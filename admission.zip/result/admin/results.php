<?php
$pageTitle = "Exam Results";
include 'header_student.php';

$selected_year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$years = range(date('Y'), 2022);
$terms = ['1st QUARTERLY', 'MID TERM', '2nd QUARTERLY', 'FINAL TERM'];
?>

<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h3 style="margin:0; color:#004a99;">Academic Records</h3>
        <form method="GET">
            <select name="year" onchange="this.form.submit()" style="padding:8px; border-radius:4px; border:1px solid #ddd;">
                <?php foreach ($years as $y): ?>
                    <option value="<?php echo $y; ?>" <?php echo ($y == $selected_year) ? 'selected' : ''; ?>>Session <?php echo $y; ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>Term Name</th>
                <th>Obtained</th>
                <th>Total</th>
                <th>Percentage</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($terms as $t):
                $safe_term = $conn->real_escape_string($t);
                $safe_year = $conn->real_escape_string($selected_year);

                // 1. Try Fetching Summary
                $s_res = $conn->query("SELECT * FROM summaries WHERE student_id=$student_id AND term_name='$safe_term' AND session_year='$safe_year'");
                $data = ($s_res->num_rows > 0) ? $s_res->fetch_assoc() : null;

                // 2. If Summary missing, check if ANY marks exist (so we can still show the "View Card" button)
                if (!$data) {
                    $r_check = $conn->query("SELECT COUNT(*) as cnt FROM results WHERE student_id=$student_id AND term_name='$safe_term' AND session_year='$safe_year'")->fetch_assoc()['cnt'];
                    if ($r_check > 0) {
                        $data = ['remarks' => 'Pending Calculation']; // Fake data to trigger button display
                    }
                }
            ?>
                <tr>
                    <td style="font-weight: bold; color:#555;"><?php echo $t; ?></td>
                    <td><?php echo $data['obtained_marks'] ?? '-'; ?></td>
                    <td><?php echo $data['out_of_marks'] ?? '-'; ?></td>
                    <td>
                        <?php if (isset($data['percentage'])) {
                            echo "<strong style='color:" . ($data['percentage'] >= 40 ? 'green' : 'red') . "'>" . $data['percentage'] . "%</strong>";
                        } else {
                            echo '-';
                        } ?>
                    </td>
                    <td><?php echo $data ? ($data['remarks'] ?? 'Available') : '<span style="color:#999;">Not Released</span>'; ?></td>
                    <td>
                        <?php if ($data): ?>
                            <a href="view_result.php?term=<?php echo urlencode($t); ?>&year=<?php echo $selected_year; ?>" class="btn-primary" style="padding:5px 10px; font-size:12px;">
                                <i class="fas fa-eye"></i> View Card
                            </a>
                        <?php else: ?>
                            <span style="color:#ccc;">&minus;</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>