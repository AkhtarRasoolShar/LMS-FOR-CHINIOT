<?php
$pageTitle = "Manage Results";
include 'header_teacher.php';

// 1. Validate Subject Selection
if (!isset($_GET['class_id']) || !isset($_GET['subject_id'])) {
    echo "<div class='content-wrapper'><div class='card text-danger'>Please select a subject from the Dashboard.</div></div>";
    exit;
}

$class_id = (int)$_GET['class_id'];
$subject_id = (int)$_GET['subject_id'];

// 2. Fetch Class/Subject Info
$info = $conn->query("SELECT c.class_name, s.subject_name FROM classes c, subjects s WHERE c.class_id=$class_id AND s.subject_id=$subject_id")->fetch_assoc();
$class_name = $info['class_name'];

// 3. Set Filters (Year & Term)
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$term = isset($_GET['term']) ? $_GET['term'] : 'FINAL TERM';

// 4. Handle Form Submission
$msg = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sid = $_POST['student_id'];
    $tot = $_POST['total_marks'];
    $obt = $_POST['obtained_marks'];
    $lock = isset($_POST['is_locked']) ? 1 : 0;

    // Check if previously locked
    $prev = $conn->query("SELECT is_locked FROM results WHERE student_id=$sid AND subject_id=$subject_id AND term_name='$term' AND session_year='$year'")->fetch_assoc();

    if ($prev && $prev['is_locked'] == 1) {
        $msg = "<div class='alert alert-danger'>Error: This result is locked and cannot be edited.</div>";
    } else {
        // Insert or Update
        if ($prev) {
            $sql = "UPDATE results SET marks_obtained='$obt', total_marks='$tot', is_locked='$lock' 
                    WHERE student_id=$sid AND subject_id=$subject_id AND term_name='$term' AND session_year='$year'";
        } else {
            $sql = "INSERT INTO results (student_id, subject_id, term_name, session_year, marks_obtained, total_marks, is_locked) 
                    VALUES ($sid, $subject_id, '$term', '$year', '$obt', '$tot', '$lock')";
        }

        if ($conn->query($sql)) {
            // Auto-Update Summary
            update_summary($conn, $sid, $term, $year);
            $msg = "<div class='alert alert-success'>Result Saved! " . ($lock ? "(Locked)" : "") . "</div>";
        }
    }
}

// Helper: Update Summary Table (Total/Grade)
function update_summary($conn, $sid, $term, $year)
{
    $data = $conn->query("SELECT SUM(marks_obtained) as obt, SUM(total_marks) as tot FROM results WHERE student_id=$sid AND term_name='$term' AND session_year='$year'")->fetch_assoc();
    $obt = $data['obt'] ?? 0;
    $tot = $data['tot'] ?? 0;
    $perc = ($tot > 0) ? round(($obt / $tot) * 100, 1) : 0;
    $grd = ($perc >= 40) ? 'Pass' : 'Fail'; // Simplified grade logic

    $chk = $conn->query("SELECT summary_id FROM summaries WHERE student_id=$sid AND term_name='$term' AND session_year='$year'");
    if ($chk->num_rows > 0)
        $conn->query("UPDATE summaries SET obtained_marks='$obt', out_of_marks='$tot', percentage='$perc', grade='$grd' WHERE student_id=$sid AND term_name='$term' AND session_year='$year'");
    else
        $conn->query("INSERT INTO summaries (student_id, term_name, session_year, obtained_marks, out_of_marks, percentage, grade) VALUES ($sid, '$term', '$year', '$obt', '$tot', '$perc', '$grd')");
}

// 5. Fetch Students & Their Marks for Selected Term
// Search Logic
$search_name = str_ireplace("Class ", "", $class_name);
$students = $conn->query("SELECT * FROM students WHERE class LIKE '%$search_name%' ORDER BY name ASC");

// Fetch existing marks to pre-fill table
$marks_cache = [];
$m_sql = "SELECT student_id, marks_obtained, total_marks, is_locked FROM results WHERE subject_id=$subject_id AND term_name='$term' AND session_year='$year'";
$m_res = $conn->query($m_sql);
while ($m = $m_res->fetch_assoc()) {
    $marks_cache[$m['student_id']] = $m;
}
?>

<div class="card">
    <div style="border-bottom:1px solid #eee; padding-bottom:15px; margin-bottom:20px;">
        <h2 style="margin:0; color:#004a99;"><?php echo $info['subject_name']; ?> <small style="color:#777; font-size:0.6em;">(<?php echo $class_name; ?>)</small></h2>

        <form method="GET" style="display:flex; gap:10px; margin-top:15px;">
            <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
            <input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">

            <select name="year" class="form-control" onchange="this.form.submit()" style="width:150px;">
                <?php for ($y = date('Y'); $y >= 2023; $y--) echo "<option value='$y' " . ($y == $year ? 'selected' : '') . ">$y</option>"; ?>
            </select>
            <select name="term" class="form-control" onchange="this.form.submit()" style="width:200px;">
                <?php foreach (['1st QUARTERLY', 'MID TERM', '2nd QUARTERLY', 'FINAL TERM'] as $t) echo "<option value='$t' " . ($t == $term ? 'selected' : '') . ">$t</option>"; ?>
            </select>
        </form>
    </div>

    <?php echo $msg; ?>

    <table style="width:100%; border-collapse:collapse;">
        <tr style="background:#f8f9fa; text-align:left; border-bottom:2px solid #ddd;">
            <th style="padding:10px;">Roll No</th>
            <th style="padding:10px;">Name</th>
            <th style="padding:10px;">Marks</th>
            <th style="padding:10px;">Status</th>
            <th style="padding:10px;">Action</th>
        </tr>
        <?php while ($s = $students->fetch_assoc()):
            $res = $marks_cache[$s['student_id']] ?? null;
            $obt = $res['marks_obtained'] ?? '';
            $is_locked = $res['is_locked'] ?? 0;
        ?>
            <tr style="border-bottom:1px solid #eee;">
                <td style="padding:10px;"><?php echo $s['student_id']; ?></td>
                <td style="padding:10px; font-weight:bold;"><?php echo htmlspecialchars($s['name']); ?></td>
                <td style="padding:10px; font-weight:bold; color:#004a99;"><?php echo $obt !== '' ? $obt : '-'; ?></td>
                <td style="padding:10px;">
                    <?php if ($is_locked): ?>
                        <span style="background:#f8d7da; color:#721c24; padding:3px 8px; border-radius:4px; font-size:12px;"><i class="fas fa-lock"></i> Locked</span>
                    <?php elseif ($obt !== ''): ?>
                        <span style="background:#d4edda; color:#155724; padding:3px 8px; border-radius:4px; font-size:12px;">Saved</span>
                    <?php else: ?>
                        <span style="color:#999; font-size:12px;">Pending</span>
                    <?php endif; ?>
                </td>
                <td style="padding:10px;">
                    <?php if ($is_locked): ?>
                        <button disabled class="btn-warning" style="opacity:0.6; cursor:not-allowed; padding:5px 10px; font-size:12px;">Locked</button>
                    <?php else: ?>
                        <button onclick="openModal('<?php echo $s['student_id']; ?>', '<?php echo addslashes($s['name']); ?>', '<?php echo $obt; ?>')" class="btn-primary" style="padding:5px 10px; font-size:12px;">
                            <?php echo ($obt !== '') ? '<i class="fas fa-edit"></i> Edit' : '<i class="fas fa-plus"></i> Add'; ?>
                        </button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>

<div id="markModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center;">
    <div style="background:white; width:400px; padding:30px; border-radius:8px; position:relative; margin-top:10%;">
        <span onclick="document.getElementById('markModal').style.display='none'" style="float:right; cursor:pointer; font-size:24px;">&times;</span>
        <h3 style="margin-top:0; color:#004a99;">Enter Marks</h3>
        <p>Student: <strong id="mName"></strong></p>
        <p style="font-size:13px; color:#666; margin-bottom:15px;">Term: <strong><?php echo $term; ?></strong> (<?php echo $year; ?>)</p>

        <form method="POST">
            <input type="hidden" name="student_id" id="mID">
            <input type="hidden" name="year" value="<?php echo $year; ?>">
            <input type="hidden" name="term" value="<?php echo $term; ?>">

            <div style="display:flex; gap:10px; margin-bottom:15px;">
                <div style="flex:1;">
                    <label>Total</label>
                    <input type="number" name="total_marks" value="100" class="form-control">
                </div>
                <div style="flex:1;">
                    <label>Obtained</label>
                    <input type="number" step="0.01" name="obtained_marks" id="mObt" class="form-control" required>
                </div>
            </div>

            <div style="margin-bottom:20px; background:#fff3cd; padding:10px; border-radius:4px;">
                <label style="font-weight:bold; color:#856404; cursor:pointer;">
                    <input type="checkbox" name="is_locked" value="1"> Lock this result?
                </label>
                <div style="font-size:11px; color:#856404;">Once locked, you cannot edit this again.</div>
            </div>

            <button type="submit" class="btn-primary" style="width:100%;">Save Result</button>
        </form>
    </div>
</div>

<script>
    function openModal(id, name, obt) {
        document.getElementById('markModal').style.display = 'flex';
        document.getElementById('mID').value = id;
        document.getElementById('mName').innerText = name;
        document.getElementById('mObt').value = obt;
    }
    window.onclick = function(e) {
        if (e.target == document.getElementById('markModal')) document.getElementById('markModal').style.display = 'none';
    }
</script>

<?php include '../../footer.php'; ?>