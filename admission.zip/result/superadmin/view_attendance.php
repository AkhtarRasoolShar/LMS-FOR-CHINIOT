<?php
include 'admin_check.php'; // Secure this page

// --- Get data for the filters ---
$class_result = $conn->query("SELECT DISTINCT class FROM students ORDER BY class");

// --- Get filter values (if set) ---
$selected_class = $_GET['class'] ?? '';
// Default to the current month
$selected_month = $_GET['month'] ?? date('Y-m');

$students = [];
$attendance_map = [];
$days_in_month = 0;

if (!empty($selected_class) && !empty($selected_month)) {
    // --- 1. Get calendar info ---
    $year = date('Y', strtotime($selected_month));
    $month = date('m', strtotime($selected_month));
    $days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);

    // --- 2. Get all students in the class ---
    $stmt_students = $conn->prepare("SELECT student_id, name FROM students WHERE class = ? ORDER BY name");
    $stmt_students->bind_param("s", $selected_class);
    $stmt_students->execute();
    $students_result = $stmt_students->get_result();
    while ($row = $students_result->fetch_assoc()) {
        $students[] = $row;
    }
    $stmt_students->close();

    // --- 3. Get all attendance data for this class and month ---
    $stmt_att = $conn->prepare("
        SELECT 
            att.student_id, 
            DAY(att.attendance_date) AS day, 
            att.status
        FROM attendance att
        INNER JOIN students s ON att.student_id = s.student_id
        WHERE 
            s.class = ? AND 
            YEAR(att.attendance_date) = ? AND 
            MONTH(att.attendance_date) = ?
    ");
    $stmt_att->bind_param("sii", $selected_class, $year, $month);
    $stmt_att->execute();
    $att_result = $stmt_att->get_result();

    // --- 4. Process the data into an easy-to-use map ---
    // The result will look like: $attendance_map[student_id][day] = 'Present'
    while ($row = $att_result->fetch_assoc()) {
        $attendance_map[$row['student_id']][$row['day']] = $row['status'];
    }
    $stmt_att->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Attendance Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 95%;
            margin: auto;
        }

        .filter-container,
        .report-container {
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        /* --- Report Table Styles --- */
        .table-wrapper {
            overflow-x: auto;
            /* Makes the table scroll horizontally */
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            min-width: 1800px;
            /* Force scrolling */
        }

        .report-table th,
        .report-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        .report-table th {
            background: #f2f2f2;
            font-size: 12px;
        }

        .report-table .student-name {
            text-align: left;
            font-weight: bold;
            min-width: 150px;
            position: sticky;
            left: 0;
            background: #f2f2f2;
            z-index: 10;
        }

        .report-table .summary-col {
            background: #f9f9f9;
            font-weight: bold;
        }

        /* Status colors */
        .status-P {
            color: #006400;
            font-weight: bold;
        }

        .status-A {
            color: #b30000;
            font-weight: bold;
        }

        .status-L {
            color: #00008b;
            font-weight: bold;
        }

        .status-H {
            background-color: #f2f2f2;
            color: #555;
        }

        /* 'H' for Holiday (Sunday) */
        .status- {
            color: #999;
        }

        /* '-' for no data */
    </style>
</head>

<body>

    <div class="header">
        <h1>Monthly Attendance Report</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">

        <div class="filter-container">
            <h2>Select Report Criteria</h2>
            <form action="view_attendance.php" method="GET" style="display: flex; gap: 20px; align-items: flex-end;">
                <div class="form-group">
                    <label for="class">Select Class</label>
                    <select name="class" required>
                        <option value="">-- Select a Class --</option>
                        <?php while ($class = $class_result->fetch_assoc()): ?>
                            <option value="<?php echo htmlspecialchars($class['class']); ?>" <?php echo ($selected_class == $class['class']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($class['class']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="month">Select Month</label>
                    <input type="month" name="month" value="<?php echo htmlspecialchars($selected_month); ?>" required>
                </div>
                <button type="submit">Generate Report</button>
            </form>
        </div>

        <?php if (!empty($students)): ?>
            <div class="report-container">
                <h2>Report for <?php echo htmlspecialchars($selected_class); ?> - <?php echo date('F Y', strtotime($selected_month)); ?></h2>
                <div class="table-wrapper">
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th class="student-name">Student Name</th>
                                <?php for ($d = 1; $d <= $days_in_month; $d++): ?>
                                    <th><?php echo $d; ?></th>
                                <?php endfor; ?>
                                <th class="summary-col">P</th>
                                <th class="summary-col">A</th>
                                <th class="summary-col">L</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student):
                                $student_id = $student['student_id'];
                                $total_present = 0;
                                $total_absent = 0;
                                $total_leave = 0;
                            ?>
                                <tr>
                                    <td class="student-name"><?php echo htmlspecialchars($student['name']); ?></td>

                                    <?php for ($d = 1; $d <= $days_in_month; $d++):
                                        // Get the status from our map
                                        $status_char = '-'; // Default (no entry)
                                        if (isset($attendance_map[$student_id][$d])) {
                                            $status = $attendance_map[$student_id][$d];
                                            $status_char = $status[0]; // 'P', 'A', or 'L'

                                            // Increment totals
                                            if ($status == 'Present') $total_present++;
                                            if ($status == 'Absent') $total_absent++;
                                            if ($status == 'Leave') $total_leave++;
                                        }

                                        // Check for Sunday
                                        $day_name = date('D', mktime(0, 0, 0, $month, $d, $year));
                                        if ($day_name == 'Sun') {
                                            $status_char = 'H'; // Holiday
                                        }
                                    ?>
                                        <td class="status-<?php echo $status_char; ?>"><?php echo $status_char; ?></td>
                                    <?php endfor; ?>

                                    <td class="summary-col status-P"><?php echo $total_present; ?></td>
                                    <td class="summary-col status-A"><?php echo $total_absent; ?></td>
                                    <td class="summary-col status-L"><?php echo $total_leave; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

    </div>
</body>

</html>