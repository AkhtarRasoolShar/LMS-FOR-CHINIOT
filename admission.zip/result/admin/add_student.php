<?php
// Secure this page!
include 'admin_check.php'; // This includes db.php

$message = '';

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // --- 1. Get Student Data ---
    $student_id = $_POST['student_id'];
    $name = $_POST['name'];
    $f_name = $_POST['f_name'];
    $class = $_POST['class'];
    $gender = $_POST['gender'];
    $photo_filename = NULL; // Default to no photo

    // --- 2. Handle File Upload ---
    // Check if a file was uploaded without errors
    if (isset($_FILES['student_photo']) && $_FILES['student_photo']['error'] == 0) {
        $target_dir = "../uploads/"; // Go UP from 'admin' to the root, then into 'uploads'

        // Get the file extension (e.g., "jpg")
        $extension = strtolower(pathinfo($_FILES["student_photo"]["name"], PATHINFO_EXTENSION));

        // Create a new, unique filename using the Student's S.NO
        // Example: 8631.jpg
        $new_filename = $student_id . '.' . $extension;
        $target_file = $target_dir . $new_filename;

        // Allowed file types
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($extension, $allowed_types)) {
            // Move the file from the temporary location to our new location
            if (move_uploaded_file($_FILES["student_photo"]["tmp_name"], $target_file)) {
                // Success! Save the new filename to the database
                $photo_filename = $new_filename;
            } else {
                $message = "Error: There was a problem uploading your file.";
            }
        } else {
            $message = "Error: Only JPG, JPEG, PNG, & GIF files are allowed.";
        }
    }

    // --- 3. Insert into Database ---
    if (empty($message)) { // Only proceed if there was no upload error
        $stmt = $conn->prepare("INSERT INTO students (student_id, name, f_name, class, gender, photo_filename) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $student_id, $name, $f_name, $class, $gender, $photo_filename);

        if ($stmt->execute()) {
            $message = "Success! Student $name added with S.NO $student_id.";
        } else {
            $message = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add Student</title>
    <style>
        /* (Same styles as before) */
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #006400;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 600px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #006400;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Add New Student</h1>
        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>">
                <?php echo $message; ?>
            </p>
        <?php endif; ?>

        <form action="add_student.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="student_id">S.NO / Roll No</label>
                <input type="number" name="student_id" required>
            </div>
            <div class="form-group">
                <label for="name">Student Name</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-group">
                <label for="f_name">Father's Name</label>
                <input type="text" name="f_name" required>
            </div>
            <div class="form-group">
                <label for="class">Class</label>
                <input type="text" name="class" placeholder="e.g., LSS B VII-A">
            </div>
            <div class="form-group">
                <label for="gender">Gender</label>
                <select name="gender">
                    <option value="MALE">MALE</option>
                    <option value="FEMALE">FEMALE</option>
                </select>
            </div>

            <div class="form-group">
                <label for="student_photo">Student Photo</label>
                <input type="file" name="student_photo">
            </div>

            <button type="submit">Add Student</button>
        </form>
    </div>
</body>

</html>