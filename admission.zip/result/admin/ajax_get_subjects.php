<?php
// ajax_get_subjects.php
// Fetches subjects assigned to the logged-in teacher for a specific class.

include 'db.php';

$class_id = (int)$_GET['class_id'] ?? 0;
$logged_in_teacher_id = $_SESSION['teacher_id'] ?? 0;

if ($class_id === 0) {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit;
}

// Find all subjects that this teacher is assigned to for this class_id.
$stmt = $conn->prepare("
    SELECT s.subject_id, s.subject_name
    FROM teacher_assignments ta
    JOIN subjects s ON ta.subject_id = s.subject_id
    WHERE 
        ta.teacher_id = ? AND ta.class_id = ?
    ORDER BY s.subject_name
");
$stmt->bind_param("ii", $logged_in_teacher_id, $class_id);
$stmt->execute();
$result = $stmt->get_result();

$subjects = [];
while ($row = $result->fetch_assoc()) {
    $subjects[] = $row;
}
$stmt->close();

header('Content-Type: application/json');
echo json_encode($subjects);
exit();
