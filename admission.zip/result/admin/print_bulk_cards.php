<?php
session_start();
require '../db.php';
if (!isset($_SESSION['teacher_id'])) die("Access Denied");

$class_id = (int)$_GET['class_id'];
$year = $_GET['year'];

$c_name = $conn->query("SELECT class_name FROM classes WHERE class_id=$class_id")->fetch_assoc()['class_name'];
$students = $conn->query("SELECT student_id FROM students WHERE class LIKE '$c_name' ORDER BY name ASC");
?>
<!DOCTYPE html>
<html>

<head>
    <title>Bulk Print</title>
    <style>
        @media print {
            .page-break {
                page-break-after: always;
            }

            .no-print {
                display: none;
            }
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Times New Roman';
        }
    </style>
</head>

<body>
    <div class="no-print" style="padding:10px; background:#333; color:white; text-align:center;">
        Printing <?php echo $students->num_rows; ?> cards <button onclick="window.print()">PRINT ALL</button>
    </div>

    <?php while ($row = $students->fetch_assoc()):
        // Include logic to render a single card directly here
        // You can simply include the view_student_card.php content logic or use an iframe if preferred (iframe is bad for print though).
        // Ideally, paste the HTML structure from view_student_card.php inside this loop.
    ?>
        <div style="height:100vh; width:100%;">
            <iframe src="view_student_card.php?student_id=<?php echo $row['student_id']; ?>&year=<?php echo $year; ?>"
                style="width:100%; height:100%; border:none;"></iframe>
        </div>
        <div class="page-break"></div>
    <?php endwhile; ?>
</body>

</html>