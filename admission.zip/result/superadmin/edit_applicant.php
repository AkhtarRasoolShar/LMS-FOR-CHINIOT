<?php
include 'admin_check.php'; // Includes session and db connection (../db.php)

// Only Super Admins can access this page
if ($_SESSION['role'] !== 'admin') {
    die("Access Denied. You must be a Super Admin.");
}

$message = '';
$error = '';

// --- File Upload Function (from send-admission.php) ---
function handleUpload($file, $form_no, $doc_type)
{
    if (isset($file) && $file['error'] == UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/'; // We are in /superadmin/, so path is ../uploads/
        $max_size = 250 * 1024; // 250KB
        $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];

        if ($file['size'] > $max_size) {
            return ['error' => "Error: File '{$doc_type}' is larger than 250KB."];
        }
        if (!in_array($file['type'], $allowed_types)) {
            return ['error' => "Error: File '{$doc_type}' has an invalid format. Use JPG, PNG, or PDF."];
        }

        $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $new_filename = "applicant_{$form_no}_{$doc_type}_" . time() . ".{$file_extension}";
        $upload_path = $upload_dir . $new_filename;

        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            return ['filename' => $new_filename];
        } else {
            return ['error' => "Error: Could not move uploaded file '{$doc_type}'."];
        }
    }
    return ['error' => "Error: No file selected or upload error for '{$doc_type}'."];
}
// --- End File Upload Function ---

// --- Document Link Helper ---
function doc_link($filename)
{
    if (!empty($filename)) {
        $path = '../uploads/' . htmlspecialchars($filename);
        return "<a href='{$path}' target='_blank'>View Current</a>";
    }
    return "N/A";
}
// --- End Helper ---


// --- PART 1: Handle Form Submission (UPDATE) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $conn->begin_transaction();

        $applicant_id = (int)$_POST['applicant_id'];
        $form_no = $_POST['form_no']; // Get form_no for file naming

        // 1. Create array of filenames, starting with the old ones
        $doc_filenames = [
            'photo_filename' => $_POST['old_photo_filename'],
            'doc_birth_cert' => $_POST['old_doc_birth_cert'],
            'doc_bform' => $_POST['old_doc_bform'],
            'doc_father_cnic_front' => $_POST['old_doc_father_cnic_front'],
            'doc_father_cnic_back' => $_POST['old_doc_father_cnic_back'],
            'doc_mother_cnic_front' => $_POST['old_doc_mother_cnic_front'],
            'doc_mother_cnic_back' => $_POST['old_doc_mother_cnic_back'],
            'doc_last_school_cert' => $_POST['old_doc_last_school_cert'],
            'doc_medical_cert' => $_POST['old_doc_medical_cert'],
        ];

        // 2. Loop through uploaded files and update if a new one is provided
        foreach ($doc_filenames as $key => $old_filename) {
            if (isset($_FILES[$key]) && $_FILES[$key]['error'] == UPLOAD_ERR_OK) {
                // A new file was uploaded
                $upload_result = handleUpload($_FILES[$key], $form_no, $key);

                if (isset($upload_result['filename'])) {
                    // Success: Update the filename and delete the old file
                    $doc_filenames[$key] = $upload_result['filename'];
                    if (!empty($old_filename)) {
                        @unlink('../uploads/' . $old_filename);
                    }
                } else {
                    // Fail: Throw the error
                    throw new Exception($upload_result['error']);
                }
            }
        }

        // 3. Prepare the UPDATE query
        $sql = "UPDATE applicants SET 
            student_name = ?, dob = ?, gender = ?, place_of_birth = ?, district = ?, 
            religion = ?, nationality = ?, student_cnic_bform = ?,
            applying_for_class = ?, last_school_name = ?, last_school_cert_no = ?,
            father_name = ?, guardian_name = ?, father_cnic = ?, office_address = ?, 
            occupation = ?, designation = ?, monthly_income = ?,
            tel_number = ?, address = ?, permanent_address = ?,
            whatsapp_father = ?, email_father = ?, email_mother = ?, whatsapp_mother = ?, 
            heard_about_us = ?, test_date = ?, test_time = ?, syllabus_url = ?, 
            payment_status = ?,
            photo_filename = ?, doc_birth_cert = ?, doc_bform = ?, 
            doc_father_cnic_front = ?, doc_father_cnic_back = ?, 
            doc_mother_cnic_front = ?, doc_mother_cnic_back = ?, 
            doc_last_school_cert = ?, doc_medical_cert = ?
            WHERE applicant_id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "ssssssssssssssssssssssssssssssisssssssssi",
            $_POST['student_name'],
            $_POST['dob'],
            $_POST['gender'],
            $_POST['place_of_birth'],
            $_POST['district'],
            $_POST['religion'],
            $_POST['nationality'],
            $_POST['student_cnic_bform'],
            $_POST['applying_for_class'],
            $_POST['last_school_name'],
            $_POST['last_school_cert_no'],
            $_POST['father_name'],
            $_POST['guardian_name'],
            $_POST['father_cnic'],
            $_POST['office_address'],
            $_POST['occupation'],
            $_POST['designation'],
            $_POST['monthly_income'],
            $_POST['tel_number'],
            $_POST['address'],
            $_POST['permanent_address'],
            $_POST['whatsapp_father'],
            $_POST['email_father'],
            $_POST['email_mother'],
            $_POST['whatsapp_mother'],
            $_POST['heard_about_us'],
            $_POST['test_date'],
            $_POST['test_time'],
            $_POST['syllabus_url'],
            $_POST['payment_status'],
            $doc_filenames['photo_filename'],
            $doc_filenames['doc_birth_cert'],
            $doc_filenames['doc_bform'],
            $doc_filenames['doc_father_cnic_front'],
            $doc_filenames['doc_father_cnic_back'],
            $doc_filenames['doc_mother_cnic_front'],
            $doc_filenames['doc_mother_cnic_back'],
            $doc_filenames['doc_last_school_cert'],
            $doc_filenames['doc_medical_cert'],
            $applicant_id
        );

        $stmt->execute();
        $conn->commit();
        $stmt->close();

        $message = "Applicant details updated successfully!";
    } catch (Exception $e) {
        $conn->rollback();
        $error = "Error updating record: " . $e->getMessage();
    }
}


// --- PART 2: Fetch Applicant Data (GET) ---
$applicant_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($applicant_id === 0 && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid Applicant ID.");
}

// If it's a POST, we need to re-fetch the (potentially new) data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $applicant_id = (int)$_POST['applicant_id'];
}

$stmt = $conn->prepare("SELECT * FROM applicants WHERE applicant_id = ?");
$stmt->bind_param("i", $applicant_id);
$stmt->execute();
$applicant_result = $stmt->get_result();

if ($applicant_result->num_rows === 0) {
    die("Applicant not found.");
}
$applicant = $applicant_result->fetch_assoc();
$stmt->close();
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Applicant - <?php echo htmlspecialchars($applicant['form_no']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #004d40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 900px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h3 {
            color: #006400;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
            margin-top: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-group label span {
            color: #dc3545;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-grid-3 {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        .file-note {
            font-size: 12px;
            color: #555;
            margin-top: 10px;
        }

        .current-file {
            font-size: 12px;
            color: #006400;
        }

        .submit-btn {
            display: block;
            width: 100%;
            padding: 12px;
            background: #006400;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            margin-top: 30px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Edit Applicant</h1>
        <a href="manage_applicants.php">Back to List</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="message error"><?php echo $error; ?></p>
        <?php endif; ?>

        <h2>Editing Application for: <?php echo htmlspecialchars($applicant['student_name']); ?> (Form: <?php echo htmlspecialchars($applicant['form_no']); ?>)</h2>

        <form action="edit_applicant.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="applicant_id" value="<?php echo $applicant['applicant_id']; ?>">
            <input type="hidden" name="form_no" value="<?php echo htmlspecialchars($applicant['form_no']); ?>">

            <h3>Admin Information</h3>
            <div class="form-grid-3">
                <div class="form-group">
                    <label for="payment_status">Payment Status <span>*</span></label>
                    <select id="payment_status" name="payment_status" required>
                        <option value="0" <?php echo ($applicant['payment_status'] == 0) ? 'selected' : ''; ?>>Pending</option>
                        <option value="1" <?php echo ($applicant['payment_status'] == 1) ? 'selected' : ''; ?>>Paid</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="test_date">Test Date</label>
                    <input type="date" id="test_date" name="test_date" value="<?php echo htmlspecialchars($applicant['test_date']); ?>">
                </div>
                <div class="form-group">
                    <label for="test_time">Test Time</label>
                    <input type="time" id="test_time" name="test_time" value="<?php echo htmlspecialchars($applicant['test_time']); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="syllabus_url">Syllabus URL</label>
                <input type="text" id="syllabus_url" name="syllabus_url" value="<?php echo htmlspecialchars($applicant['syllabus_url']); ?>">
            </div>

            <h3>Student Information</h3>
            <div class="form-grid-3">
                <div class="form-group full-width">
                    <label for="student_name">Student's Name <span>*</span></label>
                    <input type="text" id="student_name" name="student_name" value="<?php echo htmlspecialchars($applicant['student_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="dob">Date of Birth <span>*</span></label>
                    <input type="date" id="dob" name="dob" value="<?php echo htmlspecialchars($applicant['dob']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="gender">Gender <span>*</span></label>
                    <select id="gender" name="gender" required>
                        <option value="Male" <?php echo ($applicant['gender'] == 'Male') ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo ($applicant['gender'] == 'Female') ? 'selected' : ''; ?>>Female</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="place_of_birth">Place of Birth</label>
                    <input type="text" id="place_of_birth" name="place_of_birth" value="<?php echo htmlspecialchars($applicant['place_of_birth']); ?>">
                </div>
                <div class="form-group">
                    <label for="district">District</label>
                    <input type="text" id="district" name="district" value="<?php echo htmlspecialchars($applicant['district']); ?>">
                </div>
                <div class="form-group">
                    <label for="religion">Religion <span>*</span></label>
                    <input type="text" id="religion" name="religion" value="<?php echo htmlspecialchars($applicant['religion']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="nationality">Nationality <span>*</span></label>
                    <input type="text" id="nationality" name="nationality" value="<?php echo htmlspecialchars($applicant['nationality']); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label for="student_cnic_bform">Student CNIC/Form B (13 digits)</label>
                <input type="text" id="student_cnic_bform" name="student_cnic_bform" value="<?php echo htmlspecialchars($applicant['student_cnic_bform']); ?>" pattern="\d{13}">
            </div>

            <h3>Academic Information</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label for="applying_for_class">Class to which admission is sought <span>*</span></label>
                    <select id="applying_for_class" name="applying_for_class" required>
                        <option value="">—Select Class—</option>
                        <option value="Montessori Junior (Morning)" <?php echo ($applicant['applying_for_class'] == 'Montessori Junior (Morning)') ? 'selected' : ''; ?>>Montessori Junior (Morning)</option>
                        <option value="Montessori Senior (Morning)" <?php echo ($applicant['applying_for_class'] == 'Montessori Senior (Morning)') ? 'selected' : ''; ?>>Montessori Senior (Morning)</option>
                        <option value="Montessori Advance (Morning)" <?php echo ($applicant['applying_for_class'] == 'Montessori Advance (Morning)') ? 'selected' : ''; ?>>Montessori Advance (Morning)</option>
                        <option value="Class I (Morning)" <?php echo ($applicant['applying_for_class'] == 'Class I (Morning)') ? 'selected' : ''; ?>>Class I (Morning)</option>
                        <option value="Class VI" <?php echo ($applicant['applying_for_class'] == 'Class VI') ? 'selected' : ''; ?>>Class VI</option>
                        <option value="Class VIII" <?php echo ($applicant['applying_for_class'] == 'Class VIII') ? 'selected' : ''; ?>>Class VIII</option>
                        <option value="XI (Pre-Engineering)" <?php echo ($applicant['applying_for_class'] == 'XI (Pre-Engineering)') ? 'selected' : ''; ?>>XI (Pre-Engineering)</option>
                        <option value="XI (Pre-Medical)" <?php echo ($applicant['applying_for_class'] == 'XI (Pre-Medical)') ? 'selected' : ''; ?>>XI (Pre-Medical)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="last_school_name">Class studying at present / school last attended</label>
                    <input type="text" id="last_school_name" name="last_school_name" value="<?php echo htmlspecialchars($applicant['last_school_name']); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="last_school_cert_no">School Leaving Certificate No.</label>
                <input type="text" id="last_school_cert_no" name="last_school_cert_no" value="<?php echo htmlspecialchars($applicant['last_school_cert_no']); ?>">
            </div>

            <h3>Parent / Guardian Information</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label for="father_name">Father's Name <span>*</span></label>
                    <input type="text" id="father_name" name="father_name" value="<?php echo htmlspecialchars($applicant['father_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="guardian_name">Guardian's Name (If Applicable)</label>
                    <input type="text" id="guardian_name" name="guardian_name" value="<?php echo htmlspecialchars($applicant['guardian_name']); ?>">
                </div>
                <div class="form-group">
                    <label for="father_cnic">Father's CNIC (13 digits) <span>*</span></label>
                    <input type="text" id="father_cnic" name="father_cnic" value="<?php echo htmlspecialchars($applicant['father_cnic']); ?>" pattern="\d{13}" required>
                </div>
                <div class="form-group">
                    <label for="occupation">Father’s / Guardian’s Occupation</label>
                    <input type="text" id="occupation" name="occupation" value="<?php echo htmlspecialchars($applicant['occupation']); ?>">
                </div>
                <div class="form-group">
                    <label for="designation">Designation</label>
                    <input type="text" id="designation" name="designation" value="<?php echo htmlspecialchars($applicant['designation']); ?>">
                </div>
                <div class="form-group">
                    <label for="monthly_income">Monthly Income</label>
                    <input type="text" id="monthly_income" name="monthly_income" value="<?php echo htmlspecialchars($applicant['monthly_income']); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="office_address">Office / Business Address</label>
                <input type="text" id="office_address" name="office_address" value="<?php echo htmlspecialchars($applicant['office_address']); ?>">
            </div>
            <div class="form-grid-3">
                <div class="form-group">
                    <label for="tel_number">Telephone Number (Optional)</label>
                    <input type="text" id="tel_number" name="tel_number" value="<?php echo htmlspecialchars($applicant['tel_number']); ?>">
                </div>
                <div class="form-group">
                    <label for="whatsapp_father">WhatsApp No. (Father) <span>*</span></label>
                    <input type="text" id="whatsapp_father" name="whatsapp_father" value="<?php echo htmlspecialchars($applicant['whatsapp_father']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="whatsapp_mother">WhatsApp No. (Mother)</label>
                    <input type="text" id="whatsapp_mother" name="whatsapp_mother" value="<?php echo htmlspecialchars($applicant['whatsapp_mother']); ?>">
                </div>
                <div class="form-group">
                    <label for="email_father">Parent's Email (Father)</label>
                    <input type="email" id="email_father" name="email_father" value="<?php echo htmlspecialchars($applicant['email_father']); ?>">
                </div>
                <div class="form-group">
                    <label for="email_mother">Parent's Email (Mother)</label>
                    <input type="email" id="email_mother" name="email_mother" value="<?php echo htmlspecialchars($applicant['email_mother']); ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="address">Local Address <span>*</span></label>
                <textarea id="address" name="address" required><?php echo htmlspecialchars($applicant['address']); ?></textarea>
            </div>
            <div class="form-group">
                <label for="permanent_address">Permanent Address</label>
                <textarea id="permanent_address" name="permanent_address"><?php echo htmlspecialchars($applicant['permanent_address']); ?></textarea>
            </div>

            <h3>Required Documents</h3>
            <p class="file-note">Upload a new file *only* if you want to replace the existing one.</p>

            <div class="form-grid-3">
                <input type="hidden" name="old_photo_filename" value="<?php echo htmlspecialchars($applicant['photo_filename']); ?>">
                <input type="hidden" name="old_doc_birth_cert" value="<?php echo htmlspecialchars($applicant['doc_birth_cert']); ?>">
                <input type="hidden" name="old_doc_bform" value="<?php echo htmlspecialchars($applicant['doc_bform']); ?>">
                <input type="hidden" name="old_doc_father_cnic_front" value="<?php echo htmlspecialchars($applicant['doc_father_cnic_front']); ?>">
                <input type="hidden" name="old_doc_father_cnic_back" value="<?php echo htmlspecialchars($applicant['doc_father_cnic_back']); ?>">
                <input type="hidden" name="old_doc_mother_cnic_front" value="<?php echo htmlspecialchars($applicant['doc_mother_cnic_front']); ?>">
                <input type="hidden" name="old_doc_mother_cnic_back" value="<?php echo htmlspecialchars($applicant['doc_mother_cnic_back']); ?>">
                <input type="hidden" name="old_doc_last_school_cert" value="<?php echo htmlspecialchars($applicant['doc_last_school_cert']); ?>">
                <input type="hidden" name="old_doc_medical_cert" value="<?php echo htmlspecialchars($applicant['doc_medical_cert']); ?>">

                <div class="form-group">
                    <label for="photo_filename">Picture (Passport size)</label>
                    <span class="current-file"><?php echo doc_link($applicant['photo_filename']); ?></span>
                    <input type="file" id="photo_filename" name="photo_filename" accept=".jpg,.jpeg,.png,.pdf">
                </div>
                <div class="form-group">
                    <label for="doc_birth_cert">Birth Certificate (NADRA Only)</label>
                    <span class="current-file"><?php echo doc_link($applicant['doc_birth_cert']); ?></span>
                    <input type="file" id="doc_birth_cert" name="doc_birth_cert" accept=".jpg,.jpeg,.png,.pdf">
                </div>
                <div class="form-group">
                    <label for="doc_bform">B-Form (NADRA Only)</label>
                    <span class="current-file"><?php echo doc_link($applicant['doc_bform']); ?></span>
                    <input type="file" id="doc_bform" name="doc_bform" accept=".jpg,.jpeg,.png,.pdf">
                </div>
                <div class="form-group">
                    <label for="doc_father_cnic_front">Father's CNIC: Front Side</label>
                    <span class="current-file"><?php echo doc_link($applicant['doc_father_cnic_front']); ?></span>
                    <input type="file" id="doc_father_cnic_front" name="doc_father_cnic_front" accept=".jpg,.jpeg,.png,.pdf">
                </div>
                <div class="form-group">
                    <label for="doc_father_cnic_back">Father's CNIC: Back Side</label>
                    <span class="current-file"><?php echo doc_link($applicant['doc_father_cnic_back']); ?></span>
                    <input type="file" id="doc_father_cnic_back" name="doc_father_cnic_back" accept=".jpg,.jpeg,.png,.pdf">
                </div>
                <div class="form-group">
                    <label for="doc_mother_cnic_front">Mother's CNIC: Front Side</label>
                    <span class="current-file"><?php echo doc_link($applicant['doc_mother_cnic_front']); ?></span>
                    <input type="file" id="doc_mother_cnic_front" name="doc_mother_cnic_front" accept=".jpg,.jpeg,.png,.pdf">
                </div>
                <div class="form-group">
                    <label for="doc_mother_cnic_back">Mother's CNIC: Back Side</label>
                    <span class="current-file"><?php echo doc_link($applicant['doc_mother_cnic_back']); ?></span>
                    <input type="file" id="doc_mother_cnic_back" name="doc_mother_cnic_back" accept=".jpg,.jpeg,.png,.pdf">
                </div>
                <div class="form-group">
                    <label for="doc_last_school_cert">School Leaving Cert/Marksheet</label>
                    <span class="current-file"><?php echo doc_link($applicant['doc_last_school_cert']); ?></span>
                    <input type="file" id="doc_last_school_cert" name="doc_last_school_cert" accept=".jpg,.jpeg,.png,.pdf">
                </div>
                <div class="form-group">
                    <label for="doc_medical_cert">Medical Certificate</label>
                    <span class="current-file"><?php echo doc_link($applicant['doc_medical_cert']); ?></span>
                    <input type="file" id="doc_medical_cert" name="doc_medical_cert" accept=".jpg,.jpeg,.png,.pdf">
                </div>
            </div>

            <h3>Final Steps</h3>
            <div class="form-group">
                <label for="heard_about_us">How did you hear about us? <span>*</span></label>
                <select id="heard_about_us" name="heard_about_us" required>
                    <option value="Social Media (FaceBook/Instagram)" <?php echo ($applicant['heard_about_us'] == 'Social Media (FaceBook/Instagram)') ? 'selected' : ''; ?>>Social Media (FaceBook/Instagram)</option>
                    <option value="Personal Reference" <?php echo ($applicant['heard_about_us'] == 'Personal Reference') ? 'selected' : ''; ?>>Personal Reference</option>
                    <option value="School Visit" <?php echo ($applicant['heard_about_us'] == 'School Visit') ? 'selected' : ''; ?>>School Visit</option>
                    <option value="Billboard/Banner" <?php echo ($applicant['heard_about_us'] == 'Billboard/Banner)') ? 'selected' : ''; ?>>Billboard/Banner</option>
                    <option value="Other" <?php echo ($applicant['heard_about_us'] == 'Other') ? 'selected' : ''; ?>>Other</option>
                </select>
            </div>

            <button type="submit" class="submit-btn">Update Application</button>
        </form>
    </div>

</body>

</html>