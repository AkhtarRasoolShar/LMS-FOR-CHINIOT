<?php
session_start();
require '../db.php';
include '../../header.php';

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = (int)$_POST['student_id'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        // Verify Student Exists
        $check = $conn->prepare("SELECT student_id, password_hash, name FROM students WHERE student_id = ?");
        $check->bind_param("i", $student_id);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            if (!empty($row['password_hash'])) {
                $error = "Account already exists! <a href='index.php'>Please Login</a>.";
            } else {
                // Set Password
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $update = $conn->prepare("UPDATE students SET password_hash = ? WHERE student_id = ?");
                $update->bind_param("si", $hash, $student_id);

                if ($update->execute()) {
                    $success = "Account created successfully! <a href='index.php'>Click here to Login</a>.";
                } else {
                    $error = "Database error. Please try again.";
                }
            }
        } else {
            $error = "Student ID not found in our records.";
        }
        $check->close();
    }
}
?>

<div class="container-padded" style="max-width: 450px; margin: 50px auto;">
    <form method="POST" style="background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.1); border-top: 5px solid #28a745;">
        <h2 style="text-align: center; color: #28a745;">Student Registration</h2>
        <p style="text-align: center; color: #666;">Set up your account password</p>

        <?php if ($error) echo "<div style='color: red; text-align: center; margin-bottom: 10px;'>$error</div>"; ?>
        <?php if ($success) echo "<div style='color: green; text-align: center; margin-bottom: 10px;'>$success</div>"; ?>

        <div class="form-group">
            <label>Student ID (SN)</label>
            <input type="number" name="student_id" class="form-control" required style="width: 100%; padding: 10px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 4px;">
        </div>

        <div class="form-group">
            <label>New Password</label>
            <input type="password" name="password" class="form-control" required style="width: 100%; padding: 10px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 4px;">
        </div>

        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control" required style="width: 100%; padding: 10px; margin-bottom: 20px; border: 1px solid #ccc; border-radius: 4px;">
        </div>

        <button type="submit" style="width: 100%; background: #28a745; color: white; padding: 10px; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;">Create Account</button>

        <div style="text-align: center; margin-top: 15px;">
            <a href="index.php" style="color: #004a99;">Already have an account? Login</a>
        </div>
    </form>
</div>
<?php include '../../footer.php'; ?>