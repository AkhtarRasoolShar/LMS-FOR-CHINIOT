<?php
include 'admin_check.php';

// Only Super Admins
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'superadmin') {
    die("Access Denied.");
}

$selected_year = $_GET['year'] ?? date('Y');
$selected_term = $_GET['term'] ?? '';
$selected_class_id = $_GET['class_id'] ?? 0;
$search_term = $_GET['search'] ?? '';
$error = '';
$results_data = null; // Initialize to null

// --- Get Full Class List for Dropdown ---
// Note: We safely assume $conn is available from admin_check.php
$class_result = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");

// --- Build the Dynamic Results Query ---
$results_query_sql = "
    SELECT 
        s.student_id, 
        s.name, 
        s.f_name, 
        s.class, 
        su.term_name, 
        su.obtained_marks, 
        su.out_of_marks, 
        su.percentage, 
        su.rank, 
        su.grade, 
        su.remarks
    FROM summaries su
    JOIN students s ON su.student_id = s.student_id
";

// --- FIX: Using the most robust timestamp column for filtering the year ---
// We will use YEAR(su.created_at) as the most reliable default for the summary timestamp.
$where_clauses = ["YEAR(su.created_at) = ?"];
$params = [$selected_year];
$param_types = 's'; // Year is being treated as a string for binding

// 1. Term Filter
if (!empty($selected_term)) {
    $where_clauses[] = "su.term_name = ?";
    $params[] = $selected_term;
    $param_types .= 's';
}

// 2. Class Filter 
if ($selected_class_id > 0) {
    $class_name_row = $conn->query("SELECT class_name FROM classes WHERE class_id = $selected_class_id")->fetch_assoc();
    if ($class_name_row) {
        $where_clauses[] = "s.class LIKE ?";
        $params[] = '%' . $class_name_row['class_name'] . '%';
        $param_types .= 's';
    }
}

// 3. Search Filter
if (!empty($search_term)) {
    $search_term_like = '%' . $search_term . '%';
    $where_clauses[] = "(s.student_id = ? OR s.name LIKE ? OR s.f_name LIKE ?)";
    $params[] = $search_term;
    $params[] = $search_term_like;
    $params[] = $search_term_like;
    $param_types .= 'iss';
}

$results_query_sql .= " WHERE " . implode(" AND ", $where_clauses);
$results_query_sql .= " ORDER BY s.class, su.term_name, s.name";

// Prepare and execute the final query
try {
    $results_stmt = $conn->prepare($results_query_sql);
    $results_stmt->bind_param($param_types, ...$params);
    $results_stmt->execute();
    $results_data = $results_stmt->get_result(); // Store result set here
} catch (mysqli_sql_exception $e) {
    // If the error persists, the user needs to manually check the column names.
    $error = "Database Error: Failed to execute query. The summary table is missing the timestamp column used for the Year filter (created_at).";
}

$conn->close();

// Term options
$term_options = [
    '1st QUARTERLY',
    'MID TERM',
    '2nd QUARTERLY',
    'FINAL TERM'
];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View All Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
        }

        .header {
            background: #004d40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1300px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .filter-area {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .filter-area select,
        .filter-area input,
        .filter-area button {
            padding: 10px;
            font-size: 14px;
            border-radius: 4px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .filter-area button {
            background: #004d40;
            color: white;
            cursor: pointer;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th,
        .data-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            font-size: 12px;
        }

        .data-table th {
            background: #f2f2f2;
        }

        .results-table td:nth-child(6) {
            font-weight: bold;
        }

        .results-table .highlight-pass {
            color: green;
            font-weight: bold;
        }

        .results-table .highlight-fail {
            color: red;
            font-weight: bold;
        }

        /* Responsive */
        @media (max-width: 900px) {
            .filter-area {
                grid-template-columns: 1fr 1fr;
            }
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>All Student Results Overview</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($error): ?>
            <p class="message error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form class="filter-area" method="GET" action="view_all_results_by_year.php">

            <select name="year">
                <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                    <option value="<?php echo $y; ?>" <?php echo ($selected_year == $y) ? 'selected' : ''; ?>>Year <?php echo $y; ?></option>
                <?php endfor; ?>
            </select>

            <select name="term">
                <option value="">-- All Terms --</option>
                <?php foreach ($term_options as $term): ?>
                    <option value="<?php echo $term; ?>" <?php echo ($selected_term == $term) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($term); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select name="class_id">
                <option value="0">-- All Classes --</option>
                <?php $class_result->data_seek(0);
                while ($class = $class_result->fetch_assoc()): ?>
                    <option value="<?php echo $class['class_id']; ?>" <?php echo ($selected_class_id == $class['class_id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($class['class_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <input type="text" name="search" placeholder="Search Name, F.Name, or S.ID" value="<?php echo htmlspecialchars($search_term); ?>">

            <button type="submit" style="grid-column: span 1;">Filter/Search</button>

        </form>

        <?php if ($results_data && $results_data->num_rows > 0): ?>
            <table class="data-table results-table">
                <thead>
                    <tr>
                        <th>S.ID</th>
                        <th>Name</th>
                        <th>Father's Name</th>
                        <th>Class</th>
                        <th>Term</th>
                        <th>Obtained</th>
                        <th>Total</th>
                        <th>%</th>
                        <th>Rank</th>
                        <th>Grade</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $results_data->fetch_assoc()): ?>
                        <?php $remarks_class = ($row['remarks'] == 'PASSED') ? 'highlight-pass' : 'highlight-fail'; ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['f_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['class']); ?></td>
                            <td><?php echo htmlspecialchars($row['term_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['obtained_marks'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['out_of_marks'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['percentage'] ?? 'N/A'); ?>%</td>
                            <td><?php echo htmlspecialchars($row['rank'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($row['grade'] ?? '-'); ?></td>
                            <td><span class="<?php echo $remarks_class; ?>"><?php echo htmlspecialchars($row['remarks'] ?? '-'); ?></span></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No results found for the selected criteria in Year <?php echo $selected_year; ?>.</p>
        <?php endif; ?>
    </div>
</body>

</html>