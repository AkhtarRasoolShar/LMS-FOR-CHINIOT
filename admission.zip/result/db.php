


<?php
/*
  db.php
  This file connects to your MySQL database.
  It is shared by Student, Teacher, and Super Admin portals.
*/

// Database credentials
$servername = "localhost"; // Usually 'localhost'
$username = "u298546061_chiniot";        // Your database username (default for XAMPP)
$password = "Chiniot0099#";            // Your database password (default for XAMPP is empty)
$dbname = "u298546061_admission"; // The name of the database you created


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the character set to utf8 (good for all languages, including Urdu)
$conn->set_charset("utf8");

// Optional: Set Timezone if needed (e.g., 'Asia/Karachi')
date_default_timezone_set('Asia/Karachi');
?>
