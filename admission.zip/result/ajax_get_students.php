<?php
include 'db.php'; // Includes db connection
session_start();

// Check if teacher is logged in (use role check for security)
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'teacher') {
    echo json_encode([]);
    exit;
}

$class_id = (int)$_GET['class_id'];
$status_filter = $_GET['status'] ?? ''; // New status filter passed from add_result.php
$students = [];

// Security: We MUST get the class name from the class_id
$class_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
$class_stmt->bind_param("i", $class_id);
$class_stmt->execute();
$class_result = $class_stmt->get_result();

if ($class_result->num_rows > 0) {
    $class_row = $class_result->fetch_assoc();
    $class_name = $class_row['class_name']; // e.g., "V-A"

    // Use LIKE to find students in "PM V-A" or "CO V-A"
    $like_class_name = '%' . $class_name . '%';

    $sql = "SELECT student_id, name FROM students WHERE class LIKE ?";
    $types = "s";
    $params = [$like_class_name];

    // --- FIX: Add enrollment status filter if the flag is set (e.g., from add_result.php) ---
    if ($status_filter == 'current') {
        $sql .= " AND enrollment_status = 'Current'";
    }

    $sql .= " ORDER BY name";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $students[] = [
            'student_id' => $row['student_id'],
            'name' => htmlspecialchars($row['name'])
        ];
    }
    $stmt->close();
}

$class_stmt->close();
$conn->close();

header('Content-Type: application/json');
echo json_encode($students);
