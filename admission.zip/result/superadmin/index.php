<?php
session_start();
// If admin is already logged in, redirect to dashboard
if (isset($_SESSION['teacher_id']) && $_SESSION['role'] == 'admin') {
    header("Location: dashboard.php");
    exit();
}

// Check for login errors
$error = '';
if (isset($_GET['error'])) {
    $error = "Invalid username or password.";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Administrator Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 40px;
            text-align: center;
            width: 300px;
        }

        /* Red theme for Admin */
        h2 {
            margin: 0 0 20px 0;
            color: #b30000;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        /* Red theme for Admin */
        button {
            background-color: #b30000;
            color: white;
            padding: 14px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }

        a {
            color: #b30000;
            text-decoration: none;
            display: block;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Administrator Login</h2>
        <?php if ($error): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form action="auth.php" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</body>

</html>