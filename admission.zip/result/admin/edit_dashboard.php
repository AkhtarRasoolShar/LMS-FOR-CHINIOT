<?php
// Secure this page!
include 'admin_check.php'; // This includes db.php

$logged_in_teacher_id = $_SESSION['teacher_id'];
$selected_student_id = $_GET['student_id'] ?? null;
$message = '';

// --- 1. Get all students assigned to this teacher (for the filter dropdown) ---
$stmt_students = $conn->prepare("
    SELECT DISTINCT s.student_id, s.name, c.class_name
    FROM students s
    JOIN classes c ON s.class = c.class_name
    JOIN teacher_assignments ta ON c.class_id = ta.class_id
    WHERE ta.teacher_id = ?
    ORDER BY c.class_name, s.name
");
$stmt_students->bind_param("i", $logged_in_teacher_id);
$stmt_students->execute();
$students_result = $stmt_students->get_result();

// --- 2. If a student is selected, get their submitted term summaries ---
$summaries = [];
if ($selected_student_id) {
    // Retrieve summaries submitted by THIS teacher for the selected student
    $stmt_summaries = $conn->prepare("
        SELECT s.summary_id, s.term_name, s.is_locked, c.report_template
        FROM summaries s
        JOIN students st ON s.student_id = st.student_id
        JOIN classes c ON st.class = c.class_name
        WHERE s.student_id = ? AND s.teacher_id = ?
        ORDER BY s.term_name
    ");
    $stmt_summaries->bind_param("ii", $selected_student_id, $logged_in_teacher_id);
    $stmt_summaries->execute();
    $summaries_result_set = $stmt_summaries->get_result();
    while ($row = $summaries_result_set->fetch_assoc()) {
        $summaries[] = $row;
    }
    $stmt_summaries->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Submitted Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #006400;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 900px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h2 {
            border-bottom: 2px solid #006400;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .filter-form {
            margin-bottom: 30px;
        }

        .filter-form label {
            font-weight: bold;
            margin-right: 10px;
        }

        .filter-form select {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .results-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .results-table th,
        .results-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .results-table th {
            background: #f2f2f2;
            color: #006400;
        }

        .status-locked {
            color: #b30000;
            font-weight: bold;
        }

        .status-unlocked {
            color: #006400;
            font-weight: bold;
        }

        .btn-edit {
            background-color: #006400;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
        }

        .btn-disabled {
            background-color: #ccc;
            color: #666;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
            display: inline-block;
            cursor: not-allowed;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Submitted Results Review</h1>
        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <h2>Submitted Reports</h2>

        <form action="edit_dashboard.php" method="GET" class="filter-form">
            <label for="student_id">Select Student to Review:</label>
            <select name="student_id" id="student_id" onchange="this.form.submit()">
                <option value="">-- Select Student --</option>
                <?php while ($student = $students_result->fetch_assoc()): ?>
                    <option value="<?php echo $student['student_id']; ?>"
                        <?php if ($selected_student_id == $student['student_id']) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($student['name']); ?> (<?php echo htmlspecialchars($student['class_name']); ?>)
                    </option>
                <?php endwhile; ?>
            </select>
        </form>

        <?php if (!empty($summaries)): ?>
            <div class="results-display">
                <h3>Submitted Term Summaries</h3>
                <p style="color: #b30000; font-weight: bold;">Only UNLOCKED reports can be edited.</p>
                <table class="results-table">
                    <thead>
                        <tr>
                            <th>Term</th>
                            <th>Lock Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($summaries as $summary):
                            $edit_page = ($summary['report_template'] == 'primary') ? 'edit_result_form_primary.php' : 'edit_result_form.php';
                        ?>
                            <tr>
                                <td><?php echo htmlspecialchars($summary['term_name']); ?></td>
                                <td>
                                    <?php if ($summary['is_locked'] == 1): ?>
                                        <span class="status-locked">LOCKED</span>
                                    <?php else: ?>
                                        <span class="status-unlocked">UNLOCKED</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($summary['is_locked'] == 1): ?>
                                        <span class="btn-disabled">Locked</span>
                                    <?php else: ?>
                                        <a href="<?php echo $edit_page; ?>?summary_id=<?php echo $summary['summary_id']; ?>" class="btn-edit">Edit</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php elseif ($selected_student_id): ?>
            <p style="text-align: center; margin-top: 20px;">No results have been submitted for this student yet.</p>
        <?php endif; ?>

    </div>
</body>

</html>