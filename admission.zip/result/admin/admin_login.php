<?php
// Ensure session is started for authentication
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection (assuming this file exists at '../db.php' relative to this location)
// NOTE: You must ensure the path to your database connection file is correct.
require_once '../db.php';

// Initialize login error message
$login_error = '';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Sanitize input
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Simple validation
    if (empty($username) || empty($password)) {
        $login_error = "Please enter both username and password.";
    } else {

        // 2. Prepare an SQL statement to retrieve user data securely
        // Use prepared statements to prevent SQL Injection
        $sql = "SELECT admin_id, password FROM admin WHERE username = ?";

        if ($stmt = $conn->prepare($sql)) {
            // Bind the username parameter
            $stmt->bind_param("s", $username);

            // Execute the statement
            if ($stmt->execute()) {
                $stmt->store_result();

                if ($stmt->num_rows == 1) {
                    // Bind result variables
                    $stmt->bind_result($admin_id, $hashed_password);

                    if ($stmt->fetch()) {
                        // 3. Verify the password hash
                        // CRITICAL: This uses modern secure hashing. It requires passwords to be stored with password_hash().
                        if (password_verify($password, $hashed_password)) {
                            // Password is correct, start a new session
                            $_SESSION["loggedin"] = true;
                            $_SESSION["admin_id"] = $admin_id;
                            $_SESSION["username"] = $username;

                            // Redirect to admin dashboard
                            header("Location: admin_dashboard.php");
                            exit;
                        } else {
                            // Password is not valid
                            $login_error = "Invalid username or password.";
                        }
                    }
                } else {
                    // Username doesn't exist
                    $login_error = "Invalid username or password.";
                }
            } else {
                // Execution error
                error_log("SQL Execution Error in admin_login.php: " . $stmt->error);
                $login_error = "An internal error occurred. Please try again.";
            }

            // Close statement
            $stmt->close();
        } else {
            // Preparation error
            error_log("SQL Preparation Error in admin_login.php: " . $conn->error);
            $login_error = "An internal error occurred. Please try again.";
        }
    }
}
// If there was an error during POST, or it's a GET request, the HTML form is rendered below.
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <!-- Include your CSS files here. Example: -->
    <!-- <link rel="stylesheet" href="../../css/style.css"> -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn-login {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .btn-login:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: #e74c3c;
            text-align: center;
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #e74c3c;
            border-radius: 4px;
            background-color: #fdd;
        }

        .forgot-password {
            text-align: center;
            margin-top: 15px;
        }

        .forgot-password a {
            color: #007bff;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h2>Admin Login</h2>

        <?php
        // Display error messages from failed login attempt
        if (!empty($login_error)) {
            echo '<div class="error-message">' . htmlspecialchars($login_error) . '</div>';
        }
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <button type="submit" class="btn-login">Login</button>
            </div>
        </form>

        <div class="forgot-password">
            <a href="forgot_password.php">Forgot Password?</a>
        </div>
    </div>
</body>

</html>