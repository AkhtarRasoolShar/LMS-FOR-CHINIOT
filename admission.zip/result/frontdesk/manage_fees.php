<?php
include 'admin_check.php'; // --- SECURITY FIRST ---

// --- The user ID is correctly defined in admin_check.php as $_SESSION['user_id'] ---
// We don't need to redeclare it, but we can access it via $_SESSION['user_id']

$message = '';
$selected_class_id = $_GET['class_id'] ?? 0;
$search_term = $_GET['search'] ?? '';
$search_term_clean = '%' . $search_term . '%'; // Prepared once for LIKE queries

// Handle "Toggle Payment" action
if (isset($_GET['action']) && $_GET['action'] == 'toggle' && isset($_GET['id'])) {
    $student_id = (int)$_GET['id'];

    // Toggle payment status (flips 0 to 1, or 1 to 0)
    $conn->query("UPDATE students SET is_fee_paid = !is_fee_paid WHERE student_id = $student_id");

    $message = "Payment status updated for student ID: $student_id.";
}

// --- Get Full Class List for Dropdown (Unfiltered) ---
$class_result = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");

// --- Build the Dynamic Students Query ---
$students_query_sql = "SELECT student_id, name, f_name, class, is_fee_paid FROM students";
$where_clauses = [];
$params = [];
$param_types = '';

// 1. Class Filter Logic
if ($selected_class_id > 0) {
    // Get the Class Name from the ID for the LIKE search (e.g., 'V-A')
    $class_name_row = $conn->query("SELECT class_name FROM classes WHERE class_id = $selected_class_id")->fetch_assoc();
    if ($class_name_row) {
        $where_clauses[] = "class LIKE ?";
        $params[] = '%' . $class_name_row['class_name'] . '%';
        $param_types .= 's';
    }
}

// 2. Search Filter (by ID, Name, or Father's Name)
if (!empty($search_term)) {
    // We add placeholders for each search field
    $where_clauses[] = "(student_id = ? OR name LIKE ? OR f_name LIKE ?)";
    $params[] = $search_term;          // For exact ID match
    $params[] = $search_term_clean;    // For name LIKE %term%
    $params[] = $search_term_clean;    // For f_name LIKE %term%
    $param_types .= 'iss';
}

if (!empty($where_clauses)) {
    $students_query_sql .= " WHERE " . implode(" AND ", $where_clauses);
}

$students_query_sql .= " ORDER BY name";

// Prepare and execute the final query
$students_stmt = $conn->prepare($students_query_sql);
if (!empty($params)) {
    $students_stmt->bind_param($param_types, ...$params);
}
$students_stmt->execute();
$students_result = $students_stmt->get_result();
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Student Fees</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7f6;
            margin: 0;
        }

        .header {
            background: #004a99;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .filter-area {
            display: grid;
            grid-template-columns: 1fr 3fr;
            /* Class filter, Search input + button */
            gap: 15px;
            margin-bottom: 20px;
        }

        .filter-area select {
            padding: 10px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        .search-group {
            display: flex;
        }

        .search-group input {
            padding: 10px;
            font-size: 16px;
            border-radius: 4px 0 0 4px;
            border: 1px solid #ccc;
            flex-grow: 1;
        }

        .search-group button {
            padding: 10px 15px;
            font-size: 16px;
            background: #004a99;
            color: white;
            border: none;
            border-radius: 0 4px 4px 0;
            cursor: pointer;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th,
        .data-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            font-size: 14px;
        }

        .data-table th {
            background: #f2f2f2;
        }

        .status-paid {
            color: green;
            font-weight: bold;
        }

        .status-unpaid {
            color: red;
            font-weight: bold;
        }

        .action-link {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
            color: white;
        }

        .action-paid {
            background-color: #28a745;
        }

        .action-unpaid {
            background-color: #dc3545;
        }

        @media (max-width: 768px) {
            .filter-area {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Manage Student Fees</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>

        <form class="filter-area" method="GET" action="manage_fees.php">

            <select name="class_id" onchange="this.form.submit()">
                <option value="0">-- Filter by Class --</option>
                <?php $class_result->data_seek(0);
                while ($class = $class_result->fetch_assoc()): ?>
                    <option value="<?php echo $class['class_id']; ?>" <?php echo ($selected_class_id == $class['class_id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($class['class_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <div class="search-group">
                <input type="text" name="search" placeholder="Search by Student ID, Name, or Father's Name" value="<?php echo htmlspecialchars($search_term); ?>">
                <button type="submit">Search</button>
            </div>
        </form>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Father's Name</th>
                    <th>Class</th>
                    <th>Fee Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($students_result && $students_result->num_rows > 0): ?>
                    <?php while ($row = $students_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['f_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['class']); ?></td>
                            <td>
                                <?php if ($row['is_fee_paid'] == 1): ?>
                                    <span class="status-paid">Paid</span>
                                <?php else: ?>
                                    <span class="status-unpaid">Not Paid</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                // Preserve current filters in the toggle links
                                $current_filters = "class_id=$selected_class_id&search=" . urlencode($search_term);
                                if ($row['is_fee_paid'] == 1): ?>
                                    <a href="?action=toggle&id=<?php echo $row['student_id']; ?>&<?php echo $current_filters; ?>" class="action-link action-unpaid">Mark as Unpaid</a>
                                <?php else: ?>
                                    <a href="?action=toggle&id=<?php echo $row['student_id']; ?>&<?php echo $current_filters; ?>" class="action-link action-paid">Mark as Paid</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No students found matching your criteria.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html>