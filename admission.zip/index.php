<?php
$pageTitle = "Home";
include 'header.php';

// --- ADDED DB CONNECTION WITH ERROR CHECKING ---
$admissions_status = 'closed'; // Default to closed
try {
    require_once 'result/db.php'; // Use require_once

    // Check admission status from database
    $sql = "SELECT setting_value FROM system_settings WHERE setting_name = 'admissions_status'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $status_row = $result->fetch_assoc();
        $admissions_status = $status_row['setting_value'];
    } else {
        // This will happen if the table/row doesn't exist.
        error_log("Warning: 'system_settings' table or 'admissions_status' row not found. Defaulting to closed.");
    }
    $conn->close(); // Close the connection

} catch (Exception $e) {
    // This CATCH block prevents the white screen if db.php fails or query fails
    error_log("Database connection error on index.php: " . $e->getMessage());
    $admissions_status = 'closed'; // Safely default to closed
}
?>

<style>
    /* --- Hero Section --- */
    .hero {
        background-image: linear-gradient(rgba(0, 74, 153, 0.7), rgba(0, 74, 153, 0.7)), url('/chiniot/image_fe2690.png');
        background-size: cover;
        background-position: center;
        text-align: center;
        padding: 100px 20px;
        color: white;
    }

    .hero-content h1 {
        font-size: 3.5em;
        margin: 0;
        font-weight: 700;
        text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);
    }

    .hero-content p {
        font-size: 1.4em;
        margin: 20px 0 30px 0;
        max-width: 600px;
        margin-left: auto;
        margin-right: auto;
    }

    .cta-button-large {
        background-color: #fdb813;
        /* Gold */
        color: #000;
        padding: 15px 30px;
        text-decoration: none;
        font-size: 1.2em;
        font-weight: bold;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .cta-button-large:hover {
        background-color: #ffc107;
    }

    /* --- Admissions Notice Banners --- */
    .admission-closed-notice {
        background-color: #dc3545;
        /* Red */
        color: white;
        text-align: center;
        padding: 15px;
        font-size: 1.2em;
        font-weight: bold;
    }

    .admission-open-notice {
        background-color: #28a745;
        /* Green */
        color: white;
        text-align: center;
        padding: 15px;
        font-size: 1.2em;
        font-weight: bold;
    }

    /* --- Admissions Popup Modal --- */
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.6);
        z-index: 1000;
        display: none;
    }

    .modal-popup {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: #fff;
        border-radius: 8px;
        width: 90%;
        max-width: 500px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        text-align: center;
        padding: 30px;
        z-index: 1001;
        display: none;
        animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translate(-50%, -45%);
        }

        to {
            opacity: 1;
            transform: translate(-50%, -50%);
        }
    }

    .modal-popup h2 {
        color: #004a99;
        margin-top: 0;
        font-size: 24px;
    }

    /* Blue */
    .modal-popup p {
        font-size: 18px;
        color: #333;
        margin: 20px 0;
    }

    .modal-close-btn {
        background: #004a99;
        color: white;
        border: none;
        /* Blue */
        padding: 10px 20px;
        border-radius: 5px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        text-decoration: none;
    }

    .modal-close-btn.open {
        background: #28a745;
        /* Green for 'Apply Now' */
    }

    .modal-close-btn:hover {
        background: #003b7a;
    }

    /* Darker Blue */
    .modal-close-btn.open:hover {
        background: #218838;
    }

    /* --- Content Sections --- */
    .content-section {
        background: #fff;
        padding: 50px 30px;
        max-width: 1000px;
        margin: 30px auto;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .content-section.light-bg {
        background: #f9f9f9;
    }

    .content-section.dark-bg {
        background: #004a99;
        /* Blue */
        color: white;
    }

    .content-section h2 {
        text-align: center;
        font-size: 2.5em;
        margin-top: 0;
        margin-bottom: 40px;
        color: #004a99;
        /* Blue */
    }

    .content-section.dark-bg h2 {
        color: white;
    }

    /* --- Welcome Section --- */
    .welcome-content {
        display: flex;
        align-items: center;
        gap: 30px;
    }

    .welcome-content img {
        width: 200px;
        height: 200px;
        border-radius: 50%;
        object-fit: cover;
        border: 5px solid #004a99;
        /* Blue */
    }

    .welcome-text {
        flex: 1;
        font-size: 1.1em;
        line-height: 1.7;
    }

    .welcome-text h2 {
        text-align: left;
    }

    /* --- NEW: Quick Links Section --- */
    .links-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
    }

    .link-card {
        text-decoration: none;
        color: #fff;
        position: relative;
        overflow: hidden;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    }

    .link-card img {
        width: 100%;
        height: 250px;
        object-fit: cover;
        display: block;
        transition: transform 0.4s ease;
    }

    .link-card:hover img {
        transform: scale(1.1);
    }

    .link-card-overlay {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        padding: 15px;
        background: linear-gradient(to top, rgba(0, 74, 153, 0.9), rgba(0, 74, 153, 0));
    }

    .link-card-overlay h3 {
        margin: 0;
        font-size: 1.5em;
        font-weight: 600;
        color: #fff;
    }

    /* --- Stats Bar --- */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
        text-align: center;
    }

    .stat-item {
        border-right: 1px solid #003b7a;
        /* Darker Blue */
    }

    .stat-item:last-child {
        border-right: none;
    }

    .stat-item span {
        font-size: 2.5em;
        font-weight: bold;
        display: block;
        color: #fdb813;
        /* Gold */
    }

    .stat-item p {
        font-size: 1.2em;
        margin: 5px 0 0 0;
    }

    /* --- News Section --- */
    .news-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 30px;
    }

    .news-card {
        background: #fff;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .news-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    .news-card img {
        width: 100%;
        height: 220px;
        object-fit: cover;
    }

    .news-content {
        padding: 25px;
    }

    .news-content span {
        font-size: 0.9em;
        color: #777;
    }

    .news-content h3 {
        font-size: 1.3em;
        margin: 10px 0;
        color: #333;
    }

    .news-content a {
        color: #004a99;
        text-decoration: none;
        font-weight: bold;
    }

    /* --- Animation Class --- */
    .fade-in {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease-out, transform 0.6s ease-out;
    }

    .fade-in.visible {
        opacity: 1;
        transform: translateY(0);
    }

    /* Responsive */
    @media (max-width: 900px) {

        .links-grid,
        .news-grid {
            grid-template-columns: 1fr 1fr;
        }
    }

    @media (max-width: 768px) {
        .hero h1 {
            font-size: 2.5em;
        }

        .hero p {
            font-size: 1.2em;
        }

        .welcome-content {
            flex-direction: column;
            text-align: center;
        }

        .stats-grid {
            grid-template-columns: 1fr;
        }

        .stat-item {
            border-right: none;
            border-bottom: 1px solid #003b7a;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }

        .stat-item:last-child {
            border-bottom: none;
            padding-bottom: 0;
            margin-bottom: 0;
        }
    }

    @media (max-width: 600px) {

        .links-grid,
        .news-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="modal-overlay" id="popupOverlay"></div>
<div class="modal-popup" id="admissionPopup">
    <?php if ($admissions_status == 'open'): ?>
        <h2>Admissions are Open!</h2>
        <p>Registration for the 2025-2026 session is now available.</p>
        <a href="/chiniot/admissions.php" class="modal-close-btn open">Apply Now</a>
    <?php else: ?>
        <h2>Admissions Closed</h2>
        <p>Admissions / Registration for Session 2025-2026 are now Closed.</p>
        <button class="modal-close-btn" id="closePopupBtn">OK</button>
    <?php endif; ?>
</div>

<section class="hero">
    <div class="hero-content">

        <h1>Quality Education at an Affordable Cost</h1>
        <p>Our mission is to produce students of high academic and moral caliber.</p>
    </div>
</section>

<?php if ($admissions_status == 'open'): ?>
    <section class="admission-open-notice">
        Admissions for Session 2025-2026 are now OPEN! <a href="/chiniot/admissions.php" style="color: white; text-decoration: underline;">Apply Now</a>
    </section>
<?php else: ?>
    <section class="admission-closed-notice">
        Admissions / Registration for Session 2025-2026 are now Closed.
    </section>
<?php endif; ?>

<section class="content-section">
    <div class="container">
        <div class="welcome-content fade-in">
            <img src="/chiniot/principle.jpg" alt="Principal's Message">
            <div class="welcome-text">
                <h2>Message from the Principal</h2>
                <p>Welcome to Chiniot Islamia Public School & College. We are dedicated to fostering an environment of academic excellence and moral integrity. Our mission is to nurture young minds, equipping them with the knowledge and character to lead and succeed in a global community. We believe in a balanced approach to education, one that develops our students intellectually, morally, and physically.</p>
            </div>
        </div>
    </div>
</section>

<section class="content-section light-bg">
    <div class="container">
        <h2 class="fade-in">Quick Links</h2>
        <div class="links-grid">
            <a href="/chiniot/admissions.php" class="link-card fade-in">
                <img src="/chiniot/img/admission.png" alt="Admissions">
                <div class="link-card-overlay">
                    <h3>Admissions</h3>
                </div>
            </a>
            <a href="/chiniot/result/index.php" class="link-card fade-in">
                <img src="/chiniot/img/DSC_4500-768x512.jpg" alt="Student Portal">
                <div class="link-card-overlay">
                    <h3>Student Portal</h3>
                </div>
            </a>
            <a href="/chiniot/career.php" class="link-card fade-in">
                <img src="/chiniot/img/car.jpg" alt="Career">
                <div class="link-card-overlay">
                    <h3>Career</h3>
                </div>
            </a>
            <a href="/chiniot/contact.php" class="link-card fade-in">
                <img src="/chiniot/img/contact-us.jpg" alt="Contact Us">
                <div class="link-card-overlay">
                    <h3>Contact Us</h3>
                </div>
            </a>
        </div>
    </div>
</section>

<section class="content-section dark-bg fade-in">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-item">
                <span>13,396+</span>
                <p>Books in Library</p>
            </div>
            <div class="stat-item">
                <span>150+</span>
                <p>Qualified Staff</p>
            </div>
            <div class="stat-item">
                <span>38+</span>
                <p>Years of Excellence</p>
            </div>
        </div>
    </div>
</section>

<section class="content-section">
    <div class="container">
        <h2 class="fade-in">Latest News & Events</h2>
        <div class="news-grid">
            <div class="news-card fade-in">
                <img src="/chiniot/img/DSC_5658-768x512.jpg" alt="Annual Sports Gala">
                <div class="news-content">
                    <span>October 29, 2025</span>
                    <h3>Annual Sports Gala Was a Huge Success</h3>
                    <a href="/chiniot/gallery.php#sports">Read More &rarr;</a>
                </div>
            </div>
            <div class="news-card fade-in">
                <img src="/chiniot/img/DSC_6870-768x512.jpg" alt="Science Exhibition">
                <div class="news-content">
                    <span>October 15, 2025</span>
                    <h3>Students Showcase Innovation at Science Exhibition</h3>
                    <a href="/chiniot/gallery.php#open-day">Read More &rarr;</a>
                </div>
            </div>
            <div class="news-card fade-in">
                <img src="/chiniot/img/416020959_847957184005621_7665658194456500485_n-768x512.jpg" alt="Scout Camp">
                <div class="news-content">
                    <span>September 30, 2025</span>
                    <h3>Annual Scout Camp Teaches Leadership Skills</h3>
                    <a href="/chiniot/gallery.php#scouts">Read More &rarr;</a>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        // --- 1. Popup Logic (Shows once per session) ---
        const popup = document.getElementById('admissionPopup');
        const closeBtn = document.getElementById('closePopupBtn');
        const overlay = document.getElementById('popupOverlay');

        if (popup && overlay && !sessionStorage.getItem('popupShown')) {
            popup.style.display = 'block';
            overlay.style.display = 'block';
            sessionStorage.setItem('popupShown', 'true');
        }

        function closePopup() {
            if (popup && overlay) {
                popup.style.display = 'none';
                overlay.style.display = 'none';
            }
        }
        if (closeBtn) {
            closeBtn.addEventListener('click', closePopup);
        }
        if (overlay) {
            overlay.addEventListener('click', closePopup);
        }

        // --- 2. Fade-in on Scroll Animation Logic ---
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.1 // Trigger when 10% of the element is visible
            });

            const elementsToFade = document.querySelectorAll('.fade-in');
            elementsToFade.forEach(el => {
                observer.observe(el);
            });
        }
    });
</script>

<?php include 'footer.php'; ?>