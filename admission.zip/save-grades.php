<?php
// Start the session
session_start();
require 'db_connect.php'; // Get the database connection

// --- SECURITY CHECK ---
if (!isset($_SESSION["teacher_loggedin"]) || $_SESSION["teacher_loggedin"] !== true) {
    header("location: teacher-login.html");
    exit;
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get the common data from the form
    $class_id = $_POST['class_id'];
    $subject = $_POST['subject'];
    $exam_type = $_POST['exam_type'];
    $grades_data = $_POST['grades']; // This is an array [student_id => marks]

    // Prepare the SQL query
    // This is similar to the attendance query.
    // 1. It tries to INSERT a new grade.
    // 2. If a grade for that student, subject, and exam already exists,
    //    it will UPDATE the 'marks_obtained' instead.
    $sql = "INSERT INTO grades (student_id, class_id, subject, exam_type, marks_obtained) 
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE marks_obtained = VALUES(marks_obtained)";

    if ($stmt = $conn->prepare($sql)) {
        // Bind parameters
        $stmt->bind_param("iissi", $student_id, $class_id, $subject, $exam_type, $marks_obtained);

        // Loop through each grade submitted
        foreach ($grades_data as $student_id => $marks_obtained) {

            // Skip if the teacher left the marks box empty
            if (empty($marks_obtained) && $marks_obtained !== '0') {
                continue;
            }

            // The variables $student_id and $marks_obtained are updated here
            // and then executed by the prepared statement
            $stmt->execute();
        }

        // Close the statement
        $stmt->close();
    } else {
        // Handle error if statement couldn't be prepared
        echo "Error: Could not prepare the database query.";
        exit;
    }

    // Close the connection
    $conn->close();

    // --- SUCCESS ---
    // Redirect the teacher back to the dashboard with a success message.
    header("location: teacher-dashboard.php?grades_success=1");
    exit;
} else {
    // If not a POST request, just redirect
    header("location: teacher-dashboard.php");
    exit;
}
