<?php
include 'admin_check.php'; // Includes security and sets $logged_in_user_id

$message = '';
$selected_class_id = $_GET['class_id'] ?? 0;
$search_term = $_GET['search'] ?? '';
$search_term_clean = '%' . $search_term . '%';

// --- Get Full Class List for Dropdown (Unfiltered) ---
$class_result = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");

// --- Build the Students Query (with Filters) ---
// FIX: We select 'enrollment_status' which was added in a previous step.
// FIX: We select student_id twice for the Roll No. field.
$students_query_sql = "SELECT student_id, name, f_name, class, enrollment_status FROM students";
$where_clauses = [];
$params = [];
$param_types = '';

// 1. Class Filter Logic
if ($selected_class_id > 0) {
    // Get the Class Name from the ID for the LIKE search
    $class_name_row = $conn->query("SELECT class_name FROM classes WHERE class_id = $selected_class_id")->fetch_assoc();
    if ($class_name_row) {
        $where_clauses[] = "class LIKE ?";
        $params[] = '%' . $class_name_row['class_name'] . '%';
        $param_types .= 's';
    }
}

// 2. Search Filter (by ID, Name, or Father's Name)
if (!empty($search_term)) {
    // FIX: Using student_id for Roll No. search
    $where_clauses[] = "(student_id = ? OR name LIKE ? OR f_name LIKE ?)";
    $params[] = $search_term;
    $params[] = $search_term_clean;
    $params[] = $search_term_clean;
    $param_types .= 'iss';
}

if (!empty($where_clauses)) {
    $students_query_sql .= " WHERE " . implode(" AND ", $where_clauses);
}

$students_query_sql .= " ORDER BY class, name";

// Prepare and execute the final query
$students_stmt = $conn->prepare($students_query_sql);
if (!empty($params)) {
    $students_stmt->bind_param($param_types, ...$params);
}
$students_stmt->execute();
$students_result = $students_stmt->get_result();
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Students</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #004d40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .filter-area {
            display: grid;
            grid-template-columns: 1fr 2fr 100px;
            gap: 15px;
            margin-bottom: 20px;
        }

        .filter-area select {
            padding: 10px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        .search-group {
            display: flex;
            grid-column: 2 / 4;
        }

        .search-group input {
            padding: 10px;
            font-size: 16px;
            border-radius: 4px 0 0 4px;
            border: 1px solid #ccc;
            flex-grow: 1;
        }

        .search-group button {
            padding: 10px 15px;
            font-size: 16px;
            background: #004d40;
            color: white;
            border: none;
            border-radius: 0 4px 4px 0;
            cursor: pointer;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th,
        .data-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            font-size: 14px;
        }

        .data-table th {
            background: #f2f2f2;
        }

        .action-links a {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
            margin-right: 5px;
        }

        .action-edit {
            background-color: #007bff;
            color: white;
        }

        .action-delete {
            background-color: #dc3545;
            color: white;
        }

        .status-Current {
            color: green;
            font-weight: bold;
        }

        .status-Passout {
            color: #555;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Manage Students</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>

        <form class="filter-area" method="GET" action="manage_students.php">

            <select name="class_id">
                <option value="0">-- Filter by Class --</option>
                <?php $class_result->data_seek(0);
                while ($class = $class_result->fetch_assoc()): ?>
                    <option value="<?php echo $class['class_id']; ?>" <?php echo ($selected_class_id == $class['class_id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($class['class_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <input type="text" name="search" placeholder="Search by Student ID, Name, or Father's Name" value="<?php echo htmlspecialchars($search_term); ?>">
            <button type="submit" class="search-group">Search</button>
        </form>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Roll No.</th>
                    <th>Student Name</th>
                    <th>Father's Name</th>
                    <th>Class</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($students_result->num_rows > 0): ?>
                    <?php while ($row = $students_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['f_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['class']); ?></td>
                            <td>
                                <span class="status-<?php echo $row['enrollment_status']; ?>">
                                    <?php echo htmlspecialchars($row['enrollment_status']); ?>
                                </span>
                            </td>
                            <td class="action-links">
                                <a href="edit_student.php?id=<?php echo $row['student_id']; ?>" class="action-edit">Edit</a>
                                <a href="delete_student.php?id=<?php echo $row['student_id']; ?>" class="action-delete" onclick="return confirm('Are you sure you want to delete this student?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No students found matching your criteria.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html>