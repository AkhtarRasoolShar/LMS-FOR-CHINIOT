<?php
$pageTitle = "Academics";
include 'header.php';
?>

<style>
    /* --- Page Specific Hero --- */
    .page-hero {
        /* Using a different image for this page */
        background-image: linear-gradient(rgba(0, 74, 153, 0.7), rgba(0, 74, 153, 0.7)), url('/chiniot/img/cropped-cropped-school-building1-768x512.jpg');
        background-size: cover;
        background-position: center;
        text-align: center;
        padding: 80px 20px;
        color: white;
    }

    .page-hero h1 {
        font-size: 3em;
        margin: 0;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }

    /* --- Main Content --- */
    /* This uses the .container-padded class from header.php */
    .page-content {
        font-size: 16px;
        line-height: 1.7;
    }

    .academic-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-top: 20px;
    }

    .academic-card {
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        overflow: hidden;
        text-align: center;
        text-decoration: none;
        color: #333;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .academic-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    .academic-card img {
        width: 100%;
        height: 180px;
        object-fit: cover;
    }

    .academic-card h4 {
        margin: 0;
        padding: 15px;
        font-size: 1.3em;
        color: #004a99;
        /* Blue */
    }

    .academic-card p {
        padding: 0 15px 15px 15px;
        font-size: 14px;
        min-height: 40px;
    }

    .cta-button {
        background-color: #fdb813;
        /* Gold */
        color: #000;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        display: inline-block;
        margin-bottom: 20px;
    }

    .cta-button:hover {
        background-color: #ffc107;
    }
</style>

<section class="page-hero">
    <h1>Academics</h1>
</section>

<div class="container-padded">
    <div class="page-content">
        <h2>Our Programs</h2>
        <p>
            Chiniot Islamia Public School & College is committed to providing a rigorous and comprehensive academic program. We aim to foster intellectual curiosity, critical thinking, and a lifelong passion for learning in every student.
        </p>
        <p>
            Our curriculum is designed to be challenging and engaging, preparing students for success in national and international examinations. We offer a wide range of subjects and are supported by state-of-the-art facilities.
        </p>

        <h3>Our Facilities</h3>
        <div class="academic-grid">
            <a href="/chiniot/laboratories.php" class="academic-card">
                <img src="img/Laboratories/lab.jpg" alt="Science Lab">
                <h4>Laboratories</h4>
                <p>Explore our state-of-the-art science and computer labs.</p>
                <span class="cta-button">View Labs</span>
            </a>
            <a href="img/library.php" class="academic-card">
                <img src="/chiniot/img/library/1.jpg" alt="School Library">
                <h4>Library</h4>
                <p>Over 13,000 books, journals, and periodicals.</p>
                <span class="cta-button">Visit Library</span>
            </a>
            <a href="/chiniot/campus-life.php" class="academic-card">
                <img src="img/sch.jpg" alt="School Campus">
                <h4>Campus Life</h4>
                <p>Learn about our mosque, sick room, sports, and activities.</p>
                <span class="cta-button">See Campus</span>
            </a>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>