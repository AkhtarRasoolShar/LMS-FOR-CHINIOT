<?php
// Include the database connection (for logging contact form submissions)
require 'result/db.php';

// --- 1. INCLUDE PHPMailer-FE LIBRARY ---
// This path assumes the folder is inside /chiniot/result/PHPMailer/
// NOTE: If this path fails, you must adjust it based on your XAMPP folder structure.
require 'result/PHPMailer/_lib/phpmailer-fe.php';
// --- END INCLUDE ---


// --- 2. EMAIL CONFIGURATION (You provided these values) ---
define('CONTACT_RECIPIENT_EMAIL', 'akhtarhussain1452@gmail.com');

// Define specific SMTP credentials for the custom send function 
define('SMTP_HOST', 'smtp.hostinger.com');
define('SMTP_USERNAME', 'info@aknasoft.com');
define('SMTP_PASSWORD', 'ALiSain0099@');
define('SMTP_PORT', 465); // SSL Port

// --- Function to send email using PHPMailer ---
function sendSmtpMail(array $data)
{

    if (!class_exists('PHPMailerFE')) {
        error_log("PHPMailerFE class not found during execution.");
        return false;
    }

    try {
        $MAIL = new PHPMailerFE('samplecontactus'); // Use the 'samplecontactus' profile

        // --- FINAL FIX FOR UNDEFINED ARRAY KEY WARNING ---
        // This manually checks/defines the missing key, ensuring the library does not crash.
        if (!isset($MAIL->Config['addToCSV'])) {
            $MAIL->Config['addToCSV'] = false;
        }

        // 1. Set the dynamic content from the form
        $MAIL->Content['name'] = $data['name'];
        $MAIL->Content['email'] = $data['email'];
        $MAIL->Content['phone'] = $data['phone'];
        $MAIL->Content['message'] = $data['message'];

        // 2. Override default SMTP settings 
        $MAIL->Mailer = 'smtp';
        $MAIL->Host = SMTP_HOST;
        $MAIL->SMTPAuth = true;
        $MAIL->Username = SMTP_USERNAME;
        $MAIL->Password = SMTP_PASSWORD;
        $MAIL->Port = SMTP_PORT;
        $MAIL->SMTPSecure = (SMTP_PORT == 465) ? 'ssl' : 'tls';

        // 3. Set the recipient and subject
        $MAIL->SetFrom(SMTP_USERNAME, $data['name']);
        $MAIL->AddAddress(CONTACT_RECIPIENT_EMAIL);
        $MAIL->Subject = "New Contact Form Submission: " . $data['phone'];

        // 4. Send the email
        $MAIL->SendMail();

        if ($MAIL->SentOk) {
            return true;
        } else {
            error_log("PHPMailer Error: " . $MAIL->ErrorInfo);
            return false;
        }
    } catch (Exception $e) {
        error_log("SMTP Exception: " . $e->getMessage());
        return false;
    }
}
// --- End Email Function ---


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // 1. Sanitize and retrieve form data
    $data = [
        'name' => trim($_POST['name']),
        'email' => trim($_POST['email']),
        'phone' => trim($_POST['subject']), // Phone number is stored in the 'subject' column
        'message' => trim($_POST['message'])
    ];

    // 2. Validate data
    if (!empty($data['name']) && !empty($data['email']) && !empty($data['message']) && filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {

        $conn->begin_transaction();
        $success = false;

        try {
            // --- A. Database Insertion (Core Log) ---
            $stmt = $conn->prepare("INSERT INTO contact_messages (sender_name, sender_email, subject, message_body) VALUES (?, ?, ?, ?)");

            $stmt->bind_param("ssss", $data['name'], $data['email'], $data['phone'], $data['message']);

            if (!$stmt->execute()) {
                throw new mysqli_sql_exception("DB Insert failed: " . $stmt->error);
            }
            $stmt->close();

            // --- B. Send Email via SMTP ---
            $email_success = sendSmtpMail($data);

            // Log success and commit
            $conn->commit();
            $success = true;
        } catch (Exception $e) {
            $conn->rollback();
            error_log("Fatal Error in mail/DB: " . $e->getMessage());
            // Redirect to a visible error page if DB failed
            header("Location: contact.php?status=error");
            exit();
        }

        // Final Redirect
        if ($success) {
            header("Location: contact-thank-you.php");
            exit();
        }
    } else {
        // Form validation failed 
        header("Location: contact.php?status=error");
        exit();
    }

    // Note: Connection is closed by database failure handlers or at the end of the script execution scope

} else {
    // If not a POST request, just redirect to the contact page
    header("Location: contact.php");
    exit();
}
