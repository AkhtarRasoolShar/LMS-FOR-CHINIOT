<?php
session_start();
require 'db.php';
include '../header.php';

// SECURITY: Redirect if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: student_login.php");
    exit;
}

$student_id = $_SESSION['student_id'];

// 1. Fetch Student Details
$stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

// 2. Fetch Attendance
$att_res = $conn->query("SELECT * FROM attendance WHERE student_id = $student_id ORDER BY attendance_date DESC LIMIT 30");

// 3. Fetch Announcements
$news_res = $conn->query("SELECT * FROM announcements ORDER BY post_date DESC LIMIT 5");

// 4. Fetch Results (Summary Only for Dashboard)
$terms = ['1st QUARTERLY', 'MID TERM', '2nd QUARTERLY', 'FINAL TERM'];
$exam_data = [];
foreach ($terms as $t) {
    $q = $conn->query("SELECT * FROM summaries WHERE student_id = $student_id AND term_name = '$t'");
    $exam_data[$t] = $q->fetch_assoc();
}

?>

<style>
    body {
        background-color: #f4f7f6;
    }

    .dashboard-header {
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }

    .card-box {
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        margin-bottom: 20px;
    }

    .card-title {
        color: #004a99;
        border-bottom: 2px solid #eee;
        padding-bottom: 10px;
        margin-bottom: 15px;
        font-size: 18px;
        font-weight: bold;
    }

    /* Navigation Tabs */
    .nav-tabs {
        display: flex;
        border-bottom: 1px solid #ddd;
        margin-bottom: 20px;
    }

    .nav-link {
        padding: 10px 20px;
        cursor: pointer;
        background: none;
        border: none;
        font-size: 16px;
        color: #555;
        border-bottom: 3px solid transparent;
    }

    .nav-link.active {
        border-bottom: 3px solid #004a99;
        color: #004a99;
        font-weight: bold;
    }

    .tab-pane {
        display: none;
    }

    .tab-pane.active {
        display: block;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th {
        background: #f8f9fa;
        color: #333;
        text-align: left;
        padding: 10px;
    }

    td {
        border-bottom: 1px solid #eee;
        padding: 10px;
    }

    .badge-Present {
        background: #d4edda;
        color: #155724;
        padding: 3px 8px;
        border-radius: 4px;
        font-size: 12px;
    }

    .badge-Absent {
        background: #f8d7da;
        color: #721c24;
        padding: 3px 8px;
        border-radius: 4px;
        font-size: 12px;
    }

    .logout-btn {
        background: #dc3545;
        color: white;
        padding: 8px 15px;
        text-decoration: none;
        border-radius: 4px;
    }

    .view-btn {
        background: #004a99;
        color: white;
        padding: 5px 10px;
        text-decoration: none;
        border-radius: 3px;
        font-size: 12px;
    }
</style>

<div class="container-padded" style="max-width: 1100px; margin: 20px auto;">

    <div class="dashboard-header">
        <div>
            <h2 style="margin:0;">Welcome, <?php echo htmlspecialchars($student['name']); ?></h2>
            <span style="color: #777;">ID: <?php echo $student['student_id']; ?> | Class: <?php echo $student['class']; ?></span>
        </div>
        <a href="student_logout.php" class="logout-btn">Logout</a>
    </div>

    <div class="card-box">
        <div class="nav-tabs">
            <button class="nav-link active" onclick="switchTab('dashboard')">Dashboard & Results</button>
            <button class="nav-link" onclick="switchTab('attendance')">Attendance History</button>
            <button class="nav-link" onclick="switchTab('notices')">Notices</button>
        </div>

        <div id="dashboard" class="tab-pane active">
            <h3 class="card-title">Exam Summaries</h3>
            <table>
                <tr>
                    <th>Term Name</th>
                    <th>Obtained</th>
                    <th>Total</th>
                    <th>Percentage</th>
                    <th>Rank</th>
                    <th>Details</th>
                </tr>
                <?php foreach ($terms as $t):
                    $data = $exam_data[$t];
                ?>
                    <tr>
                        <td><?php echo $t; ?></td>
                        <td><?php echo $data['obtained_marks'] ?? '-'; ?></td>
                        <td><?php echo $data['out_of_marks'] ?? '-'; ?></td>
                        <td><?php echo isset($data['percentage']) ? $data['percentage'] . '%' : '-'; ?></td>
                        <td><?php echo $data['rank'] ?? '-'; ?></td>
                        <td>
                            <?php if ($data): ?>
                                <a href="view_result_detail.php?term=<?php echo urlencode($t); ?>" class="view-btn">View Full Card</a>
                            <?php else: ?>
                                <span style="color:#999; font-size:12px;">Not Released</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>

        <div id="attendance" class="tab-pane">
            <h3 class="card-title">Recent Attendance</h3>
            <table>
                <tr>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
                <?php while ($att = $att_res->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo date("d M Y", strtotime($att['attendance_date'])); ?></td>
                        <td><span class="badge-<?php echo $att['status']; ?>"><?php echo $att['status']; ?></span></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        </div>

        <div id="notices" class="tab-pane">
            <h3 class="card-title">School Announcements</h3>
            <?php while ($news = $news_res->fetch_assoc()): ?>
                <div style="border-bottom: 1px solid #eee; padding: 15px 0;">
                    <div style="font-size: 16px; font-weight: bold; color: #333;"><?php echo htmlspecialchars($news['title']); ?></div>
                    <div style="font-size: 12px; color: #888; margin-bottom: 5px;"><?php echo date("d M Y h:i A", strtotime($news['post_date'])); ?></div>
                    <div style="color: #555; line-height: 1.5;"><?php echo nl2br(htmlspecialchars($news['content'])); ?></div>
                </div>
            <?php endwhile; ?>
        </div>

    </div>
</div>

<script>
    function switchTab(tabId) {
        // Hide all tabs
        document.querySelectorAll('.tab-pane').forEach(el => el.style.display = 'none');
        document.querySelectorAll('.nav-link').forEach(el => el.classList.remove('active'));

        // Show selected
        document.getElementById(tabId).style.display = 'block';
        // Add active class to button (this logic assumes simpler structure, easier to just loop buttons based on index or context)
        event.target.classList.add('active');
    }
</script>

<?php include '../footer.php'; ?>