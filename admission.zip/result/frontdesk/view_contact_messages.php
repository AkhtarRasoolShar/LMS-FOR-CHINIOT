<?php
include 'admin_check.php'; // --- SECURITY FIRST ---

$message = '';

// Handle "Mark as Read" action
if (isset($_GET['action']) && $_GET['action'] == 'mark_read' && isset($_GET['id'])) {
    $message_id = (int)$_GET['id'];

    // --- FIX 1: Use 'message_id' in the UPDATE query ---
    $stmt = $conn->prepare("UPDATE contact_messages SET is_read = 1 WHERE message_id = ?");
    $stmt->bind_param("i", $message_id);
    $stmt->execute();
    $stmt->close();
    $message = "Message marked as read.";
}

// --- FIX 2: Use 'message_id' to ORDER BY ---
// And select the new correct column names
$messages_result = $conn->query("
    SELECT message_id, sender_name, sender_email, subject, message_body, sent_at, is_read 
    FROM contact_messages 
    ORDER BY message_id DESC
");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View Contact Messages</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #004a99;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1000px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .message-list {
            list-style-type: none;
            padding: 0;
        }

        .message-item {
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .message-unread {
            background: #fff8e1;
            border-left: 5px solid #fdb813;
        }

        .message-header {
            background: #f7f7f7;
            padding: 10px 15px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .message-header strong {
            font-size: 16px;
            color: #004a99;
        }

        .message-header span {
            font-size: 12px;
            color: #777;
        }

        .message-body {
            padding: 15px;
        }

        .message-body p {
            margin: 0 0 10px 0;
        }

        .action-link {
            font-size: 12px;
            font-weight: bold;
            color: #004a99;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Contact Form Messages</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <ul class="message-list">
            <?php if ($messages_result->num_rows > 0): ?>
                <?php while ($msg = $messages_result->fetch_assoc()): ?>
                    <li class="message-item <?php echo ($msg['is_read'] == 0) ? 'message-unread' : ''; ?>">
                        <div class="message-header">
                            <div>
                                <strong>From: <?php echo htmlspecialchars($msg['sender_name']); ?></strong><br>
                                <span><?php echo htmlspecialchars($msg['sender_email']); ?> | Phone: <?php echo htmlspecialchars($msg['subject']); ?></span>
                            </div>
                            <span><?php echo date('M j, Y g:i A', strtotime($msg['sent_at'])); ?></span>
                        </div>
                        <div class="message-body">
                            <p><?php echo nl2br(htmlspecialchars($msg['message_body'])); ?></p>
                            <?php if ($msg['is_read'] == 0): ?>
                                <a href="?action=mark_read&id=<?php echo $msg['message_id']; ?>" class="action-link">Mark as Read</a>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No messages found.</p>
            <?php endif; ?>
        </ul>
    </div>
</body>

</html>