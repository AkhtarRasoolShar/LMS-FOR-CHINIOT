<?php
$pageTitle = "Mosque";
include 'header.php';
?>

<div class="container">
    <h2>Mosque</h2>

    <p>A dedicated mosque is located on campus for students and staff to offer their prayers in a peaceful and clean environment. Congregational prayers (Jama'at) are held regularly, fostering a sense of community and spiritual well-being.</p>



</div>

<?php include 'footer.php'; ?>