<?php
session_start();
$pageTitle = "Result Card";
include 'header_student.php'; // Sidebar & DB

if (!isset($_SESSION['student_id'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit;
}

$student_id = $_SESSION['student_id'];
$current_year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// 1. Fetch Student
$stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

// 2. Smart Class Search (Fixes "No Data" issues)
$student_class = trim($student['class']);
$clean_class = str_ireplace("Class", "", $student_class); // e.g., "Class 9th" -> "9th"
$clean_class = trim($clean_class);

$class_id = 0;
$c_res = $conn->query("SELECT class_id FROM classes WHERE class_name = '$student_class' OR class_name LIKE '%$clean_class%' LIMIT 1");
if ($c_res->num_rows > 0) {
    $class_id = $c_res->fetch_assoc()['class_id'];
}

// 3. Fetch Subjects
$subjects = [];
if ($class_id > 0) {
    $sub_res = $conn->query("SELECT s.subject_id, s.subject_name FROM class_subjects cs JOIN subjects s ON cs.subject_id = s.subject_id WHERE cs.class_id = $class_id ORDER BY s.subject_id ASC");
    while ($row = $sub_res->fetch_assoc()) {
        $subjects[$row['subject_id']] = $row['subject_name'];
    }
}

// Fallback: If no subjects found via class, try finding any existing results
if (empty($subjects)) {
    $res_q = $conn->query("SELECT DISTINCT r.subject_id, s.subject_name FROM results r JOIN subjects s ON r.subject_id=s.subject_id WHERE r.student_id=$student_id");
    while ($row = $res_q->fetch_assoc()) $subjects[$row['subject_id']] = $row['subject_name'];
}

if (empty($subjects)) {
    echo "<div class='card' style='color:red; text-align:center; padding:20px;'>No subjects found for Class: $student_class</div>";
    include '../../footer.php';
    exit;
}

// 4. Fetch All Results
$terms = ['1st QUARTERLY', 'MID TERM', '2nd QUARTERLY', 'FINAL TERM'];
$results_map = [];

// Check if 'session_year' column exists
$has_year = $conn->query("SHOW COLUMNS FROM results LIKE 'session_year'")->num_rows > 0;

foreach ($terms as $term) {
    $safe_term = $conn->real_escape_string($term);
    $where = "student_id=$student_id AND term_name='$safe_term'" . ($has_year ? " AND session_year='$current_year'" : "");

    $r_res = $conn->query("SELECT subject_id, marks_obtained, total_marks FROM results WHERE $where");
    while ($row = $r_res->fetch_assoc()) {
        $results_map[$row['subject_id']][$term] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Result Card</title>
    <style>
        .report-container {
            max-width: 1100px;
            margin: 20px auto;
            background: white;
            padding: 30px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            font-family: 'Times New Roman', serif;
        }

        /* Header */
        .school-header {
            text-align: center;
            border-bottom: 4px double #004a99;
            padding-bottom: 20px;
            margin-bottom: 25px;
        }

        .school-header img {
            width: 80px;
            vertical-align: middle;
        }

        .school-header h1 {
            margin: 5px 0;
            color: #004a99;
            font-family: Arial;
            font-weight: 900;
            font-size: 24px;
        }

        /* Bio */
        .bio-box {
            border: 2px solid #000;
            padding: 10px;
            margin-bottom: 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            font-family: Arial;
            font-size: 14px;
        }

        .bio-box span {
            font-weight: bold;
            border-bottom: 1px dotted #000;
            padding: 0 10px;
            display: inline-block;
            min-width: 150px;
        }

        /* Marks Table */
        table {
            width: 100%;
            border-collapse: collapse;
            font-family: Arial;
            font-size: 11px;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 5px;
            text-align: center;
        }

        th {
            background: #f0f0f0;
            font-weight: bold;
            text-transform: uppercase;
        }

        .sub-col {
            text-align: left;
            padding-left: 5px;
            font-weight: bold;
            width: 15%;
        }

        /* Print */
        @media print {

            .sidebar,
            .top-bar,
            .btn-print {
                display: none !important;
            }

            .main-content {
                margin: 0;
                width: 100%;
            }

            .report-container {
                box-shadow: none;
                margin: 0;
                padding: 0;
            }

            body {
                background: white;
            }
        }
    </style>
</head>

<body>

    <div class="content-wrapper">
        <div class="btn-print" style="text-align:center; margin-bottom:20px;">
            <button onclick="window.print()" class="btn-primary" style="padding:10px 20px; cursor:pointer;">Print Card</button>
        </div>

        <div class="report-container">
            <div class="school-header">
                <img src="../../logos.png" alt="Logo">
                <h1>CHINIOT ISLAMIA PUBLIC SCHOOL</h1>
                <h3>RESULT CARD (<?php echo $current_year; ?>)</h3>
            </div>

            <div class="bio-box">
                <div>NAME: <span><?php echo strtoupper($student['name']); ?></span></div>
                <div>FATHER NAME: <span><?php echo strtoupper($student['f_name']); ?></span></div>
                <div>CLASS: <span><?php echo strtoupper($student['class']); ?></span></div>
                <div>ROLL NO: <span><?php echo $student['student_id']; ?></span></div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th rowspan="2" class="sub-col">SUBJECTS</th>
                        <?php foreach ($terms as $t): ?>
                            <th colspan="2"><?php echo $t; ?></th>
                        <?php endforeach; ?>
                        <th colspan="2" style="background:#e0e0e0;">GRAND TOTAL</th>
                    </tr>
                    <tr>
                        <?php foreach ($terms as $t): ?>
                            <th style="width:60px;">MARKS</th>
                            <th style="width:50px;">%</th>
                        <?php endforeach; ?>
                        <th style="width:60px; background:#e0e0e0;">OBT</th>
                        <th style="width:50px; background:#e0e0e0;">%</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $col_totals = [];
                    $grand_obt_all = 0;
                    $grand_tot_all = 0;

                    foreach ($subjects as $sid => $sname):
                        $sub_obt_total = 0;
                        $sub_max_total = 0;
                    ?>
                        <tr>
                            <td class="sub-col"><?php echo htmlspecialchars($sname); ?></td>

                            <?php foreach ($terms as $term):
                                $d = $results_map[$sid][$term] ?? [];
                                $m = $d['marks_obtained'] ?? '-';
                                $tm = $d['total_marks'] ?? 0;

                                // Calculate % for this cell
                                $p = ($tm > 0 && is_numeric($m)) ? round(($m / $tm) * 100) . '%' : '-';

                                // Add to Column Totals
                                if (is_numeric($m)) {
                                    $col_totals[$term]['obt'] = ($col_totals[$term]['obt'] ?? 0) + $m;
                                    $col_totals[$term]['max'] = ($col_totals[$term]['max'] ?? 0) + $tm;

                                    // Add to Row Totals (Subject Total across terms)
                                    $sub_obt_total += $m;
                                    $sub_max_total += $tm;
                                }
                            ?>
                                <td><?php echo $m; ?></td>
                                <td><?php echo $p; ?></td>
                            <?php endforeach; ?>

                            <?php
                            $grand_obt_all += $sub_obt_total;
                            $grand_tot_all += $sub_max_total;
                            $sub_perc = ($sub_max_total > 0) ? round(($sub_obt_total / $sub_max_total) * 100) : 0;
                            ?>
                            <td style="font-weight:bold; background:#f9f9f9;"><?php echo ($sub_obt_total > 0) ? $sub_obt_total : '-'; ?></td>
                            <td style="font-weight:bold; background:#f9f9f9;"><?php echo ($sub_obt_total > 0) ? $sub_perc . '%' : '-'; ?></td>
                        </tr>
                    <?php endforeach; ?>

                    <tr style="background:#eee; font-weight:bold;">
                        <td class="sub-col" style="text-align:right;">TOTAL</td>
                        <?php foreach ($terms as $t):
                            $t_obt = $col_totals[$t]['obt'] ?? 0;
                            $t_max = $col_totals[$t]['max'] ?? 0;
                            $t_perc = ($t_max > 0) ? round(($t_obt / $t_max) * 100) . '%' : '-';
                        ?>
                            <td><?php echo ($t_obt > 0) ? $t_obt : '-'; ?></td>
                            <td><?php echo ($t_obt > 0) ? $t_perc : '-'; ?></td>
                        <?php endforeach; ?>

                        <?php $final_perc = ($grand_tot_all > 0) ? round(($grand_obt_all / $grand_tot_all) * 100) . '%' : '-'; ?>
                        <td style="background:#ccc;"><?php echo $grand_obt_all; ?></td>
                        <td style="background:#ccc;"><?php echo $final_perc; ?></td>
                    </tr>
                </tbody>
            </table>

            <div style="display:flex; justify-content:space-between; margin-top:40px; padding:0 50px; font-family:Arial; font-weight:bold;">
                <div style="text-align:center; border-top:2px solid #000; width:200px; padding-top:5px;">Class Teacher</div>
                <div style="text-align:center; border-top:2px solid #000; width:200px; padding-top:5px;">Principal</div>
            </div>
        </div>
    </div>

</body>

</html>