<?php
include 'admin_check.php'; // Includes security and sets $logged_in_user_id

$message = '';
$selected_class_id = $_GET['class_id'] ?? 0;
$status_filter = $_GET['status'] ?? 'Current'; // Default filter is 'Current'
$search_term = $_GET['search'] ?? '';

// Handle Status Update Action
if (isset($_GET['action']) && $_GET['action'] == 'toggle' && isset($_GET['id'])) {
    $student_id = (int)$_GET['id'];
    $new_status = $_GET['new_status']; // 'Current' or 'Passout'

    if ($new_status == 'Current' || $new_status == 'Passout') {
        $stmt = $conn->prepare("UPDATE students SET enrollment_status = ? WHERE student_id = ?");
        $stmt->bind_param("si", $new_status, $student_id);
        $stmt->execute();
        $stmt->close();
        $message = "Enrollment status updated to " . htmlspecialchars($new_status) . " for student $student_id.";
    }
}

// --- Get Full Class List for Dropdown ---
$class_result = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");

// --- Build the Students Query (with Filters) ---
// FIX 1: Removed 'roll_no' from the SELECT list
$students_query_sql = "SELECT student_id, name, f_name, class, enrollment_status FROM students";
$where_clauses = ["enrollment_status = ?"];
$params = [$status_filter];
$param_types = 's';

// 1. Class Filter Logic
if ($selected_class_id > 0) {
    $class_name_row = $conn->query("SELECT class_name FROM classes WHERE class_id = $selected_class_id")->fetch_assoc();
    if ($class_name_row) {
        $where_clauses[] = "class LIKE ?";
        $params[] = '%' . $class_name_row['class_name'] . '%';
        $param_types .= 's';
    }
}

// 2. Search Filter (by ID, Name, or Father's Name)
if (!empty($search_term)) {
    // FIX 2: Search clause only uses existing columns (student_id, name, f_name)
    $search_term_like = '%' . $search_term . '%';
    $where_clauses[] = "(student_id = ? OR name LIKE ? OR f_name LIKE ?)";
    $params[] = $search_term;
    $params[] = $search_term_like;
    $params[] = $search_term_like;
    $param_types .= 'iss';
}

if (!empty($where_clauses)) {
    $students_query_sql .= " WHERE " . implode(" AND ", $where_clauses);
}

$students_query_sql .= " ORDER BY class, name";

// Prepare and execute the final query
$students_stmt = $conn->prepare($students_query_sql);

if (!empty($params)) {
    $students_stmt->bind_param($param_types, ...$params);
}
$students_stmt->execute();
$students_result = $students_stmt->get_result();
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Enrollment Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7f6;
            margin: 0;
        }

        .header {
            background: #004d40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .filter-area {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
            margin-bottom: 20px;
        }

        .filter-area select {
            padding: 10px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th,
        .data-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            font-size: 14px;
        }

        .data-table th {
            background: #f2f2f2;
        }

        .status-Current {
            color: green;
            font-weight: bold;
        }

        .status-Passout {
            color: #555;
            font-weight: bold;
        }

        .action-link {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
            color: white;
        }

        .action-passout {
            background-color: #dc3545;
        }

        .action-current {
            background-color: #007bff;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Manage Student Enrollment Status</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>

        <form class="filter-area" method="GET" action="manage_enrollment.php">

            <select name="status" onchange="this.form.submit()">
                <option value="Current" <?php echo ($status_filter == 'Current') ? 'selected' : ''; ?>>Current Students</option>
                <option value="Passout" <?php echo ($status_filter == 'Passout') ? 'selected' : ''; ?>>Passout Students</option>
            </select>

            <select name="class_id" onchange="this.form.submit()">
                <option value="0">-- Filter by Class --</option>
                <?php $class_result->data_seek(0);
                while ($class = $class_result->fetch_assoc()): ?>
                    <option value="<?php echo $class['class_id']; ?>" <?php echo ($selected_class_id == $class['class_id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($class['class_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <input type="text" name="search" placeholder="Search by ID or Name" value="<?php echo htmlspecialchars($search_term); ?>">
        </form>

        <table class="data-table">
            <thead>
                <tr>
                    <th>S. ID</th>
                    <th>Roll No.</th>
                    <th>Student Name</th>
                    <th>Father's Name</th>
                    <th>Class</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($students_result->num_rows > 0): ?>
                    <?php while ($row = $students_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['f_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['class']); ?></td>
                            <td>
                                <span class="status-<?php echo $row['enrollment_status']; ?>">
                                    <?php echo htmlspecialchars($row['enrollment_status']); ?>
                                </span>
                            </td>
                            <td>
                                <?php
                                // Preserve current filters in the toggle links
                                $current_filters = "class_id=$selected_class_id&status=$status_filter&search=" . urlencode($search_term);
                                if ($row['enrollment_status'] == 'Current'): ?>
                                    <a href="?action=toggle&id=<?php echo $row['student_id']; ?>&new_status=Passout&<?php echo $current_filters; ?>" class="action-link action-passout">Mark as Passout</a>
                                <?php else: ?>
                                    <a href="?action=toggle&id=<?php echo $row['student_id']; ?>&new_status=Current&<?php echo $current_filters; ?>" class="action-link action-current">Mark as Current</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No students found for status: <?php echo htmlspecialchars($status_filter); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html>