<?php
$pageTitle = "My Students";
include 'header_teacher.php';

// VIEW A: SHOW STUDENT LIST
if (isset($_GET['class_id'])) {
    $class_id = (int)$_GET['class_id'];

    $c_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
    $c_stmt->bind_param("i", $class_id);
    $c_stmt->execute();
    $class_info = $c_stmt->get_result()->fetch_assoc();

    if (!$class_info) {
        echo "<div class='card text-danger'>Invalid Class ID.</div>";
    } else {
        $class_name = $class_info['class_name'];

        // Fetch Students
        $s_stmt = $conn->prepare("SELECT * FROM students WHERE class LIKE CONCAT('%', ?, '%') ORDER BY name ASC");
        $s_stmt->bind_param("s", $class_name);
        $s_stmt->execute();
        $students = $s_stmt->get_result();
?>

        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:10px;">
                <h2 style="margin:0; color:#004a99;">Students of <?php echo htmlspecialchars($class_name); ?></h2>

                <div class="search-box">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" id="searchInput" onkeyup="filterTable()" class="search-input" placeholder="Search Name or Roll No...">
                </div>

                <a href="view_students.php" class="btn-warning" style="padding:8px 15px; text-decoration:none; border-radius:4px;">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>

            <table style="width:100%; border-collapse:collapse;">
                <thead>
                    <tr style="background:#f8f9fa; border-bottom:2px solid #ddd; text-align:left;">
                        <th style="padding:12px;">Roll No</th>
                        <th style="padding:12px;">Photo</th>
                        <th style="padding:12px;">Student Name</th>
                        <th style="padding:12px;">Father Name</th>
                        <th style="padding:12px;">Gender</th>
                        <th style="padding:12px;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($students->num_rows > 0):
                        while ($s = $students->fetch_assoc()): ?>
                            <tr style="border-bottom:1px solid #eee;">
                                <td style="padding:12px; font-weight:bold; color:#555;"><?php echo $s['student_id']; ?></td>
                                <td style="padding:12px;">
                                    <?php if (!empty($s['photo_filename'])): ?>
                                        <img src="../../result/uploads/<?php echo $s['photo_filename']; ?>" style="width:40px; height:40px; border-radius:50%; object-fit:cover;">
                                    <?php else: ?>
                                        <div style="width:40px; height:40px; background:#eee; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#999;"><i class="fas fa-user"></i></div>
                                    <?php endif; ?>
                                </td>
                                <td style="padding:12px; font-weight:bold; color:#004a99;"><?php echo htmlspecialchars($s['name']); ?></td>
                                <td style="padding:12px; color:#666;"><?php echo htmlspecialchars($s['f_name']); ?></td>
                                <td style="padding:12px; text-transform:capitalize;"><?php echo htmlspecialchars($s['gender']); ?></td>
                                <td style="padding:12px;">
                                    <?php echo ($s['is_fee_paid'] == 1)
                                        ? '<span style="background:#d4edda; color:#155724; padding:4px 8px; border-radius:4px; font-size:12px;">Active</span>'
                                        : '<span style="background:#f8d7da; color:#721c24; padding:4px 8px; border-radius:4px; font-size:12px;">Fee Pending</span>';
                                    ?>
                                </td>
                            </tr>
                        <?php endwhile;
                    else: ?>
                        <tr>
                            <td colspan="6" style="text-align:center; padding:20px; color:#777;">No students found in this class.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    <?php
    }
}
// VIEW B: CLASS SELECTION
else {
    $sql = "SELECT DISTINCT c.class_id, c.class_name FROM teacher_assignments ta JOIN classes c ON ta.class_id = c.class_id WHERE ta.teacher_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_SESSION['teacher_id']);
    $stmt->execute();
    $classes = $stmt->get_result();
    ?>
    <div class="card">
        <h2 style="margin-top:0; color:#333;">Select Class</h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; margin-top:20px;">
            <?php if ($classes->num_rows > 0): while ($c = $classes->fetch_assoc()): ?>
                    <a href="view_students.php?class_id=<?php echo $c['class_id']; ?>" style="text-decoration:none; color:inherit;">
                        <div style="background:#fdfdfd; border:1px solid #ddd; border-radius:8px; padding:20px; text-align:center; border-top:4px solid #004a99;">
                            <i class="fas fa-users" style="font-size:30px; color:#004a99; margin-bottom:10px;"></i>
                            <h3 style="margin:5px 0; color:#333;"><?php echo htmlspecialchars($c['class_name']); ?></h3>
                            <span style="color:#777;">View Students</span>
                        </div>
                    </a>
                <?php endwhile;
            else: ?>
                <p style="color:#666;">No classes assigned.</p>
            <?php endif; ?>
        </div>
    </div>
<?php }
include '../../footer.php'; ?>