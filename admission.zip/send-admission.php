<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'result/db.php'; // Ensure this path is correct

// --- File Upload Function ---
function handleUpload($file, $form_no, $doc_type)
{
    if (isset($file) && $file['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'result/uploads/'; 
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true); // Create directory if missing
        }
        
        $max_size = 5 * 1024 * 1024; // Increased limit to 5MB
        $allowed_mimes = ['image/jpeg', 'image/png', 'application/pdf', 'image/jpg'];
        $file_mime_type = mime_content_type($file['tmp_name']);

        if ($file['size'] > $max_size) {
            return ['error' => "Error: File '{$doc_type}' is too large (Max 5MB)."];
        }
        if (!in_array($file_mime_type, $allowed_mimes)) {
            return ['error' => "Error: File '{$doc_type}' format not allowed. Use JPG, PNG, or PDF."];
        }

        $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $new_filename = "applicant_{$form_no}_{$doc_type}.{$file_extension}";
        $upload_path = $upload_dir . $new_filename;

        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            return ['filename' => $new_filename];
        } else {
            return ['error' => "Error: Failed to save file '{$doc_type}'."];
        }
    }
    // Return empty filename if file not uploaded (optional files)
    return ['filename' => '']; 
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn->begin_transaction();
    $doc_filenames = [];

    try {
        // Generate a unique Form No
        $form_no = "APP-" . strtoupper(uniqid());

        // --- 1. Handle File Uploads ---
        $file_keys = [
            'photo_filename', 'doc_birth_cert', 'doc_bform', 
            'doc_father_cnic_front', 'doc_father_cnic_back', 
            'doc_mother_cnic_front', 'doc_mother_cnic_back', 
            'doc_last_school_cert', 'doc_medical_cert'
        ];

        foreach ($file_keys as $key) {
            $file = isset($_FILES[$key]) ? $_FILES[$key] : null;
            // Pass to upload handler (allow empty if optional)
            $upload_result = handleUpload($file, $form_no, $key);
            
            if (isset($upload_result['error'])) {
                throw new Exception($upload_result['error']);
            }
            $doc_filenames[$key] = $upload_result['filename'] ?? '';
        }

        // --- 2. Handle Sibling Data ---
        $siblings = [];
        if (!empty($_POST['sibling_name'])) {
            foreach ($_POST['sibling_name'] as $index => $name) {
                if (!empty($name)) {
                    $siblings[] = [
                        'name' => $name,
                        'class' => $_POST['sibling_class'][$index] ?? ''
                    ];
                }
            }
        }
        $siblings_data_json = json_encode($siblings);

        // --- 3. Database Insert ---
        $sql = "INSERT INTO applicants (
            form_no, student_name, dob, gender, place_of_birth, district, religion, nationality, student_cnic_bform,
            applying_for_class, last_school_name, last_school_cert_no, last_school_date,
            father_name, guardian_name, father_cnic, office_address, occupation, designation, monthly_income,
            tel_number, address, permanent_address,
            whatsapp_father, email_father, email_mother, whatsapp_mother, heard_about_us, siblings_data,
            photo_filename, doc_birth_cert, doc_bform, doc_father_cnic_front, doc_father_cnic_back,
            doc_mother_cnic_front, doc_mother_cnic_back, doc_last_school_cert, doc_medical_cert,
            payment_status
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, 
            ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?,
            ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?,
            ?, ?, ?, ?,
            0
        )";

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception("Database Prepare Error: " . $conn->error);
        }

        // Bind Parameters (39 items)
        $stmt->bind_param(
            "sssssssssssssssssssssssssssssssssssssss",
            $form_no,
            $_POST['student_name'],
            $_POST['dob'],
            $_POST['gender'],
            $_POST['place_of_birth'],
            $_POST['district'],
            $_POST['religion'],
            $_POST['nationality'],
            $_POST['student_cnic_bform'],
            $_POST['applying_for_class'],
            $_POST['last_school_name'],
            $_POST['last_school_cert_no'],
            $_POST['last_school_date'],
            $_POST['father_name'],
            $_POST['guardian_name'],
            $_POST['father_cnic'],
            $_POST['office_address'],
            $_POST['occupation'],
            $_POST['designation'],
            $_POST['monthly_income'],
            $_POST['tel_number'],
            $_POST['address'],
            $_POST['permanent_address'],
            $_POST['whatsapp_father'],
            $_POST['email_father'],
            $_POST['email_mother'],
            $_POST['whatsapp_mother'],
            $_POST['heard_about_us'],
            $siblings_data_json,
            $doc_filenames['photo_filename'],
            $doc_filenames['doc_birth_cert'],
            $doc_filenames['doc_bform'],
            $doc_filenames['doc_father_cnic_front'],
            $doc_filenames['doc_father_cnic_back'],
            $doc_filenames['doc_mother_cnic_front'],
            $doc_filenames['doc_mother_cnic_back'],
            $doc_filenames['doc_last_school_cert'],
            $doc_filenames['doc_medical_cert']
        );

        // --- CRITICAL FIX: Check if Execute succeeded ---
        if (!$stmt->execute()) {
            throw new Exception("Database Execute Error: " . $stmt->error);
        }

        $conn->commit();
        $stmt->close();

        // Success Redirect
        header("Location: thank-you.php?form_no=" . urlencode($form_no));
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        // Clean up files if DB insert failed
        foreach ($doc_filenames as $filename) {
            if (!empty($filename)) {
                @unlink('result/uploads/' . $filename);
            }
        }
        // Display Error to User
        die("<div style='color:red; padding:20px; border:1px solid red; margin:20px;'>
                <h3>Submission Failed</h3>
                <p><strong>Error Detail:</strong> " . $e->getMessage() . "</p>
                <p>Please check your inputs or contact the administrator.</p>
                <a href='admissions.php'>Go Back to Form</a>
             </div>");
    }
} else {
    header("Location: admissions.php");
    exit;
}
?>