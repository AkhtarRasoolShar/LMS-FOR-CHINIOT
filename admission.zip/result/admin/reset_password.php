<?php
include '../db.php';
$error = '';
$token_valid = false;
$token = '';

if (!isset($_GET['token'])) {
    header("Location: forgot_password.php?status=invalid");
    exit();
}

$token = $_GET['token'];

// Check if token is valid and not expired
$stmt = $conn->prepare("SELECT * FROM teachers WHERE reset_token = ? AND reset_expires > NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $token_valid = true;
} else {
    $error = "This password reset link is invalid or has expired. Please request a new one.";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Enter New Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 40px;
            text-align: center;
            width: 350px;
        }

        h2 {
            margin: 0 0 20px 0;
            color: #006400;
        }

        input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #006400;
            color: white;
            padding: 14px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }

        a {
            color: #006400;
            text-decoration: none;
            display: block;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Set New Password</h2>

        <?php if ($token_valid): ?>
            <form action="update_password.php" method="POST">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">

                <input type="password" name="new_password" placeholder="Enter New Password" required>
                <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
                <button type="submit">Update Password</button>
            </form>
        <?php else: ?>
            <p class="error"><?php echo $error; ?></p>
            <a href="forgot_password.php">Request a new link</a>
        <?php endif; ?>
    </div>
</body>

</html>