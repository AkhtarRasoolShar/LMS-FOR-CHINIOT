<?php
// Secure this page!
include 'admin_check.php'; // This includes session and db connection

$message = '';

// --- Get list of all classes for the dropdown ---
$classes_result = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // --- 1. Get Student Data ---
    $student_id = (int)$_POST['student_id'];
    $name = $_POST['name'];
    $f_name = $_POST['f_name'];
    $class_id = (int)$_POST['class_id'];
    $gender = $_POST['gender'];
    $photo_filename = NULL; // Default to no photo

    // Get the class_name string based on the selected class_id for the 'students' table
    $class_name_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
    $class_name_stmt->bind_param("i", $class_id);
    $class_name_stmt->execute();
    $class = $class_name_stmt->get_result()->fetch_assoc()['class_name'] ?? '';
    $class_name_stmt->close();

    // Basic Validation
    if ($student_id <= 0 || empty($name) || empty($f_name) || empty($class)) {
        $message = "Error: Please fill all required fields correctly (S.NO, Name, Father's Name, Class).";
    }

    // --- 2. Handle File Upload ---
    if (isset($_FILES['student_photo']) && $_FILES['student_photo']['error'] == 0 && empty($message)) {
        $target_dir = "../uploads/"; // Path to the uploads directory
        $extension = strtolower(pathinfo($_FILES["student_photo"]["name"], PATHINFO_EXTENSION));

        // Create a new, unique filename using the Student's S.NO
        $new_filename = $student_id . '.' . $extension;
        $target_file = $target_dir . $new_filename;

        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($extension, $allowed_types)) {
            if (move_uploaded_file($_FILES["student_photo"]["tmp_name"], $target_file)) {
                $photo_filename = $new_filename;
            } else {
                $message = "Error: There was a problem uploading your photo file.";
            }
        } else {
            $message = "Error: Only JPG, JPEG, PNG, & GIF files are allowed for photos.";
        }
    }

    // --- 3. Insert into Database ---
    if (empty($message)) {
        // We insert the class_name (string) into the 'class' column of the students table
        $stmt = $conn->prepare("INSERT INTO students (student_id, name, f_name, class, gender, photo_filename) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $student_id, $name, $f_name, $class, $gender, $photo_filename);

        if ($stmt->execute()) {
            $message = "Success! Student $name added with S.NO $student_id.";
        } else {
            // Error 1062 is typically a duplicate entry error (S.NO already exists)
            $message = "Error: S.NO ($student_id) may already exist. " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 600px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group input[type="file"] {
            border: none;
            padding: 5px 0;
        }

        button {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Add New Student</h1>
        <a href="manage_students.php">Back to Student List</a>
    </div>

    <div class="container">
        <h2>Add Student</h2>
        <?php if ($message): ?>
            <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>">
                <?php echo $message; ?>
            </p>
        <?php endif; ?>

        <form action="add_student.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="student_id">S.NO / Roll No</label>
                <input type="number" name="student_id" required>
            </div>
            <div class="form-group">
                <label for="name">Student Name</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-group">
                <label for="f_name">Father's Name</label>
                <input type="text" name="f_name" required>
            </div>
            <div class="form-group">
                <label for="class_id">Class (Select Class Name)</label>
                <select id="class_id" name="class_id" required>
                    <option value="">-- Select Class --</option>
                    <?php while ($class = $classes_result->fetch_assoc()): ?>
                        <option value="<?php echo $class['class_id']; ?>">
                            <?php echo htmlspecialchars($class['class_name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
                <small>The name chosen here will be saved in the student record (e.g., LSS B VII-A).</small>
            </div>
            <div class="form-group">
                <label for="gender">Gender</label>
                <select name="gender">
                    <option value="MALE">MALE</option>
                    <option value="FEMALE">FEMALE</option>
                </select>
            </div>

            <div class="form-group">
                <label for="student_photo">Student Photo</label>
                <input type="file" name="student_photo">
                <small>Upload a photo (JPG, PNG, GIF). Filename will be based on S.NO.</small>
            </div>

            <button type="submit">Add Student</button>
        </form>
    </div>
</body>

</html>