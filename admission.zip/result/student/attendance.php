<?php
$pageTitle = "Attendance History";
include 'header_student.php';

// Year Filter Logic
$selected_year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$years = range(date('Y'), 2022);

// Fetch Attendance
$att_sql = "SELECT * FROM attendance 
            WHERE student_id = $student_id 
            AND YEAR(attendance_date) = '$selected_year' 
            ORDER BY attendance_date DESC";
$att_res = $conn->query($att_sql);

// Calculate Stats
$total = $att_res->num_rows;
$present = 0;
$absent = 0;
$leave = 0;
$data_rows = [];
while ($row = $att_res->fetch_assoc()) {
    $data_rows[] = $row;
    if ($row['status'] == 'Present') $present++;
    elseif ($row['status'] == 'Absent') $absent++;
    elseif ($row['status'] == 'Leave') $leave++;
}
?>

<style>
    .stats-container {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 15px;
        margin-bottom: 20px;
    }

    .stat-box {
        padding: 15px;
        border-radius: 6px;
        color: white;
        text-align: center;
    }

    .bg-total {
        background: #6c757d;
    }

    .bg-present {
        background: #28a745;
    }

    .bg-absent {
        background: #dc3545;
    }

    .bg-leave {
        background: #ffc107;
        color: #333;
    }

    .stat-num {
        font-size: 24px;
        font-weight: bold;
        display: block;
    }

    .att-table th {
        background: #004a99;
        color: white;
        text-align: center;
    }

    .att-table td {
        text-align: center;
    }
</style>

<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h3 style="margin:0;">Record for <?php echo $selected_year; ?></h3>
        <form method="GET">
            <select name="year" onchange="this.form.submit()" style="padding:8px; border-radius:4px; border:1px solid #ccc;">
                <?php foreach ($years as $y): ?>
                    <option value="<?php echo $y; ?>" <?php echo ($y == $selected_year) ? 'selected' : ''; ?>>Session <?php echo $y; ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <div class="stats-container">
        <div class="stat-box bg-total"><span class="stat-num"><?php echo $total; ?></span> Total Days</div>
        <div class="stat-box bg-present"><span class="stat-num"><?php echo $present; ?></span> Present</div>
        <div class="stat-box bg-absent"><span class="stat-num"><?php echo $absent; ?></span> Absent</div>
        <div class="stat-box bg-leave"><span class="stat-num"><?php echo $leave; ?></span> Leaves</div>
    </div>
</div>

<div class="card">
    <table class="att-table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Day</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($data_rows)):
                foreach ($data_rows as $row):
                    $status_color = ($row['status'] == 'Present') ? 'green' : (($row['status'] == 'Absent') ? 'red' : 'orange');
            ?>
                    <tr>
                        <td><?php echo date("d-M-Y", strtotime($row['attendance_date'])); ?></td>
                        <td><?php echo date("l", strtotime($row['attendance_date'])); ?></td>
                        <td style="color:<?php echo $status_color; ?>; font-weight:bold;"><?php echo $row['status']; ?></td>
                    </tr>
                <?php endforeach;
            else: ?>
                <tr>
                    <td colspan="3">No attendance records found for this year.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</div>
</div>
</body>

</html>