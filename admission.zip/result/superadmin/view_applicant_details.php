<?php
include 'admin_check.php'; // Includes session and db connection (../db.php)

// Only Super Admins can access this page
if ($_SESSION['role'] !== 'admin') {
    die("Access Denied. You must be a Super Admin.");
}

$applicant_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($applicant_id === 0) {
    die("Invalid Applicant ID.");
}

// Handle Payment Status Update
if (isset($_GET['action']) && $_GET['action'] == 'toggle_payment') {
    // Toggle payment status
    $conn->query("UPDATE applicants SET payment_status = !payment_status WHERE applicant_id = $applicant_id");
    header("Location: view_applicant_details.php?id=$applicant_id");
    exit;
}


// Fetch the specific applicant's details
$stmt = $conn->prepare("SELECT * FROM applicants WHERE applicant_id = ?");
$stmt->bind_param("i", $applicant_id);
$stmt->execute();
$applicant_result = $stmt->get_result();

if ($applicant_result->num_rows === 0) {
    die("Applicant not found.");
}
$applicant = $applicant_result->fetch_assoc();
$stmt->close();
$conn->close();

// Helper function to create a link for a document
function doc_link($filename)
{
    if (!empty($filename)) {
        // Path is ../uploads/ because we are in the /superadmin/ folder
        $path = '../uploads/' . htmlspecialchars($filename);
        return "<a href='{$path}' target='_blank'>View Document</a>";
    }
    return "Not Uploaded";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Applicant Details - <?php echo htmlspecialchars($applicant['form_no']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #004d40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 900px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .applicant-details {
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .details-header {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid #ddd;
            display: flex;
            align-items: center;
            background: #fdfdfd;
        }

        .details-header img {
            width: 150px;
            height: 150px;
            border-radius: 8px;
            border: 3px solid #eee;
            object-fit: cover;
            margin-right: 20px;
        }

        .header-info {
            text-align: left;
        }

        .header-info h2 {
            margin: 0;
            color: #004d40;
        }

        .header-info p {
            margin: 5px 0;
            font-size: 16px;
            color: #555;
        }

        .details-body {
            padding: 20px;
        }

        .section-title {
            color: #006400;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
            margin-top: 20px;
            font-size: 20px;
        }

        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
        }

        .details-grid p {
            margin: 0;
            font-size: 14px;
            padding: 10px;
            background: #fdfdfd;
            border-bottom: 1px solid #f0f0f0;
        }

        .details-grid p strong {
            display: block;
            color: #333;
            margin-bottom: 5px;
            font-size: 12px;
            text-transform: uppercase;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        .button-bar {
            text-align: center;
            padding: 20px;
        }

        .button {
            background-color: #006400;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            margin: 0 10px;
        }

        .button-back {
            background-color: #6c757d;
        }

        .button-paid {
            background-color: #198754;
        }

        .button-pending {
            background-color: #ffc107;
            color: black;
        }

        @media print {
            body {
                background: #fff;
                margin: 0;
                padding: 0;
            }

            .no-print {
                display: none;
            }

            .container {
                box-shadow: none;
                border: none;
                margin: 0;
                padding: 0;
                max-width: 100%;
            }

            .applicant-details {
                border: none;
            }

            .details-grid {
                grid-template-columns: 1fr 1fr 1fr;
            }
        }
    </style>
</head>

<body>
    <div class="header no-print">
        <h1>Applicant Details</h1>
        <a href="manage_applicants.php">Back to List</a>
    </div>

    <div class="container">
        <div class="applicant-details">
            <div class="details-header">
                <img src="../uploads/<?php echo htmlspecialchars($applicant['photo_filename']); ?>" alt="Applicant Photo">
                <div class="header-info">
                    <h2><?php echo htmlspecialchars($applicant['student_name']); ?></h2>
                    <p><strong>Form No:</strong> <?php echo htmlspecialchars($applicant['form_no']); ?></p>
                    <p><strong>Applying for:</strong> <?php echo htmlspecialchars($applicant['applying_for_class']); ?></p>
                    <p><strong>Payment Status:</strong>
                        <span style="font-weight: bold; color: <?php echo $applicant['payment_status'] ? 'green' : 'red'; ?>">
                            <?php echo $applicant['payment_status'] ? 'Paid' : 'Pending'; ?>
                        </span>
                    </p>
                </div>
            </div>

            <div class="details-body">
                <h3 class="section-title full-width">Student Information</h3>
                <div class="details-grid">
                    <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($applicant['dob']); ?></p>
                    <p><strong>Gender:</strong> <?php echo htmlspecialchars($applicant['gender']); ?></p>
                    <p><strong>Religion:</strong> <?php echo htmlspecialchars($applicant['religion']); ?></p>
                    <p><strong>Place of Birth:</strong> <?php echo htmlspecialchars($applicant['place_of_birth']); ?></p>
                    <p><strong>District:</strong> <?php echo htmlspecialchars($applicant['district']); ?></p>
                    <p><strong>Nationality:</strong> <?php echo htmlspecialchars($applicant['nationality']); ?></p>
                    <p class="full-width"><strong>Student CNIC/B-Form:</strong> <?php echo htmlspecialchars($applicant['student_cnic_bform']); ?></p>
                    <p><strong>Last School:</strong> <?php echo htmlspecialchars($applicant['last_school_name']); ?></p>
                    <p><strong>Leaving Cert No:</strong> <?php echo htmlspecialchars($applicant['last_school_cert_no']); ?></p>
                </div>

                <h3 class="section-title full-width">Parent / Guardian Information</h3>
                <div class="details-grid">
                    <p><strong>Father's Name:</strong> <?php echo htmlspecialchars($applicant['father_name']); ?></p>
                    <p><strong>Father's CNIC:</strong> <?php echo htmlspecialchars($applicant['father_cnic']); ?></p>
                    <p><strong>Guardian's Name:</strong> <?php echo htmlspecialchars($applicant['guardian_name']); ?></p>
                    <p><strong>Occupation:</strong> <?php echo htmlspecialchars($applicant['occupation']); ?></p>
                    <p><strong>Designation:</strong> <?php echo htmlspecialchars($applicant['designation']); ?></p>
                    <p><strong>Monthly Income:</strong> <?php echo htmlspecialchars($applicant['monthly_income']); ?></p>
                    <p class="full-width"><strong>Office Address:</strong> <?php echo htmlspecialchars($applicant['office_address']); ?></p>
                    <p><strong>Tel. Number:</strong> <?php echo htmlspecialchars($applicant['tel_number']); ?></p>
                    <p><strong>WhatsApp (Father):</strong> <?php echo htmlspecialchars($applicant['whatsapp_father']); ?></p>
                    <p><strong>WhatsApp (Mother):</strong> <?php echo htmlspecialchars($applicant['whatsapp_mother']); ?></p>
                    <p><strong>Email (Father):</strong> <?php echo htmlspecialchars($applicant['email_father']); ?></p>
                    <p><strong>Email (Mother):</strong> <?php echo htmlspecialchars($applicant['email_mother']); ?></p>
                    <p class="full-width"><strong>Local Address:</strong> <?php echo htmlspecialchars($applicant['address']); ?></p>
                    <p class="full-width"><strong>Permanent Address:</strong> <?php echo htmlspecialchars($applicant['permanent_address']); ?></p>
                </div>

                <h3 class="section-title full-width">Uploaded Documents</h3>
                <div class="details-grid">
                    <p><strong>Birth Certificate:</strong> <?php echo doc_link($applicant['doc_birth_cert']); ?></p>
                    <p><strong>B-Form:</strong> <?php echo doc_link($applicant['doc_bform']); ?></p>
                    <p><strong>Medical Certificate:</strong> <?php echo doc_link($applicant['doc_medical_cert']); ?></p>
                    <p><strong>Father CNIC (Front):</strong> <?php echo doc_link($applicant['doc_father_cnic_front']); ?></p>
                    <p><strong>Father CNIC (Back):</strong> <?php echo doc_link($applicant['doc_father_cnic_back']); ?></p>
                    <p><strong>Mother CNIC (Front):</strong> <?php echo doc_link($applicant['doc_mother_cnic_front']); ?></p>
                    <p><strong>Mother CNIC (Back):</strong> <?php echo doc_link($applicant['doc_mother_cnic_back']); ?></p>
                    <p><strong>Last School Cert:</strong> <?php echo doc_link($applicant['doc_last_school_cert']); ?></p>
                </div>
            </div>
        </div>

        <div class="button-bar no-print">
            <a href="manage_applicants.php" class="button button-back">Back to List</a>
            <a href="view_applicant_details.php?id=<?php echo $applicant_id; ?>&action=toggle_payment"
                class="button <?php echo $applicant['payment_status'] ? 'button-pending' : 'button-paid'; ?>">
                Mark as <?php echo $applicant['payment_status'] ? 'Pending' : 'Paid'; ?>
            </a>
            <button onclick="window.print()" class="button">Print Details</button>
        </div>
    </div>
</body>

</html>