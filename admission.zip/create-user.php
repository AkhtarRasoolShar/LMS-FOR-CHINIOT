<?php
require 'db_connect.php'; // Get the database connection

$username = "parent123";
$plain_password = "password";
$full_name = "Akhtar Hussain"; // Example name

// Hash the password securely
$password_hash = password_hash($plain_password, PASSWORD_DEFAULT);

// Insert the user into the database
$sql = "INSERT INTO users (username, password_hash, full_name) VALUES (?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $username, $password_hash, $full_name);

if ($stmt->execute()) {
    echo "User created successfully!";
} else {
    echo "Error creating user: " . $stmt->error;
}

$stmt->close();
$conn->close();
