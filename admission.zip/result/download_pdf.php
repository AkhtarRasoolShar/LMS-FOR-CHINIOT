<?php
// download_pdf.php

// 1. Load the Composer autoloader (which loads mPDF)
require_once __DIR__ . '/vendor/autoload.php';

// 2. Include the database connection
include 'db.php';

// 3. Get the student ID from the URL (e.g., download_pdf.php?id=8631)
if (isset($_GET['id'])) {
    $student_id = (int)$_GET['id'];
} else {
    die("Error: No Student ID provided.");
}

// 4. Fetch Student's Personal Information
$stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student_result = $stmt->get_result();
if ($student_result->num_rows == 0) {
    die("Error: No student found with S.NO: $student_id");
}
$student = $student_result->fetch_assoc();

// 5. Fetch ALL Subject Marks
$sql_marks = "SELECT s.subject_name, r.term_name, r.marks_obtained, r.total_marks FROM results r JOIN subjects s ON r.subject_id = s.subject_id WHERE r.student_id = ? ORDER BY s.subject_id, r.term_name";
$stmt_marks = $conn->prepare($sql_marks);
$stmt_marks->bind_param("i", $student_id);
$stmt_marks->execute();
$marks_result = $stmt_marks->get_result();
$marks_by_subject = [];
while ($row = $marks_result->fetch_assoc()) {
    $marks_by_subject[$row['subject_name']][$row['term_name']] = [
        'marks' => $row['marks_obtained'],
        'total' => $row['total_marks']
    ];
}

// 6. Fetch ALL Summary Data
$sql_summary = "SELECT * FROM summaries WHERE student_id = ?";
$stmt_summary = $conn->prepare($sql_summary);
$stmt_summary->bind_param("i", $student_id);
$stmt_summary->execute();
$summary_result = $stmt_summary->get_result();
$summary_data = [];
while ($row = $summary_result->fetch_assoc()) {
    $summary_data[$row['term_name']] = $row;
}

// 7. Get a list of all subjects
$subjects_result = $conn->query("SELECT subject_name FROM subjects ORDER BY subject_id");
$subjects_list = [];
while ($row = $subjects_result->fetch_assoc()) {
    $subjects_list[] = $row['subject_name'];
}
$conn->close();

// 8. Start output buffering
// This "catches" all the HTML below and puts it into a variable
ob_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>E-Report Card</title>
    <style>
        /* (All the same styles from view_result.php) */
        @import url('https://fonts.googleapis.com/css2?family=Arial&display=swap');
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            -webkit-print-color-adjust: exact;
        }
        .report-card {
            width: 210mm;
            min-height: 297mm;
            margin: 0;
            background: #fff;
            padding: 15mm;
            box-sizing: border-box;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 3px solid #006400;
            padding-bottom: 10px;
        }
        .header-logo { width: 100px; }
        .header-text { text-align: center; color: #006400; }
        .header-text h1 { font-size: 24px; margin: 0; }
        .header-text p { font-size: 18px; margin: 5px 0 0 0; font-weight: bold; }
        .header-photo { width: 100px; height: 120px; border: 2px solid #006400; object-fit: cover; }
        .student-info { width: 100%; margin-top: 20px; border-collapse: collapse; }
        .student-info th, .student-info td { border: 1px solid #333; padding: 6px 8px; font-size: 12px; text-align: left; }
        .student-info th { background-color: #f2f2f2; width: 15%; font-weight: bold; }
        .student-info td { width: 35%; font-weight: bold; }
        .section-title { text-align: center; font-size: 16px; font-weight: bold; margin-top: 20px; margin-bottom: 10px; color: #006400; }
        .marks-table, .summary-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 12px; }
        .marks-table th, .marks-table td, .summary-table th, .summary-table td { border: 1px solid #333; padding: 6px; text-align: center; }
        .marks-table th, .summary-table th { background-color: #f2f2f2; font-weight: bold; }
        .marks-table .subject-name, .summary-table .summary-row { text-align: left; font-weight: bold; }
        .page-break { page-break-before: always; border-top: 2px dashed #ccc; margin-top: 20px; padding-top: 15mm; }
    </style>
</head>
<body>
    <div class="report-card">
        
        <div class="header">
            <div class="header-text">
                <h1>CHINIOT ISLAMIA PUBLIC SCHOOL & COLLEGE</h1>
                <p>E-REPORT CARD 2022-2023</p>
            </div>
            <img src="<?php echo __DIR__ . '/uploads/' . htmlspecialchars($student['photo_filename']); ?>" alt="Student Photo" class="header-photo">
        </div>

        <table class="student-info">
             <tr>
                <th>S.NO</th> <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                <th>GENDER</th> <td><?php echo htmlspecialchars($student['gender']); ?></td>
            </tr>
            <tr>
                <th>NAME</th> <td><?php echo htmlspecialchars($student['name']); ?></td>
                <th>CLASS</th> <td><?php echo htmlspecialchars($student['class']); ?></td>
            </tr>
            <tr>
                <th>F.NAME</th> <td><?php echo htmlspecialchars($student['f_name']); ?></td>
                <th>TERM</th> <td>FULL SESSION</td>
            </tr>
        </table>
        
        <h3 class="section-title">1st QUARTERLY / MID TERM</h3>
        <table class="marks-table">
            <thead><tr><th>SUBJECTS</th><th>1st QUARTERLY (40)</th><th>MID TERM (100)</th></tr></thead>
            <tbody>
                <?php foreach ($subjects_list as $subject): ?>
                <tr>
                    <td class="subject-name"><?php echo htmlspecialchars($subject); ?></td>
                    <td><?php echo $marks_by_subject[$subject]['1st QUARTERLY']['marks'] ?? 'N/A'; ?></td>
                    <td><?php echo $marks_by_subject[$subject]['MID TERM']['marks'] ?? 'N/A'; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot><tr style="font-weight: bold;"><td class="subject-name">TOTAL</td><td><?php echo $summary_data['1st QUARTERLY']['obtained_marks'] ?? 'N/A'; ?></td><td><?php echo $summary_data['MID TERM']['obtained_marks'] ?? 'N/A'; ?></td></tr></tfoot>
        </table>
        <table class="summary-table">
            <thead><tr><th>SUMMARY</th><th>1st QUARTERLY MARKS</th><th>MID TERM MARKS</th></tr></thead>
            <tbody>
                <tr><td class="summary-row">OUT OF MARKS</td><td><?php echo $summary_data['1st QUARTERLY']['out_of_marks'] ?? 'N/A'; ?></td><td><?php echo $summary_data['MID TERM']['out_of_marks'] ?? 'N/A'; ?></td></tr>
                <tr><td class="summary-row">OBTAINED MARKS</td><td><?php echo $summary_data['1st QUARTERLY']['obtained_marks'] ?? 'N/A'; ?></td><td><?php echo $summary_data['MID TERM']['obtained_marks'] ?? 'N/A'; ?></td></tr>
                <tr><td class="summary-row">PERCENTAGE</td><td><?php echo $summary_data['1st QUARTERLY']['percentage'] ?? 'N/A'; ?>%</td><td><?php echo $summary_data['MID TERM']['percentage'] ?? 'N/A'; ?>%</td></tr>
                <tr><td class="summary-row">OBTAINED RANK</td><td><?php echo $summary_data['1st QUARTERLY']['rank'] ?? 'N/A'; ?></td><td><?php echo $summary_data['MID TERM']['rank'] ?? 'N/A'; ?></td></tr>
                <tr><td class="summary-row">GRADE</td><td><?php echo $summary_data['1st QUARTERLY']['grade'] ?? 'N/A'; ?></td><td><?php echo $summary_data['MID TERM']['grade'] ?? 'N/A'; ?></td></tr>
                <tr><td class="summary-row">ATTENDANCE</td><td><?php echo $summary_data['1st QUARTERLY']['attendance'] ?? 'N/A'; ?></td><td><?php echo $summary_data['MID TERM']['attendance'] ?? 'N/A'; ?></td></tr>
                <tr><td class="summary-row">REMARKS</td><td><?php echo $summary_data['1st QUARTERLY']['remarks'] ?? 'N/A'; ?></td><td><?php echo $summary_data['MID TERM']['remarks'] ?? 'N/A'; ?></td></tr>
            </tbody>
        </table>
        
        <div class="page-break"></div>
        <h3 class="section-title">2nd QUARTERLY / FINAL TERM</h3>
        <table class="marks-table">
            <thead><tr><th>SUBJECTS</th><th>2nd QUARTERLY (40)</th><th>FINAL TERM (100)</th></tr></thead>
            <tbody>
                <?php foreach ($subjects_list as $subject): ?>
                <tr>
                    <td class="subject-name"><?php echo htmlspecialchars($subject); ?></td>
                    <td><?php echo $marks_by_subject[$subject]['2nd QUARTERLY']['marks'] ?? 'N/A'; ?></td>
                    <td><?php echo $marks_by_subject[$subject]['FINAL TERM']['marks'] ?? 'N/A'; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot><tr style="font-weight: bold;"><td class="subject-name">TOTAL</td><td><?php echo $summary_data['2nd QUARTERLY']['obtained_marks'] ?? 'N/A'; ?></td><td><?php echo $summary_data['FINAL TERM']['obtained_marks'] ?? 'N/A'; ?></td></tr></tfoot>
        </table>
        <table class="summary-table">
            <thead><tr><th>SUMMARY</th><th>2nd QUARTERLY MARKS</th><th>FINAL TERM MARKS</th></tr></thead>
            <tbody>
                <tr><td class="summary-row">OUT OF MARKS</td><td><?php echo $summary_data['2nd QUARTERLY']['out_