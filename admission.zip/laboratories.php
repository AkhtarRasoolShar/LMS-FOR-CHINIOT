<?php
$pageTitle = "Laboratories";
include 'header.php';
?>

<style>
    .lab-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-top: 20px;
    }

    .lab-card {
        border: 1px solid #ddd;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        overflow: hidden;
    }

    .lab-card img {
        width: 100%;
        height: 220px;
        object-fit: cover;
        display: block;
    }

    .lab-card h3 {
        margin: 0;
        padding: 15px;
        background: #f9f9f9;
        border-top: 1px solid #eee;
    }

    @media (max-width: 768px) {
        .lab-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="container">
    <h2>We Have Well-Equipped Laboratories</h2>
    <p>
        Our state-of-the-art labs provide students with the hands-on experience necessary to understand complex scientific and technical concepts. Each lab is equipped with modern apparatus and safety measures.
    </p>

    <div class="lab-grid">
        <div class="lab-card">
            <img src="img/Laboratories/lab.jpg" alt="Chemistry Lab">
            <h3>Chemistry Lab</h3>
        </div>
        <div class="lab-card">
            <img src="img/Laboratories/phy1.jpg" alt="Physics Lab">
            <h3>Physics Lab</h3>
        </div>
        <div class="lab-card">
            <img src="img/Laboratories/bio1.jpg" alt="Biology Lab">
            <h3>Biology Lab</h3>
        </div>
        <div class="lab-card">
            <img src="img/Laboratories/comp1.jpg" alt="Computer Lab">
            <h3>Computer Lab</h3>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>