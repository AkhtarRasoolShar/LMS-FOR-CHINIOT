<style>
    .portal-footer {
        background-color: #222;
        color: #ccc;
        padding: 15px;
        text-align: center;
        margin-top: 40px;
    }

    .portal-footer a {
        color: #fdb813;
        text-decoration: none;
    }
</style>
<footer class="portal-footer">
    <p>&copy; <?php echo date('Y'); ?> Super Admin Portal | <a href="../../index.php">Back to Main Site</a></p>
</footer>
</body>

</html>