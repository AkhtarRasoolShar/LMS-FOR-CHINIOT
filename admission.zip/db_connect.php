<?php
// Start session (essential for most PHP websites, should be done early)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configuration for the main website database
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'u298546061_chiniot');
define('DB_PASSWORD', 'Chiniot0099#');
define('DB_NAME', 'u298546061_admission'); // Assuming 'result' is the database name

// Attempt to establish a database connection using the object-oriented style
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($conn->connect_error) {
    // Log the error internally and show a generic message to the user
    error_log("Database Connection Error in " . __FILE__ . ": " . $conn->connect_error);
    die("ERROR: Could not connect to the database. Please try again later.");
}

// Set character set to UTF-8 for proper data handling
if (!$conn->set_charset("utf8mb4")) {
    error_log("Error loading character set utf8mb4: " . $conn->error);
}
