<?php
include 'admin_check.php'; // --- SECURITY FIRST ---

// --- FIX: Use the standardized session variable directly ---
$logged_in_teacher_id = $_SESSION['user_id'];

// Get all students+terms that are UNLOCKED (is_locked = 0)
// AND are assigned to this teacher
$stmt = $conn->prepare("
    SELECT s.student_id, s.name, su.term_name, c.class_name, c.report_template
    FROM summaries su
    JOIN students s ON su.student_id = s.student_id
    JOIN classes c ON s.class LIKE CONCAT('%', c.class_name, '%')
    JOIN teacher_assignments ta ON c.class_id = ta.class_id
    WHERE su.is_locked = 0 AND ta.teacher_id = ?
    GROUP BY s.student_id, su.term_name
    ORDER BY s.class
");
$stmt->bind_param("i", $logged_in_teacher_id);
$stmt->execute();
$unlocked_results = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Unlocked Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #006400;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1000px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th,
        .data-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .data-table th {
            background: #f2f2f2;
        }

        .action-link {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
            color: white;
            background-color: #006400;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Edit Unlocked Results</h1>
        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <p>The following results have been unlocked by the administrator for editing. They will be locked again automatically when you submit your changes.</p>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Class</th>
                    <th>Term</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($unlocked_results->num_rows > 0): ?>
                    <?php while ($row = $unlocked_results->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['class_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['term_name']); ?></td>
                            <td>
                                <?php
                                // Route to the correct edit form based on template
                                $edit_page = 'edit_result_form.php'; // Default (use existing)
                                if ($row['report_template'] == 'primary') {
                                    $edit_page = 'edit_result_form_primary.php'; // (use existing)
                                }
                                ?>
                                <a href="<?php echo $edit_page; ?>?student_id=<?php echo $row['student_id']; ?>&term=<?php echo $row['term_name']; ?>" class="action-link">
                                    Edit Result
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">There are no results currently unlocked for you to edit.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html>