<?php
$pageTitle = "Application Received";
include 'header.php';

// Get the Form Number from the URL to display it to the user.
// We use htmlspecialchars to prevent any security issues.
$form_no = isset($_GET['form_no']) ? htmlspecialchars($_GET['form_no']) : 'N/A';
?>

<style>
    .thank-you-container {
        text-align: center;
        padding: 50px 20px;
    }

    .thank-you-container h2 {
        color: #006400;
        font-size: 2.5em;
        margin-bottom: 15px;
    }

    .thank-you-container p {
        font-size: 1.2em;
        line-height: 1.7;
        color: #333;
    }

    .form-number-box {
        background: #f4f4f4;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 20px;
        margin: 30px auto;
        display: inline-block;
    }

    .form-number-box p {
        margin: 0;
        font-size: 1.1em;
        color: #333;
    }

    .form-number-box strong {
        font-size: 1.4em;
        color: #006400;
        display: block;
        margin-top: 5px;
        letter-spacing: 1px;
    }

    .back-link {
        display: inline-block;
        margin-top: 30px;
        padding: 12px 25px;
        background-color: #006400;
        color: white;
        text-decoration: none;
        font-weight: bold;
        border-radius: 5px;
    }
</style>

<div class="container">
    <div class="thank-you-container">
        <h2>Thank You!</h2>
        <p>Your admission form has been submitted successfully.</p>

        <div class="form-number-box">
            <p>Your Application Form Number is:</p>
            <strong><?php echo $form_no; ?></strong>
            <p style="font-size: 0.9em; margin-top: 15px;">Please save this number for future reference.</p>
        </div>

        <p>
            Our admissions team will review your application and contact you soon regarding the next steps, including payment and test details.
        </p>

        <a href="index.php" class="back-link">Back to Home</a>
    </div>
</div>

<?php include 'footer.php'; ?>