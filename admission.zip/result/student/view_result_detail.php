<?php
session_start();
$pageTitle = "Detailed Result Card";
include 'header_student.php'; // Includes DB & Sidebar

// 1. Security Check
if (!isset($_SESSION['student_id'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit;
}

$student_id = $_SESSION['student_id'];
$current_term = isset($_GET['term']) ? $_GET['term'] : 'FINAL TERM';
$current_year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// 2. Fetch Student Data
$stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

// ---------------------------------------------------------
// SMART SUBJECT FINDER
// ---------------------------------------------------------
$subjects = [];
$class_id = 0;

// Attempt 1: Find Class ID by Name
$student_class = $student['class'];
$clean_class = trim(str_replace("Class", "", $student_class)); // Handle "Class 9" vs "9"

$c_res = $conn->query("SELECT class_id FROM classes WHERE class_name = '$student_class' OR class_name LIKE '%$clean_class%' LIMIT 1");
if ($c_res->num_rows > 0) {
    $class_id = $c_res->fetch_assoc()['class_id'];
    // Fetch Subjects for this Class
    $sub_res = $conn->query("SELECT s.subject_id, s.subject_name FROM class_subjects cs JOIN subjects s ON cs.subject_id = s.subject_id WHERE cs.class_id = $class_id ORDER BY s.subject_id ASC");
    while ($row = $sub_res->fetch_assoc()) {
        $subjects[$row['subject_id']] = $row['subject_name'];
    }
}

// Attempt 2 (Fallback): If no subjects found via Class, look for ANY saved results for this student
if (empty($subjects)) {
    $res_sub_q = $conn->query("SELECT DISTINCT r.subject_id, s.subject_name 
                               FROM results r 
                               JOIN subjects s ON r.subject_id = s.subject_id 
                               WHERE r.student_id = $student_id");
    while ($row = $res_sub_q->fetch_assoc()) {
        $subjects[$row['subject_id']] = $row['subject_name'];
    }
}

// If STILL empty, show error
if (empty($subjects)) {
    echo "<div class='card' style='color:red; text-align:center; padding:30px;'>
            <h3>⚠️ No Data Found</h3>
            <p>No subjects or results found for Class: <strong>" . htmlspecialchars($student_class) . "</strong></p>
            <p><small>Please ask your teacher to verify your Class Name and Subject Assignments.</small></p>
            <a href='dashboard.php' class='btn-primary' style='padding:10px 20px; text-decoration:none;'>Go Back</a>
          </div>";
    include '../../footer.php';
    exit;
}

// ---------------------------------------------------------
// FETCH RESULTS & CALCULATE
// ---------------------------------------------------------
$results_map = [];
// Check DB for year column to prevent errors
$has_year_col = $conn->query("SHOW COLUMNS FROM results LIKE 'session_year'")->num_rows > 0;
$w_res = "student_id=$student_id AND term_name='$current_term'" . ($has_year_col ? " AND session_year='$current_year'" : "");

$r_res = $conn->query("SELECT subject_id, marks_obtained, total_marks FROM results WHERE $w_res");
while ($row = $r_res->fetch_assoc()) {
    $results_map[$row['subject_id']] = $row;
}

// Calculate Summary on the Fly
$total_obt = 0;
$total_max = 0;
foreach ($subjects as $sid => $sname) {
    $m = $results_map[$sid]['marks_obtained'] ?? 0;
    $t = $results_map[$sid]['total_marks'] ?? 0;
    if (is_numeric($m)) {
        $total_obt += $m;
        $total_max += $t;
    }
}
$perc = ($total_max > 0) ? round(($total_obt / $total_max) * 100, 1) : 0;

// Determine Grade
$grade = 'F';
if ($perc >= 80) $grade = 'A+';
elseif ($perc >= 70) $grade = 'A';
elseif ($perc >= 60) $grade = 'B';
elseif ($perc >= 50) $grade = 'C';
elseif ($perc >= 40) $grade = 'D';
elseif ($perc > 0) $grade = 'E';

// Fetch existing summary for remarks/attendance
$s_res = $conn->query("SELECT * FROM summaries WHERE $w_res");
$summary_db = ($s_res->num_rows > 0) ? $s_res->fetch_assoc() : [];
$rank = $summary_db['rank'] ?? '-';
$remarks = $summary_db['remarks'] ?? (($perc >= 40) ? 'Pass' : 'Fail');

// Auto-Calculate Attendance %
$att_sql = "SELECT 
                (SELECT COUNT(*) FROM attendance WHERE student_id=$student_id AND status='Present' AND YEAR(attendance_date)='$current_year') as present,
                (SELECT COUNT(*) FROM attendance WHERE student_id=$student_id AND YEAR(attendance_date)='$current_year') as total";
$att_data = $conn->query($att_sql)->fetch_assoc();
$att_perc = ($att_data['total'] > 0) ? round(($att_data['present'] / $att_data['total']) * 100) . '%' : '-';

// Chart Data
$chart_labels = [];
$chart_data = [];
foreach ($subjects as $sid => $sname) {
    $m = $results_map[$sid]['marks_obtained'] ?? 0;
    $t = $results_map[$sid]['total_marks'] ?? 0;
    $p = ($t > 0 && is_numeric($m)) ? round(($m / $t) * 100, 1) : 0;
    if ($t > 0) {
        $chart_labels[] = $sname;
        $chart_data[] = $p;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Detailed Result Card</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .report-container {
            max-width: 900px;
            margin: 20px auto;
            background: white;
            padding: 40px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            font-family: 'Times New Roman', serif;
        }

        .school-header {
            text-align: center;
            border-bottom: 4px double #004a99;
            padding-bottom: 20px;
            margin-bottom: 25px;
            display: flex;
            justify-content: center;
            gap: 20px;
            align-items: center;
        }

        .school-header img {
            width: 90px;
        }

        .header-text h1 {
            margin: 0;
            color: #004a99;
            font-size: 24px;
            font-family: Arial, sans-serif;
            font-weight: 900;
        }

        .header-text h3 {
            margin: 5px 0 0 0;
            font-size: 16px;
            color: #333;
            font-family: Arial, sans-serif;
        }

        .student-box {
            border: 2px solid #000;
            padding: 15px;
            margin-bottom: 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .bio-item {
            font-size: 14px;
            font-weight: bold;
            font-family: Arial, sans-serif;
        }

        .bio-item span {
            font-weight: normal;
            border-bottom: 1px dotted #000;
            padding: 0 10px;
            margin-left: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-family: Arial, sans-serif;
            font-size: 13px;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
        }

        th {
            background: #f0f0f0;
            font-weight: bold;
            text-transform: uppercase;
        }

        .sub-col {
            text-align: left;
            padding-left: 10px;
            width: 40%;
            font-weight: bold;
        }

        .summary-table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
            width: 14%;
        }

        .summary-header {
            background: #004a99;
            color: white;
            font-weight: bold;
            padding: 5px;
            text-align: center;
            font-family: Arial;
            border: 2px solid #000;
            border-bottom: none;
        }

        .summary-label {
            background: #f9f9f9;
            font-weight: bold;
            font-size: 12px;
        }

        .footer-sigs {
            margin-top: 50px;
            display: flex;
            justify-content: space-between;
            padding: 0 50px;
            font-family: Arial, sans-serif;
            font-weight: bold;
        }

        .sig-line {
            border-top: 2px solid #000;
            width: 180px;
            text-align: center;
            padding-top: 5px;
        }

        @media print {

            .sidebar,
            .top-bar,
            .btn-print {
                display: none !important;
            }

            .main-content {
                margin: 0;
                width: 100%;
            }

            .report-container {
                box-shadow: none;
                margin: 0;
                padding: 0;
            }
        }
    </style>
</head>

<body>

    <div class="content-wrapper">
        <div style="text-align:center; margin-bottom:20px;" class="btn-print">
            <a href="dashboard.php" class="btn-warning" style="padding:10px 20px; text-decoration:none; margin-right:10px; border-radius:4px; background: #ffc107; color: black;">Back</a>
            <button onclick="window.print()" class="btn-primary" style="padding:10px 20px; cursor:pointer; background: #004a99; color: white; border: none; border-radius: 4px;">Print Card</button>
        </div>

        <div class="report-container">
            <div class="school-header">
                <img src="../../logos.png" alt="Logo">
                <div class="header-text">
                    <h1>CHINIOT ISLAMIA PUBLIC SCHOOL & COLLEGE</h1>
                    <h3>RESULT CARD - <?php echo htmlspecialchars($current_term); ?> (<?php echo $current_year; ?>)</h3>
                </div>
            </div>

            <div class="student-box">
                <div class="bio-item">S.NO: <span><?php echo $student['student_id']; ?></span></div>
                <div class="bio-item">GENDER: <span><?php echo strtoupper($student['gender'] ?? '-'); ?></span></div>
                <div class="bio-item">NAME: <span><?php echo strtoupper($student['name']); ?></span></div>
                <div class="bio-item">CLASS: <span><?php echo strtoupper($student['class']); ?></span></div>
                <div class="bio-item" style="grid-column: span 2;">FATHER NAME: <span><?php echo strtoupper($student['f_name']); ?></span></div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th class="sub-col">SUBJECTS</th>
                        <th>TOTAL MARKS</th>
                        <th>OBTAINED MARKS</th>
                        <th>PERCENTAGE</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($subjects)): foreach ($subjects as $sid => $sname):
                            $d = $results_map[$sid] ?? [];
                            $m = $d['marks_obtained'] ?? '-';
                            $t = $d['total_marks'] ?? '-';
                            $p = ($t > 0 && is_numeric($m)) ? round(($m / $t) * 100) . '%' : '-';
                    ?>
                            <tr>
                                <td class="sub-col"><?php echo htmlspecialchars($sname); ?></td>
                                <td><?php echo $t; ?></td>
                                <td><?php echo $m; ?></td>
                                <td><?php echo $p; ?></td>
                            </tr>
                    <?php endforeach;
                    endif; ?>

                    <tr style="background:#f9f9f9; font-weight:bold;">
                        <td class="sub-col" style="text-align:right; padding-right:15px;">GRAND TOTAL</td>
                        <td><?php echo $total_max; ?></td>
                        <td><?php echo $total_obt; ?></td>
                        <td><?php echo $perc; ?>%</td>
                    </tr>
                </tbody>
            </table>

            <div class="summary-header">PERFORMANCE SUMMARY</div>
            <table class="summary-table" style="border:2px solid #000; margin:0;">
                <tr style="background:#f9f9f9;">
                    <td class="summary-label">PERCENTAGE</td>
                    <td class="summary-label">GRADE</td>
                    <td class="summary-label">RANK</td>
                    <td class="summary-label">ATTENDANCE</td>
                    <td class="summary-label">REMARKS</td>
                </tr>
                <tr>
                    <td><?php echo $perc; ?>%</td>
                    <td><?php echo $grade; ?></td>
                    <td><?php echo $rank; ?></td>
                    <td><?php echo $att_perc; ?></td>
                    <td><?php echo $remarks; ?></td>
                </tr>
            </table>

            <div class="footer-sigs">
                <div>
                    <div class="sig-line">Class Teacher</div>
                </div>
                <div>
                    <div class="sig-line">Principal</div>
                </div>
                <div>Dated: <?php echo date('d-M-Y'); ?></div>
            </div>
        </div>
    </div>

    <?php if (!empty($chart_data)): ?>
        <script>
            // Optional: Chart Rendering if needed in future
        </script>
    <?php endif; ?>
</body>

</html>