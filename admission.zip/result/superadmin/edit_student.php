<?php
include 'admin_check.php'; // Secure this page

$message = '';
$student_id = (int)$_GET['id'];
$error_in_upload = false;

// --- Fetch list of all classes for the dropdown ---
$classes_result = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");


// --- Handle Form Submission (POST) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // --- 1. Get POST data ---
    $name = $_POST['name'];
    $f_name = $_POST['f_name'];
    $class_id = (int)$_POST['class_id'];
    $gender = $_POST['gender'];

    // Get the class_name string based on the selected class_id
    $class_name_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
    $class_name_stmt->bind_param("i", $class_id);
    $class_name_stmt->execute();
    $class = $class_name_stmt->get_result()->fetch_assoc()['class_name'] ?? '';
    $class_name_stmt->close();

    // Start transaction for file handling safety
    $conn->begin_transaction();

    try {
        // Fetch current photo filename
        $stmt_fetch = $conn->prepare("SELECT photo_filename FROM students WHERE student_id = ? FOR UPDATE");
        $stmt_fetch->bind_param("i", $student_id);
        $stmt_fetch->execute();
        $result = $stmt_fetch->get_result();
        $student_current = $result->fetch_assoc();
        $photo_filename = $student_current['photo_filename']; // Keep old photo by default
        $stmt_fetch->close();

        // --- 2. Handle File Upload (if a new one is sent) ---
        if (isset($_FILES['student_photo']) && $_FILES['student_photo']['error'] == 0) {
            $target_dir = "../uploads/";
            $extension = strtolower(pathinfo($_FILES["student_photo"]["name"], PATHINFO_EXTENSION));
            $new_filename = $student_id . '.' . $extension; // e.g., 8631.jpg
            $target_file = $target_dir . $new_filename;

            $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($extension, $allowed_types)) {
                throw new Exception("Error: Only JPG, JPEG, PNG, & GIF files are allowed.");
            }

            // Delete old photo if it has a different filename (different extension)
            if ($photo_filename && $photo_filename != $new_filename) {
                $old_file_path = $target_dir . $photo_filename;
                if (file_exists($old_file_path)) {
                    unlink($old_file_path);
                }
            }

            // Move the new file
            if (!move_uploaded_file($_FILES["student_photo"]["tmp_name"], $target_file)) {
                throw new Exception("Error: There was a problem uploading the photo.");
            }
            $photo_filename = $new_filename; // Set new photo filename
        }

        // --- 3. Update the Database ---
        $stmt_update = $conn->prepare("UPDATE students SET name = ?, f_name = ?, class = ?, gender = ?, photo_filename = ? WHERE student_id = ?");
        $stmt_update->bind_param("sssssi", $name, $f_name, $class, $gender, $photo_filename, $student_id);

        if ($stmt_update->execute()) {
            $message = "Success! Student updated.";
            $conn->commit(); // Commit if everything succeeds
        } else {
            throw new Exception("Database Update Failed.");
        }
        $stmt_update->close();
    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error: " . $e->getMessage();
        $error_in_upload = true;
    }
}

// --- Fetch Student Data (GET) ---
// Get current data to pre-fill the form (or re-fill after a failed POST)
$stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 1) {
    $student = $result->fetch_assoc();
} else {
    die("Error: Student not found.");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 600px;
            margin: auto;
        }

        .form-container {
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group input[type="file"] {
            border: none;
            padding: 5px 0;
        }

        button {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #b30000;
        }

        .current-photo {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Edit Student</h1>
        <a href="manage_students.php">Back to List</a>
    </div>

    <div class="container">
        <div class="form-container">
            <h2>Edit '<?php echo htmlspecialchars($student['name']); ?>' (S.NO: <?php echo $student['student_id']; ?>)</h2>

            <?php if ($message): ?>
                <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>"><?php echo $message; ?></p>
            <?php endif; ?>

            <form action="edit_student.php?id=<?php echo $student_id; ?>" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Student Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($student['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="f_name">Father's Name</label>
                    <input type="text" name="f_name" value="<?php echo htmlspecialchars($student['f_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="class_id">Class (Current: <?php echo htmlspecialchars($student['class']); ?>)</label>
                    <select id="class_id" name="class_id" required>
                        <option value="">-- Select Class --</option>
                        <?php
                        if ($classes_result->num_rows > 0) {
                            $classes_result->data_seek(0);
                            while ($class_row = $classes_result->fetch_assoc()):
                                // Check if the student's current class name matches the class_name from the classes table
                                $selected = ($student['class'] == $class_row['class_name']) ? 'selected' : '';
                        ?>
                                <option value="<?php echo $class_row['class_id']; ?>" <?php echo $selected; ?>>
                                    <?php echo htmlspecialchars($class_row['class_name']); ?>
                                </option>
                        <?php endwhile;
                        } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select name="gender">
                        <option value="MALE" <?php if ($student['gender'] == 'MALE') echo 'selected'; ?>>MALE</option>
                        <option value="FEMALE" <?php if ($student['gender'] == 'FEMALE') echo 'selected'; ?>>FEMALE</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Current Photo</label>
                    <div>
                        <?php
                        $photo_src = !empty($student['photo_filename']) ? "../uploads/" . htmlspecialchars($student['photo_filename']) : 'https://placehold.co/100x100/eeeeee/cccccc?text=No+Photo';
                        ?>
                        <img src="<?php echo $photo_src; ?>"
                            alt="Photo"
                            class="current-photo"
                            onerror="this.onerror=null; this.src='https://placehold.co/100x100/eeeeee/cccccc?text=No+Photo'">
                    </div>
                </div>
                <div class="form-group">
                    <label for="student_photo">Upload New Photo</label>
                    <input type="file" name="student_photo">
                    <small>Leave blank to keep the current photo.</small>
                </div>

                <button type="submit">Update Student</button>
            </form>

            <a href="manage_students.php" class="back-link">&laquo; Back to Student List</a>
        </div>
    </div>
</body>

</html>