<?php
session_start();

// Unset all session variables
$_SESSION = array();

// Destroy all session data
session_destroy();

// Redirect to the login page
header("Location: admin_login.php");
exit();
