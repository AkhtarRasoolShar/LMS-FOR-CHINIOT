<?php
session_start();
$message = '';
$error = '';

if (isset($_GET['status'])) {
    if ($_GET['status'] == 'success') {
        $message = "If an account exists for that email, a password reset link has been sent.";
    } elseif ($_GET['status'] == 'invalid') {
        $error = "Invalid or expired reset link.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 40px;
            text-align: center;
            width: 350px;
        }

        h2 {
            margin: 0 0 20px 0;
            color: #006400;
        }

        input[type="email"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #006400;
            color: white;
            padding: 14px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }

        .message {
            color: green;
            margin-bottom: 15px;
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }

        a {
            color: #006400;
            text-decoration: none;
            display: block;
            margin-top: 15px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Reset Password</h2>

        <?php if ($message): ?><p class="message"><?php echo $message; ?></p><?php endif; ?>
        <?php if ($error): ?><p class="error"><?php echo $error; ?></p><?php endif; ?>

        <p>Enter your email address and we will send you a link to reset your password.</p>

        <form action="send_reset_link.php" method="POST">
            <input type="email" name="email" placeholder="Your Email Address" required>
            <button type="submit">Send Reset Link</button>
        </form>
        <a href="admin_login.php">Back to Login</a>
    </div>
</body>

</html>