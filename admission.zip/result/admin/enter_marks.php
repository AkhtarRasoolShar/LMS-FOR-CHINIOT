<?php
$pageTitle = "Select Subject";
include 'header_teacher.php';

// Fetch Assignments
$teacher_id = $_SESSION['teacher_id'];
$sql = "SELECT ta.class_id, ta.subject_id, c.class_name, s.subject_name 
        FROM teacher_assignments ta 
        JOIN classes c ON ta.class_id = c.class_id 
        JOIN subjects s ON ta.subject_id = s.subject_id 
        WHERE ta.teacher_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$assignments = $stmt->get_result();
?>

<div class="card">
    <h3 style="margin-top:0; color:#004a99;">Select Subject to Enter Marks</h3>
    <p style="color:#666;">Choose a class and subject below to view the student list.</p>

    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; margin-top:20px;">
        <?php if ($assignments->num_rows > 0): while ($row = $assignments->fetch_assoc()): ?>
                <a href="enter_marks_list.php?class_id=<?php echo $row['class_id']; ?>&subject_id=<?php echo $row['subject_id']; ?>" style="text-decoration:none; color:inherit;">
                    <div style="background:#f8f9fa; border:1px solid #ddd; padding:20px; border-radius:8px; border-left:5px solid #004a99; transition:0.3s;">
                        <strong style="font-size:18px; display:block; margin-bottom:5px; color:#333;">
                            <?php echo htmlspecialchars($row['subject_name']); ?>
                        </strong>
                        <span style="color:#666; font-size:14px;">
                            <i class="fas fa-users"></i> <?php echo htmlspecialchars($row['class_name']); ?>
                        </span>
                        <div style="margin-top:10px; color:#004a99; font-weight:bold; font-size:13px;">
                            Enter Marks <i class="fas fa-arrow-right"></i>
                        </div>
                    </div>
                </a>
            <?php endwhile;
        else: ?>
            <p style="color:red;">No subjects assigned. Please contact the administrator.</p>
        <?php endif; ?>
    </div>
</div>

<?php include '../../footer.php'; ?>