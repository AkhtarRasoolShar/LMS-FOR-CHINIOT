<?php
// Start the session
session_start();
require 'db_connect.php'; // Get the database connection

// --- SECURITY CHECK ---
if (!isset($_SESSION["teacher_loggedin"]) || $_SESSION["teacher_loggedin"] !== true) {
    header("location: teacher-login.html");
    exit;
}

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get the data from the form
    $attendance_data = $_POST['attendance'];
    $class_id = $_POST['class_id'];
    $attendance_date = date("Y-m-d"); // Get today's date in SQL format

    // Prepare the SQL query
    // This query is special:
    // 1. It tries to INSERT a new record.
    // 2. If a record for that student on that day already exists (UNIQUE KEY),
    //    it will UPDATE the status instead. This prevents errors.
    $sql = "INSERT INTO attendance (student_id, class_id, attendance_date, status) 
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE status = VALUES(status)";

    if ($stmt = $conn->prepare($sql)) {
        // Bind parameters
        $stmt->bind_param("iiss", $student_id, $class_id, $attendance_date, $status);

        // Loop through each student submitted
        foreach ($attendance_data as $student_id => $status) {
            // The variables $student_id and $status are updated here
            // and then executed by the prepared statement
            $stmt->execute();
        }

        // Close the statement
        $stmt->close();
    } else {
        // Handle error if statement couldn't be prepared
        echo "Error: Could not prepare the database query.";
        exit;
    }

    // Close the connection
    $conn->close();

    // --- SUCCESS ---
    // Redirect the teacher back to the dashboard.
    // We add ?attendance_success=1 to show a success message
    header("location: teacher-dashboard.php?attendance_success=1");
    exit;
} else {
    // If not a POST request, just redirect
    header("location: teacher-dashboard.php");
    exit;
}
