<?php
include 'admin_check.php';

// Only Super Admins
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'superadmin') {
    die("Access Denied.");
}

$portalTitle = "Manage Result Locks";
include 'portal_header.php';

$message = '';
$error = '';

// --- Handle Lock/Unlock Action ---
if (isset($_GET['action']) && isset($_GET['id'])) {
    $student_id = (int)$_GET['id'];
    $term_name = $_GET['term_name'];
    $action = $_GET['action'];

    // Determine new lock status
    $new_lock_status = ($action == 'lock') ? 1 : 0;

    $stmt = $conn->prepare("UPDATE summaries SET is_locked = ? WHERE student_id = ? AND term_name = ?");
    $stmt->bind_param("iis", $new_lock_status, $student_id, $term_name);

    if ($stmt->execute()) {
        $message = "Result for Student ID {$student_id} ({$term_name}) successfully set to " . ($new_lock_status ? 'LOCKED' : 'UNLOCKED') . ".";
    } else {
        $error = "Error updating lock status: " . $stmt->error;
    }
    $stmt->close();
}


// --- Fetch All Summarized Results ---
$results_result = $conn->query("
    SELECT 
        s.student_id, 
        s.name, 
        s.class, 
        su.term_name, 
        su.obtained_marks, 
        su.percentage, 
        su.is_locked
    FROM summaries su
    JOIN students s ON su.student_id = s.student_id
    ORDER BY s.class, s.name, su.term_name
");

?>
<style>
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .data-table th,
    .data-table td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
        font-size: 14px;
    }

    .data-table th {
        background: #f2f2f2;
    }

    .action-links a {
        text-decoration: none;
        padding: 5px 10px;
        border-radius: 3px;
        font-size: 13px;
        margin-right: 5px;
        color: white;
    }

    .action-lock-btn {
        background-color: #dc3545;
    }

    /* Red */
    .action-unlock-btn {
        background-color: #28a745;
    }

    /* Green */
    .status-locked {
        color: #dc3545;
        font-weight: bold;
    }

    .status-unlocked {
        color: #28a745;
        font-weight: bold;
    }
</style>

<div class="container">
    <?php if ($message && !$error): ?>
        <p class="message enrollment-success"><?php echo $message; ?></p>
    <?php endif; ?>
    <?php if ($error): ?>
        <p class="message error"><?php echo $error; ?></p>
    <?php endif; ?>

    <h2>Result Lock Management</h2>
    <p>Use this page to manually lock or unlock student results for teacher editing.</p>

    <table class="data-table">
        <thead>
            <tr>
                <th>S.ID</th>
                <th>Student Name</th>
                <th>Class</th>
                <th>Term</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($results_result && $results_result->num_rows > 0): ?>
                <?php while ($row = $results_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['class']); ?></td>
                        <td><?php echo htmlspecialchars($row['term_name']); ?></td>
                        <td>
                            <?php if ($row['is_locked'] == 1): ?>
                                <span class="status-locked">LOCKED</span>
                            <?php else: ?>
                                <span class="status-unlocked">UNLOCKED</span>
                            <?php endif; ?>
                        </td>
                        <td class="action-links">
                            <?php
                            // Prepare URL parameters
                            $params = "id={$row['student_id']}&term_name=" . urlencode($row['term_name']);

                            if ($row['is_locked'] == 1): ?>
                                <a href="?action=unlock&<?php echo $params; ?>" class="action-link action-unlock-btn" onclick="return confirm('Are you sure you want to UNLOCK this result?');">Unlock for Edit</a>
                            <?php else: ?>
                                <a href="?action=lock&<?php echo $params; ?>" class="action-link action-lock-btn" onclick="return confirm('Are you sure you want to LOCK this result?');">Lock Result</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No summarized results found in the database.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'portal_footer.php'; ?>