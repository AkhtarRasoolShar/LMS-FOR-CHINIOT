<?php
$pageTitle = "My Profile";
include 'header_teacher.php';

// --- FIX: Handle missing session role safely ---
$teacher_role = isset($_SESSION['teacher_role']) ? $_SESSION['teacher_role'] : 'Teacher';

$msg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_pass = $_POST['new_pass'];
    $confirm = $_POST['confirm_pass'];

    if ($new_pass !== $confirm) {
        $msg = "<div class='alert alert-danger'>Passwords do not match.</div>";
    } elseif (strlen($new_pass) < 4) {
        $msg = "<div class='alert alert-danger'>Password is too short.</div>";
    } else {
        // Update Password
        $hash = password_hash($new_pass, PASSWORD_DEFAULT);
        $upd = $conn->prepare("UPDATE teacher SET password_hash = ? WHERE teacher_id = ?");
        $upd->bind_param("si", $hash, $teacher_id);

        if ($upd->execute()) {
            $msg = "<div class='alert alert-success'>Password updated successfully!</div>";
        } else {
            $msg = "<div class='alert alert-danger'>Database error. Try again.</div>";
        }
    }
}
?>

<style>
    .profile-card {
        max-width: 600px;
        margin: 0 auto;
        background: white;
        padding: 30px;
        border-radius: 8px;
        border-top: 4px solid #ffc107;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
        color: #555;
    }

    .form-control {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    .alert {
        padding: 15px;
        border-radius: 4px;
        margin-bottom: 20px;
    }

    .alert-success {
        background: #d4edda;
        color: #155724;
    }

    .alert-danger {
        background: #f8d7da;
        color: #721c24;
    }
</style>

<div class="profile-card">
    <h3 style="margin-top:0; border-bottom:1px solid #eee; padding-bottom:15px; margin-bottom:20px;">Teacher Profile</h3>

    <div style="margin-bottom:20px;">
        <strong>Full Name:</strong> <span style="color:#555;"><?php echo htmlspecialchars($_SESSION['teacher_name']); ?></span><br>
        <strong>Role:</strong> <span style="color:#555; text-transform:capitalize;"><?php echo htmlspecialchars($teacher_role); ?></span>
    </div>

    <h4 style="margin-bottom:15px; color:#ffc107;">Change Password</h4>
    <?php echo $msg; ?>

    <form method="POST">
        <div class="form-group">
            <label>New Password</label>
            <input type="password" name="new_pass" class="form-control" required placeholder="Enter new password">
        </div>
        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="confirm_pass" class="form-control" required placeholder="Repeat new password">
        </div>
        <button type="submit" class="btn-warning" style="width:100%; padding:12px; font-weight:bold; border:none; border-radius:4px; cursor:pointer; background:#ffc107;">Update Password</button>
    </form>
</div>

</div>
</div>
</body>

</html>