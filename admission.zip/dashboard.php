<?php
// Start the session
session_start();

// --- SECURITY CHECK ---
// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: portal.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parent Dashboard - Chiniot Islamia Public School & College</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

    <header>
        <div class="container">
            <a href="index.php" class="logo">Chiniot School</a>
            <nav class="main-nav">
                <ul>
                    <li><a href="dashboard.php" class="active">Dashboard</a></li>
                    <li><a href="messages.php">Messages</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="page-header">
        <div class="container">
            <h1><?php echo htmlspecialchars($_SESSION["full_name"]); ?>'s Dashboard</h1>
        </div>
    </section>

    <section class="page-content">
        <div class="container">

            <h2>Welcome, <?php echo htmlspecialchars($_SESSION["full_name"]); ?>!</h2>
            <p>Here you can find your child's E-Report Cards and other academic information.</p>

            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <i class="fa-solid fa-file-invoice"></i>
                    <h3>E-Report Card</h3>
                    <p>View and download the latest report card.</p>
                    <a href="report-card.php" class="cta-button">Download Report</a>
                </div>
                <div class="dashboard-card">
                    <i class="fa-solid fa-calendar-days"></i>
                    <h3>Attendance</h3>
                    <p>Check your child's attendance record.</p>
                    <a href="attendance.php" class="cta-button">View Attendance</a>
                </div>
                <div class="dashboard-card">
                    <i class="fa-solid fa-money-check"></i>
                    <h3>Fee Challan</h3>
                    <p>Download your next fee challan.</p>
                    <a href="fee-challan.php" class="cta-button">Get Fee Bill</a>
                </div>
            </div>

        </div>
    </section>

    <footer>
        <div class="footer-bottom">
            <p>&copy; <?php echo date("Y"); ?> Chiniot Islamia Public School & College. All Rights Reserved.</p>
        </div>
    </footer>

</body>

</html>