<?php
session_start();
require '../db.php'; // Connect to the database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    // Prepare statement to find the user with role 'teacher'
    $stmt = $conn->prepare("SELECT teacher_id, password_hash, role, full_name FROM teachers WHERE username = ? AND role = 'teacher'");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        // Verify the hashed password
        if (password_verify($password, $user['password_hash'])) {

            // --- FIX: Standardize Session Variables for Consistency ---
            $_SESSION['user_id'] = $user['teacher_id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role']; // Should be 'teacher'

            // Redirect to the teacher dashboard
            header("Location: admin_dashboard.php");
            exit;
        }
    }

    // If login fails (user not found or wrong password)
    header("Location: admin_login.php?error=1");
    exit;
} else {
    // Not a POST request
    header("Location: admin_login.php");
    exit;
}
