<?php
// ajax_get_subjects.php
// Fetches subjects assigned to the logged-in teacher for a specific class.

// --- FIX ---
// The db.php file is in the parent directory (result/), not in the admin/ directory.
// We must go up one level (../) to include it.
include '../db.php';

// --- Security Check ---
// We must also include the admin_check.php to secure this file
// and get the logged_in_teacher_id.
include 'admin_check.php';

$class_id = (int)$_GET['class_id'] ?? 0;
$logged_in_teacher_id = $_SESSION['teacher_id']; // Get ID from admin_check.php

if ($class_id === 0) {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit;
}

// Find all subjects that this teacher is assigned to for this class_id.
// This is the main security check for this file.
$stmt = $conn->prepare("
    SELECT s.subject_id, s.subject_name
    FROM teacher_assignments ta
    JOIN subjects s ON ta.subject_id = s.subject_id
    WHERE 
        ta.teacher_id = ? AND ta.class_id = ?
    ORDER BY s.subject_name
");
$stmt->bind_param("ii", $logged_in_teacher_id, $class_id);
$stmt->execute();
$result = $stmt->get_result();

$subjects = [];
while ($row = $result->fetch_assoc()) {
    $subjects[] = $row;
}
$stmt->close();

header('Content-Type: application/json');
echo json_encode($subjects);
exit();
