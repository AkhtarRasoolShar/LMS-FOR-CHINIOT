<?php
include 'admin_check.php';

// Only Super Admins can access this page
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'superadmin') {
    die("Access Denied.");
}

$portalTitle = "Admission Checkup & Approval";
include 'portal_header.php';

$message = '';
$error = '';

// --- Handle Approval/Rejection ---
if (isset($_GET['action']) && isset($_GET['id'])) {
    $applicant_id = (int)$_GET['id'];
    $action = $_GET['action'];
    $logged_in_user_id = $_SESSION['user_id'];

    $conn->begin_transaction();
    try {
        if ($action == 'approve') {

            // --- 1. FETCH APPLICANT DATA ---
            $applicant_stmt = $conn->prepare("
                SELECT 
                    student_name, father_name, email_father, whatsapp_father, applying_for_class, 
                    gender, dob, main_subject, phone, enrollment_status 
                FROM applicants 
                WHERE applicant_id = ?
            ");
            $applicant_stmt->bind_param("i", $applicant_id);
            $applicant_stmt->execute();
            $applicant_data = $applicant_stmt->get_result()->fetch_assoc();
            $applicant_stmt->close();

            if (!$applicant_data) {
                throw new Exception("Applicant not found or already processed.");
            }

            // --- 2. INSERT INTO STUDENTS TABLE (The Enrollment Step) ---
            $insert_student_stmt = $conn->prepare("
                INSERT INTO students 
                (name, f_name, class, gender, dob, enrollment_status, is_fee_paid, phone, email_father) 
                VALUES (?, ?, ?, ?, ?, 'Current', 1, ?, ?)
            ");
            $insert_student_stmt->bind_param(
                "sssssis",
                $applicant_data['student_name'],
                $applicant_data['father_name'],
                $applicant_data['applying_for_class'],
                $applicant_data['gender'],
                $applicant_data['dob'],
                $applicant_data['whatsapp_father'], // Using whatsapp_father for phone
                $applicant_data['email_father']
            );
            $insert_student_stmt->execute();

            // --- GET THE NEW SERIAL NUMBER ---
            $new_sn_number = $conn->insert_id;
            $insert_student_stmt->close();

            // --- 3. UPDATE APPLICANTS TABLE (Mark as Approved and record S.N. No.) ---
            $update_applicant_stmt = $conn->prepare("
                UPDATE applicants 
                SET approval_status = 'Approved', processed_by_id = ?, student_sn_number = ? 
                WHERE applicant_id = ?
            ");
            $update_applicant_stmt->bind_param("iii", $logged_in_user_id, $new_sn_number, $applicant_id);
            $update_applicant_stmt->execute();
            $update_applicant_stmt->close();

            $conn->commit();
            $message = "Success! Applicant has been ENROLLED. New Student S.N. No. is: " . $new_sn_number;
        } elseif ($action == 'reject') {
            // --- 4. REJECT ACTION (Simpler Update) ---
            $update_applicant_stmt = $conn->prepare("
                UPDATE applicants 
                SET approval_status = 'Rejected', processed_by_id = ? 
                WHERE applicant_id = ?
            ");
            $update_applicant_stmt->bind_param("ii", $logged_in_user_id, $applicant_id);
            $update_applicant_stmt->execute();
            $update_applicant_stmt->close();
            $conn->commit();
            $message = "Applicant ID {$applicant_id} marked as Rejected.";
        }
    } catch (Exception $e) {
        $conn->rollback();
        $error = "FATAL ERROR during enrollment. Details: " . $e->getMessage();
    }
}

// --- Fetch Applicants who have PAID and are PENDING approval ---
$applicants_result = $conn->query("
    SELECT applicant_id, form_no, student_name, applying_for_class, payment_status, test_date, created_at, approval_status
    FROM applicants
    WHERE payment_status = 1 AND approval_status = 'Pending'
    ORDER BY created_at ASC
");

?>
<style>
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .data-table th,
    .data-table td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
        font-size: 14px;
    }

    .data-table th {
        background: #f2f2f2;
    }

    .action-links a {
        text-decoration: none;
        padding: 5px 10px;
        border-radius: 3px;
        font-size: 13px;
        margin-right: 5px;
    }

    .action-approve {
        background-color: #28a745;
        color: white;
    }

    .action-reject {
        background-color: #dc3545;
        color: white;
    }

    .status-Pending {
        color: #ff9800;
        font-weight: bold;
    }

    .enrollment-success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
        padding: 15px;
        margin-bottom: 20px;
        font-weight: bold;
        text-align: center;
    }

    .message.error {
        background: #f8d7da;
        color: #721c24;
    }
</style>

<div class="container">
    <?php if ($message && !$error): ?>
        <p class="message enrollment-success"><?php echo $message; ?></p>
    <?php endif; ?>
    <?php if ($error): ?>
        <p class="message error"><?php echo $error; ?></p>
    <?php endif; ?>

    <h2>Paid Applications - Ready for Final Review</h2>

    <table class="data-table">
        <thead>
            <tr>
                <th>Form No</th>
                <th>Student Name</th>
                <th>Applying for Class</th>
                <th>Payment</th>
                <th>Test Date</th>
                <th>Received Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($applicants_result && $applicants_result->num_rows > 0): ?>
                <?php while ($row = $applicants_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['form_no']); ?></td>
                        <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['applying_for_class']); ?></td>
                        <td><span style="color: green; font-weight: bold;">Paid</span></td>
                        <td><?php echo htmlspecialchars($row['test_date'] ?? 'N/A'); ?></td>
                        <td><?php echo date('M j, Y', strtotime($row['created_at'])); ?></td>
                        <td class="action-links">
                            <a href="view_applicant_details.php?id=<?php echo $row['applicant_id']; ?>" class="action-view" target="_blank">View Details</a>
                            <a href="?action=approve&id=<?php echo $row['applicant_id']; ?>" class="action-approve" onclick="return confirm('APPROVE this admission? This action will generate the Student S.N. No. and enroll the student.');">Approve</a>
                            <a href="?action=reject&id=<?php echo $row['applicant_id']; ?>" class="action-reject" onclick="return confirm('REJECT this application?');">Reject</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7">No paid applications are currently pending final approval.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'portal_footer.php'; ?>