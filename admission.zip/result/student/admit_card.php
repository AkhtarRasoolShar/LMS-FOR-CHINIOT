<?php
$pageTitle = "Exam Admit Card";
include 'header_student.php';

$current_year = date('Y');
// You might want to fetch active exams from a settings table later
$active_exam = "FINAL TERM";
?>

<style>
    .admit-card-box {
        border: 2px solid #004a99;
        padding: 30px;
        max-width: 700px;
        margin: 0 auto;
        background: white;
        position: relative;
    }

    .ac-header {
        text-align: center;
        border-bottom: 2px dashed #ccc;
        padding-bottom: 20px;
        margin-bottom: 20px;
    }

    .ac-header img {
        width: 80px;
    }

    .ac-header h2 {
        margin: 10px 0 5px 0;
        color: #004a99;
        text-transform: uppercase;
    }

    .ac-title {
        text-align: center;
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 20px;
        text-transform: uppercase;
        background: #eee;
        padding: 5px;
    }

    .ac-details {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
    }

    .ac-item strong {
        display: block;
        color: #555;
        font-size: 12px;
        text-transform: uppercase;
    }

    .ac-item span {
        display: block;
        font-size: 16px;
        font-weight: bold;
        color: #000;
        border-bottom: 1px solid #eee;
        padding-bottom: 5px;
    }

    .ac-photo {
        position: absolute;
        top: 30px;
        right: 30px;
        width: 100px;
        height: 120px;
        border: 1px solid #000;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f9f9f9;
        color: #aaa;
        font-size: 12px;
    }

    .ac-instructions {
        margin-top: 30px;
        border-top: 2px dashed #ccc;
        padding-top: 15px;
    }

    .ac-instructions h4 {
        margin: 0 0 10px 0;
        font-size: 14px;
        text-transform: uppercase;
    }

    .ac-instructions ul {
        padding-left: 20px;
        margin: 0;
        font-size: 13px;
        color: #555;
    }

    .ac-instructions li {
        margin-bottom: 5px;
    }

    @media print {

        .sidebar,
        .top-bar,
        .print-btn-wrapper {
            display: none !important;
        }

        .main-content {
            margin: 0;
        }

        .content-wrapper {
            padding: 0;
        }

        .card {
            border: none;
            shadow: none;
        }

        .admit-card-box {
            border: 2px solid #000;
        }
    }
</style>

<div class="card">
    <div class="print-btn-wrapper" style="text-align:right; margin-bottom:20px;">
        <button onclick="window.print()" class="btn-primary"><i class="fas fa-print"></i> Print Admit Card</button>
    </div>

    <div class="admit-card-box">
        <div class="ac-photo">
            <?php if (!empty($current_student['photo_filename'])): ?>
                <img src="../uploads/<?php echo $current_student['photo_filename']; ?>" style="width:100%; height:100%; object-fit:cover;">
            <?php else: ?>
                Paste Photo
            <?php endif; ?>
        </div>

        <div class="ac-header">
            <img src="../../logos.png" alt="Logo">
            <h2>Chiniot Islamia Public School</h2>
            <span>EXAMINATION ADMIT CARD</span>
        </div>

        <div class="ac-title">
            <?php echo $active_exam; ?> - <?php echo $current_year; ?>
        </div>

        <div class="ac-details">
            <div class="ac-item">
                <strong>Student Name</strong>
                <span><?php echo strtoupper($current_student['name']); ?></span>
            </div>
            <div class="ac-item">
                <strong>Student ID (Roll No)</strong>
                <span><?php echo $current_student['student_id']; ?></span>
            </div>
            <div class="ac-item">
                <strong>Father's Name</strong>
                <span><?php echo strtoupper($current_student['f_name']); ?></span>
            </div>
            <div class="ac-item">
                <strong>Class</strong>
                <span><?php echo strtoupper($current_student['class']); ?></span>
            </div>
        </div>

        <div class="ac-instructions">
            <h4>Important Instructions:</h4>
            <ul>
                <li>Student must bring this admit card to the examination hall.</li>
                <li>Mobile phones and other electronic devices are strictly prohibited.</li>
                <li>Please arrive at least 15 minutes before the exam starts.</li>
                <li>Latecomers will not be allowed to sit in the exam.</li>
            </ul>
        </div>

        <div style="margin-top: 50px; display: flex; justify-content: space-between; padding: 0 20px;">
            <div style="text-align: center; width: 150px;">
                <div style="border-top: 1px solid #000; padding-top: 5px;">Controller Exams</div>
            </div>
            <div style="text-align: center; width: 150px;">
                <div style="border-top: 1px solid #000; padding-top: 5px;">Principal</div>
            </div>
        </div>

    </div>
</div>

</div>
</div>
</body>

</html>