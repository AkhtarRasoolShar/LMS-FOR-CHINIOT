<?php
include 'admin_check.php'; // Includes security and sets $logged_in_user_id

$message = '';
$error = '';
$teacher_id_to_edit = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// --- FIX 1: Accessing the standardized session variable directly ---
$current_session_user_id = $_SESSION['user_id'];

if ($teacher_id_to_edit === 0) {
    die("Invalid teacher ID.");
}

// --- PART 1: Handle Form Submission (UPDATE) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_teacher'])) {
    // Note: teacher_id_to_edit is passed via a hidden field in the form
    $edit_id = (int)$_POST['edit_id'];
    $username = $_POST['username'];
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $main_subject = $_POST['main_subject'];
    $password = $_POST['password']; // May be empty
    $assignments = $_POST['new_assignments'] ?? []; // Array of class_id|subject_id

    $conn->begin_transaction();
    try {
        // 1. Update User Details (Conditionally update password)
        $password_sql = "";
        $password_hash = "";

        if (!empty($password)) {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $password_sql = "password_hash = ?, ";
        }

        $sql = "UPDATE teachers SET 
            username = ?, 
            {$password_sql} 
            role = ?, 
            full_name = ?, 
            email = ?, 
            main_subject = ? 
            WHERE teacher_id = ?";

        $stmt = $conn->prepare($sql);

        // Dynamic parameter binding
        $bind_types = "sssssi";
        $bind_params = [
            $username,
            $role,
            $full_name,
            $email,
            $main_subject,
            $edit_id
        ];

        if (!empty($password)) {
            // Prepend password hash and change type string
            array_unshift($bind_params, $password_hash);
            $bind_types = "s" . $bind_types;
        }

        // Bind parameters dynamically
        $stmt->bind_param($bind_types, ...$bind_params);
        $stmt->execute();
        $stmt->close();


        // 2. Clear Existing Assignments
        $stmt_clear = $conn->prepare("DELETE FROM teacher_assignments WHERE teacher_id = ?");
        $stmt_clear->bind_param("i", $edit_id);
        $stmt_clear->execute();
        $stmt_clear->close();


        // 3. Insert New Assignments
        if ($role == 'teacher' || $role == 'admin') {
            if (!empty($assignments)) {
                $stmt_assign = $conn->prepare("INSERT INTO teacher_assignments (teacher_id, class_id, class_name, subject_id) VALUES (?, ?, ?, ?)");

                foreach ($assignments as $assignment_pair) {
                    list($class_id, $subject_id) = explode('|', $assignment_pair);

                    // Fetch class name needed for the teacher_assignments table structure
                    $class_name_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
                    $class_name_stmt->bind_param("i", $class_id);
                    $class_name_stmt->execute();
                    $class_name = $class_name_stmt->get_result()->fetch_assoc()['class_name'] ?? '';
                    $class_name_stmt->close();

                    // Insert assignment
                    $stmt_assign->bind_param("iisi", $edit_id, $class_id, $class_name, $subject_id);
                    $stmt_assign->execute();
                }
                $stmt_assign->close();
            }
        }

        $conn->commit();
        $message = "Success! User $full_name updated successfully.";

        // Refresh the page to show new data without error messages in the URL
        header("Location: edit_teacher.php?id=" . $edit_id . "&status=" . urlencode($message));
        exit;
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        if ($e->getCode() == 1062) {
            $error = "Error: The username '{$username}' already exists. Please choose a different one.";
        } else {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}


// --- PART 2: Fetch Initial Data (GET) ---

// Get the user whose data is being edited
$user_stmt = $conn->prepare("SELECT teacher_id, username, full_name, email, role, main_subject FROM teachers WHERE teacher_id = ?");
$user_stmt->bind_param("i", $teacher_id_to_edit);
$user_stmt->execute();
$user_data = $user_stmt->get_result()->fetch_assoc();

if (!$user_data) {
    die("User not found.");
}
$user_stmt->close();


// Get the user's current assignments
$current_assignments = [];
$assignments_result = $conn->query("
    SELECT ta.class_id, ta.subject_id, c.class_name, s.subject_name 
    FROM teacher_assignments ta 
    JOIN classes c ON ta.class_id = c.class_id 
    JOIN subjects s ON ta.subject_id = s.subject_id 
    WHERE ta.teacher_id = $teacher_id_to_edit
    ORDER BY c.class_name, s.subject_name
");
if ($assignments_result) {
    while ($row = $assignments_result->fetch_assoc()) {
        $current_assignments[] = $row;
    }
}


// Get lists for the assignment form dropdowns (Classes and Class-Subject Map)
$full_classes_list = [];
$class_subject_map = [];
$classes_data_result = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");
if ($classes_data_result) {
    while ($row = $classes_data_result->fetch_assoc()) {
        $full_classes_list[] = $row;
    }
}
$class_subjects_result = $conn->query("
    SELECT cs.class_id, s.subject_id, s.subject_name 
    FROM class_subjects cs 
    JOIN subjects s ON cs.subject_id = s.subject_id 
    ORDER BY s.subject_name
");
if ($class_subjects_result) {
    while ($row = $class_subjects_result->fetch_assoc()) {
        $class_subject_map[$row['class_id']][] = [
            'subject_id' => $row['subject_id'],
            'subject_name' => $row['subject_name']
        ];
    }
}

// Get the list of all main subjects
$subjects_list = [];
$subjects_list_result = $conn->query("SELECT subject_name FROM subjects ORDER BY subject_name");
if ($subjects_list_result) {
    while ($row = $subjects_list_result->fetch_assoc()) {
        $subjects_list[] = $row['subject_name'];
    }
}

// Display status message from redirect
if (isset($_GET['status'])) {
    $message = htmlspecialchars($_GET['status']);
}

$conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit User: <?php echo htmlspecialchars($user_data['full_name']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 900px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group.assignments-area {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 4px;
            background: #fcfcfc;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        /* Multi-select styling */
        .assignment-selector {
            display: flex;
            gap: 10px;
            margin-bottom: 5px;
        }

        .assignment-selector select {
            flex: 1;
        }

        .assignment-selector button {
            width: 50px;
            padding: 5px 0;
            margin: 0;
            font-size: 14px;
            background: #006400;
            /* Green */
        }

        .assigned-list {
            list-style: none;
            padding: 0;
            margin-top: 10px;
        }

        .assigned-list li {
            background: #eee;
            padding: 5px 10px;
            border-radius: 4px;
            margin-bottom: 3px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9em;
        }

        .assigned-list li button {
            background: #b30000;
            /* Red */
            padding: 3px 8px;
            font-size: 12px;
        }


        button {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6fb;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Edit User: <?php echo htmlspecialchars($user_data['full_name']); ?></h1>
        <a href="manage_teachers.php">Back to List</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>"><?php echo $message; ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="message error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form action="edit_teacher.php?id=<?php echo $teacher_id_to_edit; ?>" method="POST" enctype="multipart/form-data" id="edit-teacher-form">
            <input type="hidden" name="edit_teacher" value="1">
            <input type="hidden" name="edit_id" value="<?php echo $teacher_id_to_edit; ?>">

            <h2>User Details</h2>

            <div class="form-group">
                <label for="full_name">Full Name</label>
                <input type="text" name="full_name" value="<?php echo htmlspecialchars($user_data['full_name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" value="<?php echo htmlspecialchars($user_data['username']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>">
            </div>
            <div class="form-group">
                <label for="password">Change Password (Leave blank to keep current password)</label>
                <input type="password" name="password">
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select name="role" id="role-select" required>
                    <option value="teacher" <?php echo ($user_data['role'] == 'teacher') ? 'selected' : ''; ?>>Teacher (Academics/Results)</option>
                    <option value="admin" <?php echo ($user_data['role'] == 'admin') ? 'selected' : ''; ?>>Administrator (Super User)</option>
                    <option value="FrontDesk" <?php echo ($user_data['role'] == 'FrontDesk') ? 'selected' : ''; ?>>FrontDesk (Admissions/Contact)</option>
                </select>
            </div>
            <div class="form-group" id="main-subject-group">
                <label for="main_subject">Main Subject (Used for Teacher Roster)</label>
                <select name="main_subject">
                    <option value="">-- Select Main Subject --</option>
                    <?php foreach ($subjects_list as $subject): ?>
                        <option value="<?php echo htmlspecialchars($subject); ?>" <?php echo ($user_data['main_subject'] == $subject) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($subject); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group assignments-area" id="multi-assignment-section">
                <label style="color: #b30000;">Current & New Class Assignments</label>

                <ul id="assigned-classes-list" class="assigned-list">
                    <?php
                    if (!empty($current_assignments)) {
                        foreach ($current_assignments as $assignment):
                            $assignmentValue = $assignment['class_id'] . '|' . $assignment['subject_id'];
                            $displayText = htmlspecialchars($assignment['class_name'] . ' / ' . $assignment['subject_name']);
                    ?>
                            <li>
                                <span><?php echo $displayText; ?></span>
                                <input type="hidden" name="new_assignments[]" value="<?php echo $assignmentValue; ?>">
                                <button type="button" onclick="this.parentNode.remove()">Remove</button>
                            </li>
                    <?php
                        endforeach;
                    }
                    ?>
                </ul>

                <div class="assignment-selector">
                    <select id="class-select-form" required>
                        <option value="">-- Select Class --</option>
                        <?php foreach ($full_classes_list as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>"><?php echo htmlspecialchars($class['class_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select id="subject-select-form" required disabled>
                        <option value="">-- Select Subject --</option>
                    </select>
                    <button type="button" onclick="addAssignment()">Add New</button>
                </div>
            </div>

            <button type="submit" style="margin-top: 15px;">Update User Details</button>
        </form>
    </div>

    <script>
        // Data maps needed for JS
        const classSubjectMap = <?php echo json_encode($class_subject_map); ?>;
        const classSelectForm = document.getElementById('class-select-form');
        const subjectSelectForm = document.getElementById('subject-select-form');
        const assignedList = document.getElementById('assigned-classes-list');
        const assignmentSection = document.getElementById('multi-assignment-section');
        const roleSelect = document.getElementById('role-select');
        const mainSubjectGroup = document.getElementById('main-subject-group');

        // Initial visibility check for assignment section
        document.addEventListener('DOMContentLoaded', () => {
            toggleAssignmentVisibility();
        });

        roleSelect.addEventListener('change', toggleAssignmentVisibility);

        function toggleAssignmentVisibility() {
            const role = roleSelect.value;
            // Only show assignment section and main subject for Teacher
            if (role === 'teacher') {
                assignmentSection.style.display = 'block';
                mainSubjectGroup.style.display = 'block';
            } else {
                assignmentSection.style.display = 'none';
                mainSubjectGroup.style.display = 'none';
            }
        }


        // Event listener to populate subjects when a class is selected
        classSelectForm.addEventListener('change', function() {
            const classId = this.value;
            subjectSelectForm.innerHTML = '<option value="">-- Select Subject --</option>';
            subjectSelectForm.disabled = true;

            if (classId && classSubjectMap[classId]) {
                const subjects = classSubjectMap[classId];
                subjects.forEach(subject => {
                    subjectSelectForm.innerHTML += `<option value="${subject.subject_id}">${subject.subject_name}</option>`;
                });
                subjectSelectForm.disabled = false;
            }
        });

        function addAssignment() {
            const classId = classSelectForm.value;
            const subjectId = subjectSelectForm.value;

            if (!classId || !subjectId) {
                alert("Please select both a Class and a Subject.");
                return;
            }

            // Get selected text names
            const className = classSelectForm.options[classSelectForm.selectedIndex].text;
            const subjectName = subjectSelectForm.options[subjectSelectForm.selectedIndex].text;

            // Unique identifier for this assignment
            const assignmentValue = `${classId}|${subjectId}`;

            // Check for duplicates (checks against existing hidden inputs)
            if (document.querySelector(`input[value="${assignmentValue}"]`)) {
                alert(`Assignment ${className} / ${subjectName} is already added.`);
                return;
            }

            // Create list item and hidden input
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <span>${className} / ${subjectName}</span>
                <input type="hidden" name="new_assignments[]" value="${assignmentValue}">
                <button type="button" onclick="this.parentNode.remove()">Remove</button>
            `;

            assignedList.appendChild(listItem);
        }
    </script>

</body>

</html>