<?php
// Note: This file ASSUMES admin_check.php has run and set $logged_in_user_name
$portalTitle = isset($portalTitle) ? $portalTitle : 'Teacher Portal';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo $portalTitle; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
        }

        .portal-main-header {
            background: #006400;
            /* Green theme */
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .portal-main-header h1 {
            margin: 0;
            font-size: 24px;
        }

        .portal-main-header .user-info {
            font-size: 14px;
            margin-right: 15px;
        }

        .portal-main-header a {
            color: #fdb813;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1000px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <div class="portal-main-header">
        <h1><?php echo $portalTitle; ?></h1>
        <div>
            <span class="user-info">Welcome, <?php echo htmlspecialchars($logged_in_user_name ?? 'Teacher'); ?></span>
            <a href="admin_logout.php">Logout</a>
        </div>
    </div>