<?php
include 'admin_check.php'; // Secure this page

$message = '';

// --- Handle adding a new assignment (SINGLE ASSIGNMENT) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_assignment'])) {

    $teacher_id = (int)$_POST['teacher_id'];
    $class_id = (int)$_POST['class_id'];
    $subject_id = (int)$_POST['subject_id'];

    if ($teacher_id === 0 || $class_id === 0 || $subject_id === 0) {
        $message = "Error: Please select a Teacher, a Class, and a Subject.";
    } else {
        $conn->begin_transaction();
        try {
            // 1. Check if subject is part of the class curriculum
            $check_stmt = $conn->prepare("SELECT class_subject_id FROM class_subjects WHERE class_id = ? AND subject_id = ?");
            $check_stmt->bind_param("ii", $class_id, $subject_id);
            $check_stmt->execute();

            if ($check_stmt->get_result()->num_rows == 0) {
                $check_stmt->close();
                throw new mysqli_sql_exception("Error: This subject is not in the curriculum for the selected class. Add it in 'Manage Classes' first.");
            }
            $check_stmt->close();

            // 2. Get the correct class_name before proceeding
            $class_name_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
            $class_name_stmt->bind_param("i", $class_id);
            $class_name_stmt->execute();
            $class_name = $class_name_stmt->get_result()->fetch_assoc()['class_name'];
            $class_name_stmt->close();


            // 3. Proceed with assignment
            // Use INSERT IGNORE to prevent immediate transaction failure on duplicate key,
            // then check for rows affected.
            // NOTE: The table structure has both class_id and class_name. We include both.
            $stmt = $conn->prepare("INSERT IGNORE INTO teacher_assignments (teacher_id, class_id, class_name, subject_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iisi", $teacher_id, $class_id, $class_name, $subject_id);
            $stmt->execute();

            if ($stmt->affected_rows === 0) {
                // If 0 rows affected, it was ignored (duplicate entry)
                $message = "Warning: This assignment already exists.";
            } else {
                $message = "Success! Assignment created.";
            }
            $stmt->close();

            $conn->commit();
        } catch (mysqli_sql_exception $exception) {
            $conn->rollback();
            $message = "Error: " . $exception->getMessage();
        }
    }
}

// --- Handle deleting an assignment ---
if (isset($_GET['delete'])) {
    $assignment_id = (int)$_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM teacher_assignments WHERE assignment_id = ?");
    $stmt->bind_param("i", $assignment_id);

    if ($stmt->execute()) {
        $message = "Assignment has been deleted.";
    } else {
        $message = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// --- Get data for the forms ---
$teachers_result = $conn->query("SELECT teacher_id, full_name FROM teachers WHERE role = 'teacher' ORDER BY full_name");
$classes_result_form = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");

// --- Get all current assignments to display in a list ---
// FIX: Ensure assignment_id is explicitly selected using its alias (ta.assignment_id)
$assignments_result = $conn->query("
    SELECT 
        ta.assignment_id,
        t.full_name AS teacher_name,
        c.class_name,
        s.subject_name
    FROM teacher_assignments ta
    JOIN teachers t ON ta.teacher_id = t.teacher_id
    JOIN subjects s ON ta.subject_id = s.subject_id
    JOIN classes c ON ta.class_id = c.class_id
    ORDER BY t.full_name, c.class_name, s.subject_name
");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Teacher Assignments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1000px;
            margin: auto;
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 30px;
        }

        .form-container,
        .table-container {
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        /* Reverting styles for single select */
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            height: auto;
            /* Reset height */
        }

        button {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        .list-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .list-table th,
        .list-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .list-table th {
            background: #f2f2f2;
        }

        .list-table a {
            color: #b30000;
            text-decoration: none;
        }

        #subject_id:disabled {
            background: #eee;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Manage Teacher Assignments</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">

        <div class="form-container">
            <h2>Assign a Teacher (Single Assignment)</h2>
            <?php if ($message): ?>
                <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>"><?php echo $message; ?></p>
            <?php endif; ?>

            <form action="manage_assignments.php" method="POST">
                <input type="hidden" name="add_assignment" value="1">
                <div class="form-group">
                    <label for="teacher_id">Select Teacher</label>
                    <select name="teacher_id" required>
                        <option value="">-- Select Teacher --</option>
                        <?php while ($row = $teachers_result->fetch_assoc()) {
                            echo "<option value='{$row['teacher_id']}'>" . htmlspecialchars($row['full_name']) . "</option>";
                        } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="class_id">Select Class</label>
                    <select id="class_id" name="class_id" required>
                        <option value="">-- Select Class --</option>
                        <?php while ($row = $classes_result_form->fetch_assoc()) {
                            echo "<option value='{$row['class_id']}'>" . htmlspecialchars($row['class_name']) . "</option>";
                        } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="subject_id">Select Subject (from Class Curriculum)</label>
                    <select id="subject_id" name="subject_id" required disabled>
                        <option value="">-- Select Class First --</option>
                    </select>
                </div>
                <button type="submit">Add Assignment</button>
            </form>
        </div>

        <div class="table-container">
            <h2>Current Assignments</h2>
            <table class="list-table">
                <thead>
                    <tr>
                        <th>Teacher</th>
                        <th>Class</th>
                        <th>Subject</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($assignments_result) {
                        while ($row = $assignments_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['teacher_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['class_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                                <td>
                                    <a href="manage_assignments.php?delete=<?php echo $row['assignment_id']; ?>"
                                        onclick="return confirm('Are you sure you want to delete this assignment?');">Delete</a>
                                </td>
                            </tr>
                    <?php endwhile;
                    } ?>
                </tbody>
            </table>
        </div>

    </div>

    <script>
        const classSelect = document.getElementById('class_id');
        const subjectSelect = document.getElementById('subject_id');

        // Handles loading subjects when a class is selected
        classSelect.addEventListener('change', () => {
            const classId = classSelect.value;

            subjectSelect.innerHTML = '<option value="">Loading...</option>';
            subjectSelect.disabled = true;

            if (!classId) {
                subjectSelect.innerHTML = '<option value="">-- Select Class First --</option>';
                return;
            }

            // Calls the AJAX script to fetch subjects associated with the class curriculum
            fetch(`ajax_get_class_subjects.php?class_id=${classId}`)
                .then(response => response.json())
                .then(data => {
                    subjectSelect.innerHTML = '<option value="">-- Select Subject --</option>';
                    if (data.length > 0) {
                        data.forEach(subject => {
                            // subject.subject_id and subject.subject_name are retrieved from class_subjects table
                            subjectSelect.innerHTML += `<option value="${subject.subject_id}">${subject.subject_name}</option>`;
                        });
                        subjectSelect.disabled = false;
                    } else {
                        subjectSelect.innerHTML = '<option value="">-- No subjects in curriculum --</option>';
                        subjectSelect.disabled = false;
                    }
                })
                .catch(error => {
                    console.error('Error fetching subjects:', error);
                    subjectSelect.innerHTML = '<option value="">-- Error loading --</option>';
                    subjectSelect.disabled = true;
                });
        });
    </script>

</body>

</html>