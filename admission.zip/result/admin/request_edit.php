<?php
include 'admin_check.php'; // --- SECURITY FIRST ---
$message = '';
$error = '';

// --- FIX: Use the standardized session variable 'user_id' ---
$logged_in_teacher_id = $_SESSION['user_id'];

// Get all classes assigned to THIS teacher for the dropdown
$class_stmt = $conn->prepare("
    SELECT DISTINCT c.class_id, c.class_name 
    FROM teacher_assignments ta
    JOIN classes c ON ta.class_id = c.class_id
    WHERE ta.teacher_id = ? 
    ORDER BY c.class_name
");
$class_stmt->bind_param("i", $logged_in_teacher_id);
$class_stmt->execute();
$class_result = $class_stmt->get_result();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = (int)$_POST['student_id'];
    $term_name = $_POST['term_name'];
    $reason = $_POST['reason'];
    $requested_by_id = $logged_in_teacher_id; // Teacher's ID

    if (empty($student_id) || empty($term_name) || empty($reason)) {
        $error = "All fields are required.";
    } else {
        // Check if a PENDING request for this already exists
        $check_stmt = $conn->prepare("SELECT request_id FROM result_edit_requests WHERE student_id = ? AND term_name = ? AND status = 'Pending'");
        $check_stmt->bind_param("is", $student_id, $term_name);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows > 0) {
            $error = "An unlock request for this student and term is already pending.";
        } else {
            // Insert the new request
            $stmt = $conn->prepare("INSERT INTO result_edit_requests (student_id, term_name, reason, requested_by_id, status) VALUES (?, ?, ?, ?, 'Pending')");
            $stmt->bind_param("issi", $student_id, $term_name, $reason, $requested_by_id);
            if ($stmt->execute()) {
                $message = "Unlock request has been sent to the Super Admin for approval.";
            } else {
                $error = "Error: Could not send request.";
            }
            $stmt->close();
        }
        $check_stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Request Result Edit</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #006400;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 800px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #006400;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 44px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Request Result Unlock</h1>
        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?><p class="message"><?php echo $message; ?></p><?php endif; ?>
        <?php if ($error): ?><p class="message error"><?php echo $error; ?></p><?php endif; ?>

        <form action="request_edit.php" method="POST">
            <p>Select a student and term to request an unlock from the Super Admin. You will be notified when the result is ready for editing.</p>
            <div class="form-group">
                <label for="class_select">Select Class</label>
                <select id="class_select" name="class_id" required>
                    <option value="">-- Select Class --</option>
                    <?php
                    // Rewind and use the class results fetched at the top
                    $class_result->data_seek(0);
                    while ($class = $class_result->fetch_assoc()): ?>
                        <option value="<?php echo $class['class_id']; ?>"><?php echo htmlspecialchars($class['class_name']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="student_id">Select Student</label>
                <select id="student_id" name="student_id" required>
                    <option value="">-- First Select a Class --</option>
                </select>
            </div>
            <div class="form-group">
                <label for="term_name">Select Term</label>
                <select id="term_name" name="term_name" required>
                    <option value="">-- Select a Term --</option>
                    <option value="1st QUARTERLY">1st QUARTERLY</option>
                    <option value="MID TERM">MID TERM (1st Term)</option>
                    <option value="2nd QUARTERLY">2nd QUARTERLY</option>
                    <option value="FINAL TERM">FINAL TERM (2nd Term)</option>
                </select>
            </div>
            <div class="form-group">
                <label for="reason">Reason for Unlock</label>
                <textarea id="reason" name="reason" rows="4" required></textarea>
            </div>
            <button type="submit">Send Unlock Request</button>
        </form>
    </div>

    <script>
        document.getElementById('class_select').addEventListener('change', function() {
            const classId = this.value;
            const studentSelect = document.getElementById('student_id');
            studentSelect.innerHTML = '<option value="">Loading...</option>';

            if (!classId) {
                studentSelect.innerHTML = '<option value="">-- First Select a Class --</option>';
                return;
            }

            // Path goes UP one level, then to the existing teacher-specific student AJAX file
            fetch(`../ajax_get_students.php?class_id=${classId}`)
                .then(response => response.json())
                .then(data => {
                    studentSelect.innerHTML = '<option value="">-- Select a Student --</option>';
                    data.forEach(student => {
                        studentSelect.innerHTML += `<option value="${student.student_id}">${student.name} (ID: ${student.student_id})</option>`;
                    });
                })
                .catch(error => {
                    studentSelect.innerHTML = '<option value="">Error loading students.</option>';
                });
        });
    </script>
</body>

</html>