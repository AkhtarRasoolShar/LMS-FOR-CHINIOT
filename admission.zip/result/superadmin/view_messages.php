<?php
// Secure this page! This checks if the user's role is 'admin'.
include 'admin_check.php';

$message = '';
// --- Handle message actions (e.g., Delete or Mark as Read) ---
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $message_id = (int)$_GET['id'];

    if ($action == 'delete') {
        $stmt = $conn->prepare("DELETE FROM contact_messages WHERE message_id = ?");
        $stmt->bind_param("i", $message_id);
        if ($stmt->execute()) {
            $message = "Message deleted successfully.";
        } else {
            $message = "Error deleting message.";
        }
        $stmt->close();
    } elseif ($action == 'read') {
        $stmt = $conn->prepare("UPDATE contact_messages SET is_read = 1 WHERE message_id = ?");
        $stmt->bind_param("i", $message_id);
        if ($stmt->execute()) {
            $message = "Message marked as read.";
        } else {
            $message = "Error marking message as read.";
        }
        $stmt->close();
    }
    // Redirect to clean the URL after action
    header("Location: view_messages.php?status=" . urlencode($message));
    exit();
}

// Check for status message from redirect
if (isset($_GET['status'])) {
    $message = htmlspecialchars($_GET['status']);
}

// --- Fetch all contact messages ---
$sql = "SELECT * FROM contact_messages ORDER BY is_read ASC, sent_at DESC";
$messages_result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>View Contact Messages</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1000px;
            margin: auto;
        }

        .table-container {
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .message-alert {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .list-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .list-table th,
        .list-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            vertical-align: top;
        }

        .list-table th {
            background: #f2f2f2;
        }

        .unread {
            background-color: #fff3cd;
            /* Light yellow for unread */
            font-weight: bold;
        }

        .actions-link {
            color: #006400;
            text-decoration: none;
            margin-right: 5px;
        }

        .actions-link-danger {
            color: #b30000;
            text-decoration: none;
        }

        .message-body {
            white-space: pre-wrap;
            /* Preserve whitespace and line breaks */
            max-height: 100px;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Contact Messages Inbox</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message-alert"><?php echo $message; ?></p>
        <?php endif; ?>

        <div class="table-container">
            <h2>All Messages Received</h2>
            <table class="list-table">
                <thead>
                    <tr>
                        <th style="width: 10%;">Date</th>
                        <th style="width: 20%;">Sender</th>
                        <th style="width: 25%;">Subject</th>
                        <th style="width: 35%;">Message Preview</th>
                        <th style="width: 10%;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $messages_result->fetch_assoc()): ?>
                        <tr class="<?php echo ($row['is_read'] == 0) ? 'unread' : ''; ?>">
                            <td><?php echo date('M j, Y', strtotime($row['sent_at'])); ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($row['sender_name']); ?></strong><br>
                                <small><?php echo htmlspecialchars($row['sender_email']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($row['subject']); ?></td>
                            <td>
                                <div class="message-body"><?php echo htmlspecialchars($row['message_body']); ?></div>
                            </td>
                            <td>
                                <?php if ($row['is_read'] == 0): ?>
                                    <a href="view_messages.php?action=read&id=<?php echo $row['message_id']; ?>" class="actions-link">Mark Read</a>
                                <?php endif; ?>
                                <a href="view_messages.php?action=delete&id=<?php echo $row['message_id']; ?>"
                                    class="actions-link-danger"
                                    onclick="return confirm('Are you sure you want to delete this message?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    <?php if ($messages_result->num_rows == 0): ?>
                        <tr>
                            <td colspan="5" style="text-align: center;">No contact messages have been received.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>