<?php 
$pageTitle = "Print Admit Card";
include 'header.php'; 

$error_message = '';
if (isset($_GET['error'])) {
    if ($_GET['error'] == 'not_found') {
        $error_message = 'Application Form Number not found. Please check your number and try again.';
    }
}
?>

<style>
    .login-container {
        max-width: 500px; /* Narrower for this form */
        margin: 30px auto;
    }
    .login-form h1 {
        color: #004a99; /* Blue */
        margin-top: 0;
        margin-bottom: 20px;
        font-size: 22px;
        text-align: center;
    }
    .form-group {
        margin-bottom: 15px;
    }
    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
        color: #555;
    }
    .form-group input {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    .login-btn {
        background-color: #004a99; /* Blue */
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
        font-weight: bold;
        width: 100%;
        margin-top: 10px;
    }
    .login-btn:hover {
        background-color: #003b7a;
    }
    .error-message {
        color: #dc3545;
        background: #f8d7da;
        border: 1px solid #f5c6cb;
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 15px;
        font-weight: bold;
        text-align: center;
    }
</style>

<div class="container-padded login-container">
    <form class="login-form" action="/chiniot/result/download_admit_card.php" method="POST" target="_blank">
        <img src="/chiniot/logos.png" alt="School Logo" style="width: 80px; margin: 0 auto 15px auto; display: block;">
        <h1>Print Admit Card</h1>
        
        <?php if ($error_message): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>

        <p style="text-align: center; color: #555;">Please enter your Application Form Number (e.g., APP-XXXXXX) to download your admit card.</p>

        <div class="form-group">
            <label for="form_no">Application Form No.</label>
            <input type="text" id="form_no" name="form_no" required>
        </div>
        <button type="submit" class="login-btn">Download Card</button>
    </form>
</div>

<?php include 'footer.php'; ?>

<?php 
// NOTE: The fatal error was actually happening in the file this page submits to, 
// result/download_admit_card.php, not here. We must ensure that file is correct too.

// If you are still seeing the error, please check result/download_admit_card.php
// and ensure the SQL query there is not attempting to select or filter by 'phone'.
?>