<?php
session_start(); // Start session at the top
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = (int)$_POST['student_id'];
    $term_name = $_POST['term_name'];

    // Fetch the student's data AND their class template
    $stmt = $conn->prepare("
        SELECT s.*, c.report_template 
        FROM students s
        LEFT JOIN classes c ON s.class LIKE CONCAT('%', c.class_name, '%')
        WHERE s.student_id = ?
    ");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();

        // --- !!! UPDATED FEE CHECK !!! ---
        if ($student['is_fee_paid'] == 0) { // 0 = Not Paid
            // Store student details for verification display
            $_SESSION['unpaid_student_details'] = [
                'student_id' => $student['student_id'],
                'name' => $student['name'],
                'f_name' => $student['f_name'],
                'class' => $student['class']
            ];
            // Redirect back to login with a specific error
            header("Location: index.php?error=fee_unpaid");
            exit;
        }
        // --- END OF UPDATED FEE CHECK ---

        // Clear any old unpaid details if login is successful
        if (isset($_SESSION['unpaid_student_details'])) {
            unset($_SESSION['unpaid_student_details']);
        }

        // Store data for viewing the result
        $_SESSION['student_data'] = $student;
        $_SESSION['term_name'] = $term_name;

        $template = $student['report_template'];

        // Route to the correct report card template
        if ($template == 'primary') {
            header("Location: view_result_primary.php");
            exit;
        } else {
            // Default template
            header("Location: view_result.php");
            exit;
        }
    } else {
        // No student found
        header("Location: index.php?error=not_found");
        exit;
    }
} else {
    // Not a POST request
    header("Location: index.php");
    exit;
}
