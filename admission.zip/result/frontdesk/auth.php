<?php
session_start();
require '../db.php'; // Connect to the database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    // Prepare statement to find the user with role 'FrontDesk'
    $stmt = $conn->prepare("SELECT teacher_id, password_hash, role, full_name FROM teachers WHERE username = ? AND role = 'FrontDesk'");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        // Verify the hashed password
        if (password_verify($password, $user['password_hash'])) {
            // Password is correct! Set session variables
            $_SESSION['user_id'] = $user['teacher_id'];
            $_SESSION['username'] = $username;
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role']; // Will be 'FrontDesk'

            // Redirect to the front desk dashboard
            header("Location: dashboard.php");
            exit;
        }
    }

    // If login fails (user not found or wrong password)
    header("Location: frontdesk_login.php?error=1");
    exit;
} else {
    // Not a POST request
    header("Location: frontdesk_login.php");
    exit;
}
