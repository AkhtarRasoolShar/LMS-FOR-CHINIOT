<?php
session_start();
include '../db.php'; // Database connection (up one level)

// 1. Check if logged in
if (!isset($_SESSION['teacher_id'])) {
    // Not logged in, send to the login page
    header("Location: admin_login.php");
    exit();
}

// 2. Check the role. If 'admin' or 'FrontDesk', send to super-admin dashboard
if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'FrontDesk') {
    header("Location: ../superadmin/dashboard.php");
    exit();
}

// If we are here, user is a logged-in 'teacher'.
// $logged_in_teacher_id is available from $_SESSION['teacher_id']
$logged_in_teacher_id = $_SESSION['teacher_id'];
