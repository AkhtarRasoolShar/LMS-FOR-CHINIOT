<?php
include 'admin_check.php'; // Secure this page

$message = '';
$selected_class_id = $_GET['class_id'] ?? null; // Get the ID from the URL

// --- Handle Adding a New Class ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_class'])) {
    $class_name = $_POST['class_name'];
    $report_template = $_POST['report_template'];

    $stmt = $conn->prepare("INSERT INTO classes (class_name, report_template) VALUES (?, ?)");
    $stmt->bind_param("ss", $class_name, $report_template);
    if ($stmt->execute()) {
        $message = "Success! Class '$class_name' created.";
    } else {
        $message = "Error: Class name may already exist. " . $stmt->error;
    }
    $stmt->close();
}

// --- Handle Adding a Subject to a Class Curriculum ---
if (isset($_GET['add_subject'])) {
    $subject_id = (int)$_GET['add_subject'];
    $stmt = $conn->prepare("INSERT INTO class_subjects (class_id, subject_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $selected_class_id, $subject_id);
    if ($stmt->execute()) {
        $message = "Subject added to curriculum.";
    } else {
        if ($conn->errno == 1062) { // Duplicate entry error code
            $message = "Error: Subject is already assigned to this class.";
        } else {
            $message = "Error: " . $stmt->error;
        }
    }
    $stmt->close();
}

// --- Handle Removing a Subject from a Class Curriculum ---
if (isset($_GET['remove_subject'])) {
    $subject_id = (int)$_GET['remove_subject'];
    $stmt = $conn->prepare("DELETE FROM class_subjects WHERE class_id = ? AND subject_id = ?");
    $stmt->bind_param("ii", $selected_class_id, $subject_id);
    if ($stmt->execute()) {
        $message = "Subject removed from curriculum.";
    } else {
        $message = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// --- Get Data for Page ---
$classes_result = $conn->query("SELECT * FROM classes ORDER BY class_name");

$subjects_in_curriculum = [];
$subjects_not_in_curriculum = [];
$selected_class_name = '';

if ($selected_class_id) {
    // Get the name of the selected class
    $class_name_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
    $class_name_stmt->bind_param("i", $selected_class_id);
    $class_name_stmt->execute();
    $class_data = $class_name_stmt->get_result()->fetch_assoc();
    $selected_class_name = $class_data ? $class_data['class_name'] : 'N/A';
    $class_name_stmt->close();

    // Get subjects IN this class
    $stmt_in = $conn->prepare("
        SELECT s.subject_id, s.subject_name 
        FROM subjects s
        JOIN class_subjects cs ON s.subject_id = cs.subject_id
        WHERE cs.class_id = ?
        ORDER BY s.subject_name
    ");
    $stmt_in->bind_param("i", $selected_class_id);
    $stmt_in->execute();
    $result_in = $stmt_in->get_result();
    while ($row = $result_in->fetch_assoc()) {
        $subjects_in_curriculum[] = $row;
    }
    $stmt_in->close();

    // Get subjects NOT IN this class
    $stmt_out = $conn->prepare("
        SELECT s.subject_id, s.subject_name
        FROM subjects s
        WHERE s.subject_id NOT IN (
            SELECT subject_id FROM class_subjects WHERE class_id = ?
        )
        ORDER BY s.subject_name
    ");
    $stmt_out->bind_param("i", $selected_class_id);
    $stmt_out->execute();
    $result_out = $stmt_out->get_result();
    while ($row = $result_out->fetch_assoc()) {
        $subjects_not_in_curriculum[] = $row;
    }
    $stmt_out->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Classes & Curriculum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
        }

        .grid-container {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 30px;
        }

        .form-container,
        .table-container {
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        h3 {
            padding: 10px 15px;
            margin: 0;
            background: #f9f9f9;
            border-bottom: 1px solid #ddd;
            color: #b30000;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        .list-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .list-table th,
        .list-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .list-table th {
            background: #f2f2f2;
        }

        .list-table a {
            color: #006400;
            text-decoration: none;
        }

        .list-table a.danger {
            color: #b30000;
        }

        .curriculum-manager {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .subject-box {
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        .subject-box h3 {
            padding: 10px 15px;
            margin: 0;
            background: #f2f2f2;
            border-bottom: 1px solid #ddd;
            color: #b30000;
            font-size: 1.1em;
            font-weight: bold;
        }

        .subject-list {
            padding: 15px;
            max-height: 400px;
            overflow-y: auto;
        }

        .subject-list div {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px;
            border-bottom: 1px solid #eee;
        }

        .subject-list div:last-child {
            border-bottom: none;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Manage Classes & Curriculum</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">

        <?php if ($message): ?>
            <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>"><?php echo $message; ?></p>
        <?php endif; ?>

        <div class="grid-container">
            <div>
                <div class="form-container">
                    <h2>1. Add New Class</h2>
                    <form action="manage_classes.php" method="POST">
                        <input type="hidden" name="add_class" value="1">
                        <div class="form-group">
                            <label for="class_name">Class Name (e.g., "IV-D" or "SS X-A")</label>
                            <input type="text" name="class_name" required>
                        </div>
                        <div class="form-group">
                            <label for="report_template">Report Card Type</label>
                            <select name="report_template" required>
                                <option value="college">College (Matric/Inter calc)</option>
                                <option value="primary">Primary (Junior Section calc)</option>
                            </select>
                        </div>
                        <button type="submit">Add Class</button>
                    </form>
                </div>

                <div class="table-container">
                    <h2>2. All Classes</h2>
                    <p>Click on a class to manage its subject curriculum.</p>
                    <table class="list-table">
                        <thead>
                            <tr>
                                <th>Class Name</th>
                                <th>Report Type</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($classes_result) {
                                $classes_result->data_seek(0);
                                while ($row = $classes_result->fetch_assoc()): ?>
                                    <tr style="<?php if ($row['class_id'] == $selected_class_id) echo 'background-color: #f0f8ff; border: 2px solid #006400;'; ?>">
                                        <td><?php echo htmlspecialchars($row['class_name']); ?></td>
                                        <td><?php echo ucfirst($row['report_template']); ?></td>
                                        <td>
                                            <a href="manage_classes.php?class_id=<?php echo $row['class_id']; ?>" style="color: #006400;">Manage Curriculum</a>
                                        </td>
                                    </tr>
                            <?php endwhile;
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if ($selected_class_id): ?>
                <div class="table-container">
                    <h2>3. Curriculum: <?php echo htmlspecialchars($selected_class_name); ?></h2>
                    <div class="curriculum-manager">
                        <div class="subject-box">
                            <h3>Subjects IN Curriculum (<?php echo count($subjects_in_curriculum); ?>)</h3>
                            <div class="subject-list">
                                <?php foreach ($subjects_in_curriculum as $subject): ?>
                                    <div>
                                        <span><?php echo htmlspecialchars($subject['subject_name']); ?></span>
                                        <a href="manage_classes.php?class_id=<?php echo $selected_class_id; ?>&remove_subject=<?php echo $subject['subject_id']; ?>" class="danger"
                                            onclick="return confirm('WARNING: Are you sure you want to remove <?php echo htmlspecialchars($subject['subject_name']); ?> from this class? This may affect teacher assignments.');">Remove</a>
                                    </div>
                                <?php endforeach; ?>
                                <?php if (empty($subjects_in_curriculum)) echo "<p>No subjects assigned.</p>"; ?>
                            </div>
                        </div>

                        <div class="subject-box">
                            <h3>Subjects NOT in Curriculum (<?php echo count($subjects_not_in_curriculum); ?>)</h3>
                            <div class="subject-list">
                                <?php foreach ($subjects_not_in_curriculum as $subject): ?>
                                    <div>
                                        <span><?php echo htmlspecialchars($subject['subject_name']); ?></span>
                                        <a href="manage_classes.php?class_id=<?php echo $selected_class_id; ?>&add_subject=<?php echo $subject['subject_id']; ?>" style="color: #b30000;">+ Add</a>
                                    </div>
                                <?php endforeach; ?>
                                <?php if (empty($subjects_not_in_curriculum)) echo "<p>All subjects are assigned.</p>"; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    </div>
</body>

</html>