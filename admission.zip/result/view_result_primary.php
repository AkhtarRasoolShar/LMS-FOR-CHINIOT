<?php
session_start(); // Start the session
$pageTitle = "Student Results"; // This will set the "active" class in your header
include '../header.php'; // Use main site header
include 'db.php';

// --- Get student data from the SESSION, not the URL ---
if (!isset($_SESSION['student_data']) || !isset($_SESSION['term_name'])) {
    // If session data is missing, redirect to login
    header("Location: /chiniot/result/index.php?error=session_expired");
    exit;
}

$student = $_SESSION['student_data'];
$student_id = (int)$student['student_id'];
$term_name = $_SESSION['term_name'];
$year_session = date('Y');
// --- END OF FIX ---


// 1. Student Info is already in $student variable
if (!isset($student['class_id'])) {
    $class_stmt = $conn->prepare("
        SELECT c.class_id, c.report_template 
        FROM classes c 
        WHERE ? LIKE CONCAT('%', c.class_name, '%')
    ");
    $class_stmt->bind_param("s", $student['class']);
    $class_stmt->execute();
    $class_data = $class_stmt->get_result()->fetch_assoc();
    $student['class_id'] = $class_data['class_id'] ?? 0;
    $class_stmt->close();
}

// 2. Get All Subjects for this student's class
$subjects_stmt = $conn->prepare("
    SELECT s.subject_id, s.subject_name 
    FROM class_subjects cs
    JOIN subjects s ON cs.subject_id = s.subject_id
    WHERE cs.class_id = ?
    ORDER BY s.subject_id
");
$subjects_stmt->bind_param("i", $student['class_id']);
$subjects_stmt->execute();
$subjects_result = $subjects_stmt->get_result();
$subjects = [];
while ($row = $subjects_result->fetch_assoc()) {
    $subjects[] = $row;
}
$subjects_stmt->close();


// 3. Get ALL Results and Summary for the selected term
$results = [];
$res_stmt = $conn->prepare("
    SELECT subject_id, marks_obtained, total_marks 
    FROM results 
    WHERE student_id = ? AND term_name = ?
");
$res_stmt->bind_param("is", $student_id, $term_name);
$res_stmt->execute();
$res_result = $res_stmt->get_result();
while ($row = $res_result->fetch_assoc()) {
    $results[$row['subject_id']] = $row; // Keyed by subject_id
}
$res_stmt->close();

// 4. Get summary data
$sum_stmt = $conn->prepare("
    SELECT * FROM summaries 
    WHERE student_id = ? AND term_name = ?
");
$sum_stmt->bind_param("is", $student_id, $term_name);
$sum_stmt->execute();
$summary = $sum_stmt->get_result()->fetch_assoc();
$sum_stmt->close();

$conn->close();

// --- Data for the graph ---
$js_subject_labels = [];
$js_subject_percents = [];
foreach ($subjects as $sub) {
    $marks = $results[$sub['subject_id']]['marks_obtained'] ?? 0;
    $total = $results[$sub['subject_id']]['total_marks'] ?? 0;
    $percent = ($total > 0) ? ($marks / $total) * 100 : 0;

    $js_subject_labels[] = $sub['subject_name'];
    $js_subject_percents[] = $percent;
}
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    .report-card {
        max-width: 800px;
        margin: auto;
        background: #fff;
        border: 1px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-top: 30px;
        /* Added margin from header */
    }

    .report-header {
        display: flex;
        align-items: center;
        padding: 20px;
        border-bottom: 2px solid #004a99;
        /* Blue */
    }

    .report-header img {
        height: 80px;
        margin-right: 20px;
    }

    .report-header h1 {
        color: #004a99;
        /* Blue */
        margin: 0;
        font-size: 20px;
    }

    .report-header h2 {
        margin: 0;
        font-size: 16px;
        color: #555;
    }

    .title {
        text-align: center;
        background: #004a99;
        /* Blue */
        color: white;
        padding: 10px;
        font-size: 24px;
        font-weight: bold;
    }

    .student-info {
        padding: 20px;
        border-bottom: 1px solid #eee;
    }

    .info-table {
        width: 100%;
        border-collapse: collapse;
    }

    .info-table td {
        padding: 5px;
        font-size: 14px;
    }

    .info-table td:first-child {
        font-weight: bold;
        width: 100px;
    }

    .content {
        padding: 20px;
    }

    .term-title {
        font-size: 18px;
        font-weight: bold;
        color: #004a99;
        /* Blue */
        border-bottom: 1px solid #ccc;
        padding-bottom: 5px;
        margin-bottom: 15px;
    }

    .results-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    .results-table th,
    .results-table td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: center;
        font-size: 14px;
    }

    .results-table th {
        background: #f2f2f2;
    }

    .results-table .subject-name {
        text-align: left;
        font-weight: bold;
    }

    .summary-section {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .summary-table {
        width: 100%;
        border-collapse: collapse;
    }

    .summary-table th {
        background: #004a99;
        /* Blue */
        color: white;
        padding: 8px;
        font-size: 16px;
    }

    .summary-table td {
        border: 1px solid #ccc;
        padding: 8px;
        font-size: 14px;
    }

    .summary-table td:first-child {
        font-weight: bold;
        background: #f2f2f2;
    }

    .graph-container {
        width: 100%;
        height: 250px;
    }

    @media print {
        body {
            background: #fff;
            padding: 0;
        }

        .report-card {
            box-shadow: none;
            border: none;
            max-width: 100%;
            margin-top: 0;
        }

        .summary-section {
            grid-template-columns: 1fr;
        }

        /* Hide main nav on print */
        .header,
        .nav,
        .footer {
            display: none;
        }
    }
</style>

<div class="report-card">
    <div class="report-header">
        <img src="/chiniot/img/logos.png" alt="School Logo">
        <div>
            <h1>CHINIOT ISLAMIA PUBLIC SCHOOL & COLLEGE</h1>
            <h2>E-REPORT CARD (PRIMARY)</h2>
        </div>
    </div>
    <div class="title">
        E-REPORT CARD <?php echo htmlspecialchars($year_session); ?> - <?php echo htmlspecialchars($term_name); ?>
    </div>

    <div class="student-info">
        <table class="info-table">
            <tr>
                <td>S.NO:</td>
                <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                <td>GENDER:</td>
                <td><?php echo htmlspecialchars($student['gender']); ?></td>
            </tr>
            <tr>
                <td>NAME:</td>
                <td><?php echo htmlspecialchars($student['name']); ?></td>
                <td>CLASS:</td>
                <td><?php echo htmlspecialchars($student['class']); ?></td>
            </tr>
            <tr>
                <td>F.NAME:</td>
                <td colspan="3"><?php echo htmlspecialchars($student['f_name']); ?></td>
            </tr>
        </table>
    </div>

    <div class="content">
        <div class="term-title"><?php echo htmlspecialchars($term_name); ?></div>
        <table class="results-table">
            <thead>
                <tr>
                    <th>SUBJECTS</th>
                    <th>MARKS OBTAINED</th>
                    <th>TOTAL MARKS</th>
                    <th>%</th>
                </tr>
            </thead>
            <tbody id="subject-data-tbody">
                <?php
                foreach ($subjects as $sub):
                    $sub_id = $sub['subject_id'];
                    $sub_name = $sub['subject_name'];

                    $marks = $results[$sub_id]['marks_obtained'] ?? '0.00';
                    $total = $results[$sub_id]['total_marks'] ?? '0';
                    $percent = ($total > 0) ? ($marks / $total) * 100 : 0;
                ?>
                    <tr>
                        <td class="subject-name"><?php echo htmlspecialchars($sub_name); ?></td>
                        <td><?php echo htmlspecialchars($marks); ?></td>
                        <td><?php echo htmlspecialchars($total); ?></td>
                        <td><?php echo number_format($percent, 2); ?>%</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="summary-section">
            <div>
                <table class="summary-table">
                    <thead>
                        <tr>
                            <th colspan="2">SUMMARY</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>OUT OF MARKS</td>
                            <td><?php echo $summary['out_of_marks'] ?? '0'; ?></td>
                        </tr>
                        <tr>
                            <td>OBTAINED MARKS</td>
                            <td><?php echo $summary['obtained_marks'] ?? '0.00'; ?></td>
                        </tr>
                        <tr>
                            <td>PERCENTAGE</td>
                            <td><?php echo $summary['percentage'] ?? '0.00'; ?>%</td>
                        </tr>
                        <tr>
                            <td>RANK</td>
                            <td><?php echo htmlspecialchars($summary['rank'] ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td>GRADE</td>
                            <td><?php echo htmlspecialchars($summary['grade'] ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td>ATTENDANCE</td>
                            <td><?php echo htmlspecialchars($summary['attendance'] ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td>REMARKS</td>
                            <td><?php echo htmlspecialchars($summary['remarks'] ?? '-'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="graph-container">
                <canvas id="subjectGraph"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('subjectGraph').getContext('2d');

        const subjectLabels = <?php echo json_encode($js_subject_labels); ?>;
        const subjectData = <?php echo json_encode($js_subject_percents); ?>;

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: subjectLabels,
                datasets: [{
                    label: '<?php echo htmlspecialchars($term_name); ?> %',
                    data: subjectData,
                    backgroundColor: 'rgba(0, 74, 153, 0.6)', // Blue
                    borderColor: 'rgba(0, 74, 153, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%'
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true
                    },
                    title: {
                        display: true,
                        text: 'Subject Percentage (<?php echo htmlspecialchars($term_name); ?>)'
                    }
                }
            }
        });
    });
</script>

<?php
// We must go UP one directory to include the main site footer
include '../footer.php';
?>