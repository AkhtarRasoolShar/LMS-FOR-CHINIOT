<?php
// We need to check admission status for the header
// We'll use @ to suppress errors if db.php is already included
@include_once 'result/db.php';

$admissions_status = 'closed'; // Default to closed
try {
    if (isset($conn) && $conn->ping()) { // Check if connection is active
        $sql = "SELECT setting_value FROM system_settings WHERE setting_name = 'admissions_status'";
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            $status_row = $result->fetch_assoc();
            $admissions_status = $status_row['setting_value'];
        } else {
            error_log("Warning: 'system_settings' table or 'admissions_status' row not found. Defaulting to closed.");
        }
        // Don't close the connection here, other pages might need it
    } else if (!isset($conn)) {
        // This handles cases where db.php is not included, like on the main index.php before the body
        @include_once 'result/db.php';
        if (isset($conn)) {
            $sql = "SELECT setting_value FROM system_settings WHERE setting_name = 'admissions_status'";
            $result = $conn->query($sql);
            if ($result && $result->num_rows > 0) {
                $status_row = $result->fetch_assoc();
                $admissions_status = $status_row['setting_value'];
            }
            $conn->close(); // We can close it here
        }
    }
} catch (Exception $e) {
    error_log("Database connection error on header.php: " . $e->getMessage());
    $admissions_status = 'closed'; // Safely default to closed
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - Chiniot Islamia' : 'Chiniot Islamia Public School & College'; ?></title>

    <link rel="stylesheet" href="/chiniot/css/style.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
        /* --- Base Styles --- */
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            margin: 0;
            background-color: #fff;
            /* Clean white background */
            color: #333;
        }

        .container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 0;
            background: none;
            box-shadow: none;
        }

        .container-padded {
            max-width: 1000px;
            margin: 30px auto;
            padding: 30px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        .container-padded h2 {
            color: #004a99;
            /* Professional Blue */
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
            margin-top: 0;
            font-size: 2.2em;
        }

        .container-padded h3 {
            color: #004a99;
            /* Professional Blue */
            margin-top: 30px;
            font-size: 1.8em;
        }

        .home .container {
            padding: 0;
        }

        /* --- New Header/Nav Colors --- */
        .header {
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 0;
            /* Removed padding */
            border-bottom: 3px solid #fdb813;
            /* Gold border */
        }

        /* --- NEW: Top Contact Bar --- */
        .header-top-bar {
            background: #004a99;
            /* Blue */
            padding: 8px 30px;
            font-size: 13px;
            color: #fff;
            /* White text */
        }

        .header-top-bar i {
            color: #fdb813;
            /* Gold icons */
            margin-right: 5px;
        }

        .header-top-bar span {
            margin-right: 15px;
        }

        /* --- NEW: Main Header Layout --- */
        .header-main {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: #fff;
        }

        /* --- NEW: Logo with Text --- */
        .header-logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: #333;
        }

        .header-logo img {
            height: 70px;
            /* Taller logo */
            margin-right: 15px;
        }

        .logo-text h1 {
            margin: 0;
            font-size: 1.5em;
            /* 24px */
            color: #004a99;
            /* Blue */
            font-weight: 700;
        }

        .logo-text h2 {
            margin: 0;
            font-size: 1.1em;
            /* 18px */
            color: #555;
            font-weight: 400;
        }

        /* --- Navigation Bar --- */
        .nav {
            background-color: transparent;
        }

        .nav ul {
            margin: 0;
            padding: 0;
            list-style: none;
            display: flex;
            align-items: center;
            /* Vertically align links */
            flex-wrap: wrap;
        }

        .nav li {
            position: relative;
        }

        .nav a {
            display: block;
            padding: 15px 18px;
            color: #333;
            /* Dark text */
            text-decoration: none;
            font-weight: bold;
            font-size: 16px;
            transition: color 0.2s ease-in-out;
        }

        .nav a:hover {
            color: #004a99;
            /* Blue on hover */
        }

        .nav a.active {
            color: #004a99;
            /* Blue for active */
            box-shadow: 0 3px 0 0 #004a99;
            /* Blue underline */
        }

        /* --- NEW: Apply Now Button --- */
        .header-apply-btn {
            background-color: #fdb813;
            /* Gold */
            color: #000 !important;
            /* Black text */
            padding: 12px 25px;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin-left: 15px;
        }

        .header-apply-btn:hover {
            background-color: #ffc107;
            color: #000 !important;
        }

        .header-apply-btn.closed {
            background-color: #dc3545;
            /* Red */
            color: #fff !important;
        }

        .header-apply-btn.closed:hover {
            background-color: #c82333;
        }

        /* Responsive */
        @media (max-width: 992px) {

            /* Adjust breakpoint for new nav */
            .header-main {
                flex-direction: column;
                gap: 15px;
            }

            .nav ul {
                justify-content: center;
                width: 100%;
                border-top: 1px solid #f0f0f0;
                padding-top: 10px;
            }
        }

        @media (max-width: 768px) {
            .nav ul {
                flex-direction: column;
            }

            .nav a {
                text-align: center;
                border-bottom: 1px solid #f0f0f0;
                width: 100vw;
                /* Full width on mobile */
            }

            .nav a.active {
                box-shadow: none;
                /* Remove underline on mobile */
                background: #f4f4f4;
            }

            .header-apply-btn {
                width: 80%;
                margin: 10px auto;
            }
        }
    </style>
</head>

<body class="<?php echo ($pageTitle == 'Home') ? 'home' : ''; ?>">

    <header class="header">
        <div class="header-top-bar">
            <div class="header-contact">
                <span><i class="fa fa-phone"></i> +92-21-34815341</span>
                <span><i class="fa fa-envelope"></i> chiniotschool@yahoo.com</span>
            </div>
        </div>
        <div class="header-main">

            <a href="/chiniot/index.php" class="header-logo">
                <img src="/chiniot/logos.png" alt="Chiniot Islamia School Logo">
                <div class="logo-text">
                    <h1>Chiniot Islamia</h1>
                    <h2>Public School & College</h2>
                </div>
            </a>

            <nav class="nav">
                <ul>
                    <?php
                    $current_page_title = isset($pageTitle) ? $pageTitle : '';

                    $academics_pages = ['Academics', 'Laboratories'];
                    $admissions_pages = ['Admission Form', 'Admission Procedure', 'Fee Structure', 'Admission Policy', 'Admission FAQs', 'How to Pay', 'Uniform', 'Print Admit Card'];
                    $campus_pages = ['Campus Life', 'Library', 'Mosque', 'Sick Room', 'Gallery'];
                    ?>

                    <li><a href="/chiniot/index.php" class="<?php echo ($current_page_title == 'Home') ? 'active' : ''; ?>">Home</a></li>
                    <li><a href="/chiniot/about.php" class="<?php echo ($current_page_title == 'About Us') ? 'active' : ''; ?>">About Us</a></li>
                    <li><a href="/chiniot/academics.php" class="<?php echo (in_array($current_page_title, $academics_pages)) ? 'active' : ''; ?>">Academics</a></li>
                    <li><a href="/chiniot/campus-life.php" class="<?php echo (in_array($current_page_title, $campus_pages)) ? 'active' : ''; ?>">Campus Life</a></li>
                    <li><a href="/chiniot/result/index.php" class="<?php echo ($current_page_title == 'Student Results') ? 'active' : ''; ?>">Student Results</a></li>
                    <li><a href="/chiniot/contact.php" class="<?php echo ($current_page_title == 'Contact Us') ? 'active' : ''; ?>">Contact Us</a></li>

                    <li>
                        <?php if ($admissions_status == 'open'): ?>
                            <a href="/chiniot/admissions.php" class="header-apply-btn">Admissions Open</a>
                        <?php else: ?>
                            <a href="/chiniot/admissions.php" class="header-apply-btn closed">Admissions Closed</a>
                        <?php endif; ?>
                    </li>
                </ul>
            </nav>
        </div>
    </header>