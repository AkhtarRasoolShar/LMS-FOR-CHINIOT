<?php
include 'db.php';
session_start();

// Security check for any logged-in user (frontdesk or admin)
if (!isset($_SESSION['role'])) {
    echo json_encode([]);
    exit;
}

$class_id = (int)$_GET['class_id'];
$students = [];

// Get the class name from the ID
$class_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
$class_stmt->bind_param("i", $class_id);
$class_stmt->execute();
$class_result = $class_stmt->get_result();

if ($class_result->num_rows > 0) {
    $class_row = $class_result->fetch_assoc();
    $class_name = $class_row['class_name']; // e.g., "V-A"

    // Use LIKE to find students in "PM V-A", "CO V-A" etc.
    $like_class_name = '%' . $class_name . '%';

    $stmt = $conn->prepare("
        SELECT student_id, name 
        FROM students 
        WHERE class LIKE ? 
        ORDER BY name
    ");
    $stmt->bind_param("s", $like_class_name);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $students[] = [
            'student_id' => $row['student_id'],
            'name' => htmlspecialchars($row['name'])
        ];
    }
    $stmt->close();
}

$class_stmt->close();
$conn->close();

header('Content-Type: application/json');
echo json_encode($students);
