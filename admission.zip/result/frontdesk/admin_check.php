<?php
session_start();
require_once '../db.php'; // Connect to the database

// Check if the user is logged in, has the 'FrontDesk' role, AND has all required session data
if (
    !isset($_SESSION['role']) || $_SESSION['role'] !== 'FrontDesk' ||
    !isset($_SESSION['user_id']) || !isset($_SESSION['full_name'])
) {
    // If any check fails, destroy the session and redirect to the login page
    session_unset();
    session_destroy();
    header("Location: frontdesk_login.php");
    exit;
}

// If all checks passed, store user info in a variable (this is now safe)
$logged_in_user_id = $_SESSION['user_id'];
$logged_in_user_name = $_SESSION['full_name'];
