<?php
include 'admin_check.php'; // Includes security and sets $logged_in_user_id

$message = '';
$error = '';

// --- Get essential lists for the form ---
$subjects_list = [];
$full_classes_list = [];
$classes_data_result = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");
if ($classes_data_result) {
    while ($row = $classes_data_result->fetch_assoc()) {
        $full_classes_list[] = $row;
    }
}
$subjects_list_result = $conn->query("SELECT subject_name FROM subjects ORDER BY subject_name");
if ($subjects_list_result) {
    while ($row = $subjects_list_result->fetch_assoc()) {
        $subjects_list[] = $row['subject_name'];
    }
}
$class_subjects_result = $conn->query("
    SELECT cs.class_id, s.subject_id, s.subject_name 
    FROM class_subjects cs 
    JOIN subjects s ON cs.subject_id = s.subject_id 
    ORDER BY s.subject_name
");
$class_subject_map = [];
if ($class_subjects_result) {
    while ($row = $class_subjects_result->fetch_assoc()) {
        $class_subject_map[$row['class_id']][] = [
            'subject_id' => $row['subject_id'],
            'subject_name' => $row['subject_name']
        ];
    }
}

// --- Handle adding a new user (Form Submission Logic) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $main_subject = $_POST['main_subject'] ?? NULL;

    // Only process assignments if the role is 'teacher'
    $assignments = ($_POST['role'] == 'teacher') ? ($_POST['new_assignments'] ?? []) : [];

    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $conn->begin_transaction();

    try {
        // 1. Insert New User
        $stmt = $conn->prepare("INSERT INTO teachers (username, password_hash, role, full_name, email, main_subject) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $username, $password_hash, $role, $full_name, $email, $main_subject);
        $stmt->execute();
        $new_teacher_id = $conn->insert_id;
        $stmt->close();

        // 2. Insert Assignments (Only if role is 'teacher')
        if ($role == 'teacher' && !empty($assignments)) {
            $stmt_assign = $conn->prepare("INSERT INTO teacher_assignments (teacher_id, class_id, class_name, subject_id) VALUES (?, ?, ?, ?)");

            foreach ($assignments as $assignment_pair) {
                list($class_id, $subject_id) = explode('|', $assignment_pair);

                $class_name_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
                $class_name_stmt->bind_param("i", $class_id);
                $class_name_stmt->execute();
                $class_name = $class_name_stmt->get_result()->fetch_assoc()['class_name'] ?? '';
                $class_name_stmt->close();

                $stmt_assign->bind_param("iisi", $new_teacher_id, $class_id, $class_name, $subject_id);
                $stmt_assign->execute();
            }
            $stmt_assign->close();
        }

        $conn->commit();
        $message = "Success! User $full_name added. Redirecting to management list...";

        // Redirect to management list with success message
        header("Location: manage_teachers.php?status=" . urlencode($message));
        exit;
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        if ($e->getCode() == 1062) {
            $error = "Error: The username '{$username}' already exists. Please choose a different one.";
        } else {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add New User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 600px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group.assignments-area {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 4px;
            background: #fcfcfc;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6fb;
        }

        /* Assignment specific styles */
        .assigned-list {
            list-style: none;
            padding: 0;
            margin-top: 10px;
        }

        .assigned-list li {
            background: #eee;
            padding: 5px 10px;
            border-radius: 4px;
            margin-bottom: 3px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9em;
        }

        .assignment-selector {
            display: flex;
            gap: 10px;
            margin-bottom: 5px;
        }

        .assignment-selector select {
            flex: 1;
        }

        .assignment-selector button {
            width: 50px;
            padding: 5px 0;
            margin: 0;
            background: #006400;
            /* Green */
        }

        .assigned-list li button {
            background: #b30000;
            padding: 3px 8px;
            font-size: 12px;
        }

        .hidden-group {
            display: none;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Add New User</h1>
        <a href="manage_teachers.php">Back to Management</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>"><?php echo $message; ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="message error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form action="add_teacher.php" method="POST" id="add-teacher-form">
            <input type="hidden" name="add_user" value="1">

            <div class="form-group">
                <label for="full_name">Full Name</label>
                <input type="text" name="full_name" required>
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" required>
            </div>

            <div class="form-group">
                <label for="role">Role</label>
                <select name="role" id="role-select" required>
                    <option value="teacher">Teacher (Academics/Results)</option>
                    <option value="admin">Administrator (Super User)</option>
                    <option value="FrontDesk">FrontDesk (Admissions/Contact)</option>
                </select>
            </div>

            <div class="form-group hidden-group" id="main-subject-group">
                <label for="main_subject">Main Subject (Used for Teacher Roster)</label>
                <select name="main_subject">
                    <option value="">-- Select Main Subject --</option>
                    <?php foreach ($subjects_list as $subject): ?>
                        <option value="<?php echo htmlspecialchars($subject); ?>"><?php echo htmlspecialchars($subject); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group assignments-area hidden-group" id="multi-assignment-section">
                <label style="color: #b30000;">Multiple Class Assignments (Required for Teachers)</label>

                <div class="assignment-selector">
                    <select id="class-select-form">
                        <option value="">-- Select Class --</option>
                        <?php foreach ($full_classes_list as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>"><?php echo htmlspecialchars($class['class_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select id="subject-select-form" disabled>
                        <option value="">-- Select Subject --</option>
                    </select>
                    <button type="button" id="add-assignment-btn">Add</button>
                </div>

                <ul id="assigned-classes-list" class="assigned-list">
                </ul>
            </div>

            <button type="submit" id="submit-button" style="margin-top: 15px;">Add User</button>
        </form>
    </div>

    <script>
        // Data maps needed for JS
        const classSubjectMap = <?php echo json_encode($class_subject_map); ?>;

        const classSelectForm = document.getElementById('class-select-form');
        const subjectSelectForm = document.getElementById('subject-select-form');
        const assignedList = document.getElementById('assigned-classes-list');
        const assignmentSection = document.getElementById('multi-assignment-section');
        const roleSelect = document.getElementById('role-select');
        const mainSubjectGroup = document.getElementById('main-subject-group');
        const submitButton = document.getElementById('submit-button');

        // Initial call on page load
        document.addEventListener('DOMContentLoaded', () => {
            toggleAssignmentVisibility();
        });

        roleSelect.addEventListener('change', toggleAssignmentVisibility);

        function toggleAssignmentVisibility() {
            const role = roleSelect.value;
            const isTeacher = (role === 'teacher');

            // Toggle visibility of assignment and subject fields
            assignmentSection.classList.toggle('hidden-group', !isTeacher);
            mainSubjectGroup.classList.toggle('hidden-group', !isTeacher);

            // CRITICAL FIX: Add/Remove a validation class to control form submission for teachers
            // If the role is 'teacher', the assignment list MUST be populated or the form will fail validation.
            // If the role is NOT 'teacher', we allow submission immediately.

            if (!isTeacher) {
                // Remove dynamic required class on selects and clear list to prevent empty form submission errors for Admin/FrontDesk
                classSelectForm.removeAttribute('required');
                subjectSelectForm.removeAttribute('required');
                assignedList.innerHTML = '';
            } else {
                classSelectForm.setAttribute('required', '');
                subjectSelectForm.setAttribute('required', '');
            }
        }

        // Event listener to populate subjects when a class is selected
        classSelectForm.addEventListener('change', function() {
            const classId = this.value;
            subjectSelectForm.innerHTML = '<option value="">-- Select Subject --</option>';
            subjectSelectForm.disabled = true;

            if (classId && classSubjectMap[classId]) {
                const subjects = classSubjectMap[classId];
                subjects.forEach(subject => {
                    subjectSelectForm.innerHTML += `<option value="${subject.subject_id}">${subject.subject_name}</option>`;
                });
                subjectSelectForm.disabled = false;
            }
        });

        // Event listener for the ADD button
        document.getElementById('add-assignment-btn').addEventListener('click', addAssignment);


        function addAssignment() {
            const classId = classSelectForm.value;
            const subjectId = subjectSelectForm.value;

            if (!classId || !subjectId) {
                alert("Please select both a Class and a Subject.");
                return;
            }

            // Get selected text names
            const className = classSelectForm.options[classSelectForm.selectedIndex].text;
            const subjectName = subjectSelectForm.options[subjectSelectForm.selectedIndex].text;

            // Unique identifier for this assignment
            const assignmentValue = `${classId}|${subjectId}`;

            // Check for duplicates
            if (document.querySelector(`input[value="${assignmentValue}"]`)) {
                alert(`Assignment ${className} / ${subjectName} is already added.`);
                return;
            }

            // Create list item and hidden input
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <span>${className} / ${subjectName}</span>
                <input type="hidden" name="new_assignments[]" value="${assignmentValue}">
                <button type="button" onclick="this.parentNode.remove()">Remove</button>
            `;

            assignedList.appendChild(listItem);
        }
    </script>

</body>

</html>