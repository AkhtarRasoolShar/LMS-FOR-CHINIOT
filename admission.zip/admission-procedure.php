<?php
$pageTitle = "Admission Procedure";
include 'header.php';
?>
<style>
    .admission-header {
        text-align: center;
        margin: 20px auto;
        padding: 0 20px;
        max-width: 900px;
    }

    .admission-header h2 {
        font-size: 18px;
        color: #555;
        margin: 0;
        font-weight: normal;
    }

    .admission-header h1 {
        font-size: 36px;
        color: #006400;
        margin: 5px 0 15px 0;
    }

    .admission-nav {
        background: #f8f9fa;
        border-bottom: 1px solid #ddd;
        border-top: 1px solid #ddd;
        text-align: center;
        margin-bottom: 30px;
    }

    .admission-nav ul {
        margin: 0;
        padding: 0;
        list-style: none;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
    }

    .admission-nav li {
        display: inline-block;
    }

    .admission-nav a {
        display: block;
        padding: 15px 20px;
        text-decoration: none;
        color: #006400;
        font-weight: bold;
        font-size: 16px;
        border-bottom: 3px solid transparent;
    }

    .admission-nav a:hover {
        background: #e9ecef;
    }

    .admission-nav a.active {
        border-bottom-color: #006400;
        color: #333;
        background: #e9ecef;
    }

    .content-page {
        max-width: 900px;
        margin: 0 auto 30px auto;
        padding: 30px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        font-size: 16px;
        line-height: 1.7;
        color: #333;
    }

    .content-page h2 {
        color: #006400;
        border-bottom: 2px solid #f0f0f0;
        padding-bottom: 10px;
        margin-top: 0;
    }

    .content-page ol {
        padding-left: 20px;
        margin-top: 20px;
    }

    .content-page ol li {
        margin-bottom: 15px;
    }

    .age-table {
        margin-top: 25px;
        border-collapse: collapse;
        width: 100%;
        max-width: 350px;
    }

    .age-table td {
        border: 1px solid #ddd;
        padding: 8px 12px;
    }

    .age-table td:first-child {
        font-weight: bold;
        background: #f9f9f9;
        width: 70%;
    }

    .age-table td:last-child {
        text-align: center;
    }

    @media (max-width: 768px) {
        .admission-nav ul {
            flex-direction: column;
        }

        .admission-nav a {
            border-bottom: 1px solid #ddd;
        }

        .admission-nav a.active {
            border-bottom-color: #006400;
        }
    }
</style>

<div class="admission-header">
    <h2>Chiniot Islamia Public School & College</h2>
    <h1>Admissions</h1>
</div>

<nav class="admission-nav">
    <ul>
        <li><a href="admission-procedure.php" class="active">Admission Procedure</a></li>
        <li><a href="admissions.php">Admission Form</a></li>
        <li><a href="fee-structure.php">Fee Structure</a></li>
        <li><a href="admission-policy.php">Admission Policy</a></li>
        <li><a href="admission-faqs.php">FAQs</a></li>
        <li><a href="how-to-pay.php">How to Pay Fee Bill</a></li>
        <li><a href="uniform.php">Uniform</a></li>
    </ul>
</nav>

<div class="content-page">
    <h2>Admission Procedure</h2>
    <p>Following is the procedure for admission:</p>
    <ol type="a">
        <li>Admission in School is granted to boys in classes Montessori to class VIII in the morning shift. Girls are given admission in class VI to VIII in the morning shift on merit i.e. performance in entrance test.</li>
        <li>Admission to class XI (Pre-Engineering, Pre-Medical, Computer Science) are granted to boys & girls on the basis of their Board result & admission test. Boys and girls both are eligible for Pre-Engineering, Pre-Medical and Computer Science.</li>
        <li>Applications for admission can be submitted online by filling relevant form available on the website.</li>
        <li>Coloured photographs should be uploaded with the admission form.</li>
        <li>Admission test is based on the level of the preceding class in subjects of English, Maths, Urdu from KG II to VIII for Matric stream and only English and Maths for O’ level stream students from VI to VIII.</li>
        <li>Admissions are also given in the Primary classes (KG-I to class V) in the afternoon shift .</li>
        <li>Pass marks for admission tests are 40% in each subject.</li>
        <li>The rights of admission are reserved.</li>
    </ol>
    <p>The table below gives the age against the class for the purpose of admission:</p>
    <table class="age-table">
        <tr>
            <td>Montessori Junior</td>
            <td>3+</td>
        </tr>
        <tr>
            <td>Montessori Senior</td>
            <td>4+</td>
        </tr>
        <tr>
            <td>Montessori Advance</td>
            <td>5+</td>
        </tr>
        <tr>
            <td>I</td>
            <td>6+</td>
        </tr>
        <tr>
            <td>II</td>
            <td>7+</td>
        </tr>
        <tr>
            <td>III</td>
            <td>8+</td>
        </tr>
        <tr>
            <td>IV</td>
            <td>9+</td>
        </tr>
        <tr>
            <td>V</td>
            <td>10+</td>
        </tr>
        <tr>
            <td>VI</td>
            <td>11+</td>
        </tr>
        <tr>
            <td>VII</td>
            <td>12+</td>
        </tr>
        <tr>
            <td>VIII</td>
            <td>13+</td>
        </tr>
    </table>
</div>
<?php include 'footer.php'; ?>