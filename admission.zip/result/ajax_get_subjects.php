<?php
include 'db.php'; // --- PATH FIXED ---
session_start();

// Check if teacher is logged in
if (!isset($_SESSION['teacher_id'])) {
    echo json_encode([]);
    exit;
}

$logged_in_teacher_id = (int)$_SESSION['teacher_id'];
$class_id = (int)$_GET['class_id'];
$subjects = [];

// Get the subjects THIS teacher is assigned to for THIS class
$stmt = $conn->prepare("
    SELECT s.subject_id, s.subject_name
    FROM teacher_assignments ta
    JOIN subjects s ON ta.subject_id = s.subject_id
    WHERE ta.teacher_id = ? AND ta.class_id = ?
    ORDER BY s.subject_name
");
$stmt->bind_param("ii", $logged_in_teacher_id, $class_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $subjects[] = [
        'subject_id' => $row['subject_id'],
        'subject_name' => htmlspecialchars($row['subject_name'])
    ];
}

$stmt->close();
$conn->close();

header('Content-Type: application/json');
echo json_encode($subjects);
