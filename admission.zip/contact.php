<?php
$pageTitle = "Contact Us";
include 'header.php';
?>

<style>
    /* This uses the .container-padded class from header.php */
    .container {
        max-width: 1000px;
        margin: 30px auto;
        padding: 30px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .container h2 {
        color: #004a99;
        /* Professional Blue */
        border-bottom: 2px solid #f0f0f0;
        padding-bottom: 10px;
        margin-top: 0;
        font-size: 2.2em;
    }

    .contact-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 40px;
    }

    .contact-form .form-group {
        margin-bottom: 20px;
    }

    .contact-form label {
        display: block;
        font-weight: bold;
        margin-bottom: 8px;
    }

    .contact-form input,
    .contact-form textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        /* Ensures padding doesn't break layout */
    }

    .contact-form textarea {
        height: 150px;
        font-family: Arial, sans-serif;
    }

    .contact-form button {
        display: block;
        width: 100%;
        padding: 12px;
        background: #004a99;
        /* Blue */
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 18px;
        font-weight: bold;
    }

    .contact-form button:hover {
        background: #003b7a;
        /* Darker Blue */
    }

    .contact-info p {
        font-size: 16px;
        line-height: 1.7;
    }

    .contact-info strong {
        color: #004a99;
        /* Blue */
        font-size: 1.1em;
        display: block;
        margin-bottom: 5px;
    }

    .contact-info .map-container {
        width: 100%;
        height: 250px;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid #ddd;
        margin-top: 20px;
    }

    .social-links {
        margin-top: 20px;
    }

    .social-links a {
        display: inline-block;
        margin-right: 15px;
        font-size: 2em;
        color: #004a99;
    }

    .social-links a:hover {
        color: #003b7a;
    }

    /* Responsive layout */
    @media (max-width: 768px) {
        .contact-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="container">
    <h2>Contact Us</h2>

    <div class="contact-grid">
        <div class="contact-info">
            <h3>Get in Touch</h3>
            <p>We welcome your questions, feedback, and inquiries. Please feel free to get in touch with us using the form, or by contacting us directly at our campus.</p>

            <p>
                <strong>Address:</strong>
                Block 7, University Road, Gulshan-e-Iqbal, Karachi
            </p>
            <p>
                <strong>For Information Regarding Admissions:</strong>
                Phone: +92-21-34815341<br>
                Phone: +92-21-34962836
            </p>
            <p>
                <strong>Email:</strong>
                chiniotschool@yahoo.com
            </p>
            <p>
                <strong>For Career Opportunities:</strong>
                Email: jobs@chiniotschool.edu.pk
            </p>

            <div class="social-links">
                <strong>Visit our Social Media:</strong><br>
                <a href="#" target="_blank" title="Facebook"><i class="fab fa-facebook-square"></i></a>
                <a href="#" target="_blank" title="YouTube"><i class="fab fa-youtube-square"></i></a>
            </div>

            <div class="map-container">
                <iframe
                    src="https://www.google.com/maps/place/Chiniot+Islamia+Public+School/@24.9200959,67.0973769,15.01z/data=!4m23!1m16!4m15!1m6!1m2!1s0x3eb338c7b16a3175:0xd150ffeb6c5ef0!2zQ2hpbmlvdCBJc2xhbWlhIFB1YmxpYyBTY2hvb2wg2obZhtmI2bkg2KfYs9mE2KfZhduM24Eg2b7YqNmE2qkg2LPaqdmI2YQ!2m2!1d67.1081031!2d24.9270582!1m6!1m2!1s0x3eb338c7b16a3175:0xd150ffeb6c5ef0!2sChiniot+Islamia+Public+School,+W4G5%2BR6H,+Main+University+Rd,+Block+7+Gulshan-e-Iqbal,+Karachi,+Pakistan!2m2!1d67.1081031!2d24.9270582!3e0!3m5!1s0x3eb338c7b16a3175:0xd150ffeb6c5ef0!8m2!3d24.9270582!4d67.1081031!16s%2Fm%2F0cp4kgc?hl=en&entry=ttu&g_ep=EgoyMDI1MTExMi4wIKXMDSoASAFQAw%3D%3D"
                    width="100%"
                    height="100%"
                    style="border:0;"
                    allowfullscreen=""
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
        </div>

        <div class="contact-form">
            <h3>Send us a Message</h3>

            <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
                <p style="color: green; font-weight: bold; background: #e6f7e6; padding: 10px; border-radius: 5px;">
                    Message sent successfully! We will get back to you soon.
                </p>
            <?php elseif (isset($_GET['status']) && $_GET['status'] == 'error'): ?>
                <p style="color: red; font-weight: bold; background: #fde8e8; padding: 10px; border-radius: 5px;">
                    Error: Could not send message. Please try again.
                </p>
            <?php endif; ?>

            <form action="send-contact.php" method="POST">
                <div class="form-group">
                    <label for="name">Your Name: <span>*</span></label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Your Email: <span>*</span></label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="phone">Your Phone Number: <span>*</span></label>
                    <input type="tel" id="phone" name="subject" required>
                </div>
                <div class="form-group">
                    <label for="message">Your Message: <span>*</span></label>
                    <textarea id="message" name="message" required></textarea>
                </div>
                <button type="submit">Send Message</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>