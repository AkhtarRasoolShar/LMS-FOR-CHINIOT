<?php
$pageTitle = "About Us";
include 'header.php';
?>

<style>
    /* --- Page Specific Hero --- */
    .page-hero {
        /* Using the image you provided */
        background-image: linear-gradient(rgba(0, 74, 153, 0.7), rgba(0, 74, 153, 0.7)), url('/chiniot/img/image_f15602.jpg');
        background-size: cover;
        background-position: center;
        text-align: center;
        padding: 80px 20px;
        color: white;
    }

    .page-hero h1 {
        font-size: 3em;
        margin: 0;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
    }

    /* --- Re-using styles from index.php --- */
    .content-section {
        background: #fff;
        padding: 50px 30px;
        max-width: 1000px;
        margin: 30px auto;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .content-section.light-bg {
        background: #f9f9f9;
    }

    .content-section.dark-bg {
        background: #004a99;
        /* Blue */
        color: white;
    }

    .content-section h2 {
        text-align: center;
        font-size: 2.5em;
        margin-top: 0;
        margin-bottom: 40px;
        color: #004a99;
        /* Blue */
    }

    .content-section.dark-bg h2 {
        color: white;
    }

    /* --- Welcome Section --- */
    .welcome-content {
        display: flex;
        align-items: center;
        gap: 30px;
    }

    .welcome-content img {
        width: 100%;
        max-width: 450px;
        /* Control image size */
        border-radius: 8px;
    }

    .welcome-text {
        flex: 1;
        font-size: 1.1em;
        line-height: 1.7;
    }

    .welcome-text h2 {
        text-align: left;
    }

    /* --- Why Choose Us Section --- */
    .why-us-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 30px;
    }

    .why-card {
        background: #fff;
        padding: 30px;
        text-align: center;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        border-top: 4px solid #fdb813;
        /* Gold Accent */
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .why-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    .why-card i {
        font-size: 3em;
        color: #004a99;
        /* Blue icon */
        margin-bottom: 20px;
    }

    .why-card h3 {
        font-size: 1.5em;
        margin: 0 0 15px 0;
        color: #333;
    }

    /* --- Stats Bar --- */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
        text-align: center;
    }

    .stat-item {
        border-right: 1px solid #003b7a;
        /* Darker Blue */
    }

    .stat-item:last-child {
        border-right: none;
    }

    .stat-item span {
        font-size: 2.5em;
        font-weight: bold;
        display: block;
        color: #fdb813;
        /* Gold */
    }

    .stat-item p {
        font-size: 1.2em;
        margin: 5px 0 0 0;
    }

    /* --- Principal Section --- */
    .principal-section img {
        width: 220px;
        height: 220px;
        border-radius: 50%;
        border: 5px solid #004a99;
        justify-self: center;
    }

    /* --- Animation Class --- */
    .fade-in {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease-out, transform 0.6s ease-out;
    }

    .fade-in.visible {
        opacity: 1;
        transform: translateY(0);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .welcome-content {
            flex-direction: column;
            text-align: center;
        }

        .welcome-text h2 {
            text-align: center;
        }

        .why-us-grid,
        .stats-grid {
            grid-template-columns: 1fr;
        }

        .stat-item {
            border-right: none;
            border-bottom: 1px solid #003b7a;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }

        .stat-item:last-child {
            border-bottom: none;
            padding-bottom: 0;
            margin-bottom: 0;
        }
    }
</style>

<section class="page-hero">
    <h1>About Chiniot Islamia School</h1>
</section>

<section class="content-section">
    <div class="container">
        <div class="welcome-content fade-in">
            <img src="/chiniot/img/cropped-cropped-school-building1-768x512.jpg" alt="School Building">
            <div class="welcome-text">
                <h2>Welcome to Chiniot Islamia</h2>
                <p>
                    Chiniot Islamia Public School & College is a prestigious educational institution committed to providing quality education in a nurturing and disciplined environment. Established with the vision to foster academic excellence and strong moral values, our school has grown to become a cornerstone of the community.
                </p>
                <p>
                    Our curriculum is designed to be challenging and engaging, preparing students for success in national and international examinations. We offer a wide range of subjects and are supported by state-of-the-art facilities.
                </p>
            </div>
        </div>
    </div>
</section>

<section class="content-section light-bg">
    <div class="container">
        <h2 class="fade-in">Why Choose Us?</h2>
        <div class="why-us-grid">
            <div class="why-card fade-in">
                <i class="fa-solid fa-chalkboard-user"></i>
                <h3>Qualified Faculty</h3>
                <p>Our teachers are experienced, dedicated, and committed to student success.</p>
            </div>
            <div class="why-card fade-in">
                <i class="fa-solid fa-flask"></i>
                <h3>Modern Labs</h3>
                <p>State-of-the-art facilities for Physics, Chemistry, Biology, and Computer Science.</p>
            </div>
            <div class="why-card fade-in">
                <i class="fa-solid fa-hands-praying"></i>
                <h3>Moral Values</h3>
                <p>We emphasize strong ethical and Islamic values alongside academic learning.</p>
            </div>
        </div>
    </div>
</section>

<section class="content-section dark-bg fade-in">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-item">
                <span>13,396+</span>
                <p>Books in Library</p>
            </div>
            <div class="stat-item">
                <span>150+</span>
                <p>Qualified Staff</p>
            </div>
            <div class="stat-item">
                <span>30+</span>
                <p>Years of Excellence</p>
            </div>
        </div>
    </div>
</section>

<section class="content-section">
    <div class="container">
        <div class="welcome-content principal-section fade-in">
            <img src="/chiniot/principle.jpg" alt="Principal's Message">
            <div class="welcome-text">
                <h2>Message from the Principal</h2>
                <p>Welcome to our school. We believe in a balanced approach to education, one that develops our students intellectually, morally, and physically. Our dedicated faculty and staff work tirelessly to support each student's journey, ensuring they achieve their full potential in a safe and supportive atmosphere.</p>
            </div>
        </div>
    </div>
</section>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.1
            });

            const elementsToFade = document.querySelectorAll('.fade-in');
            elementsToFade.forEach(el => {
                observer.observe(el);
            });
        }
    });
</script>

<?php include 'footer.php'; ?>