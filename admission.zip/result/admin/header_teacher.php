<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../db.php';

if (!isset($_SESSION['teacher_id'])) {
    header("Location: index.php");
    exit;
}

$teacher_id = $_SESSION['teacher_id'];
$teacher_name = $_SESSION['teacher_name'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle : 'Teacher Portal'; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f7f6;
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100%;
            transition: 0.3s;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 20px;
            text-align: center;
            background: #1a252f;
            border-bottom: 1px solid #34495e;
        }

        .sidebar-header img {
            width: 70px;
            background: white;
            border-radius: 50%;
            padding: 5px;
            margin-bottom: 10px;
        }

        .sidebar-header h3 {
            margin: 0;
            font-size: 14px;
            color: #ffc107;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .menu {
            list-style: none;
            padding: 20px 0;
            margin: 0;
        }

        .menu li {
            margin-bottom: 2px;
        }

        .menu a {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: #bdc3c7;
            text-decoration: none;
            border-left: 4px solid transparent;
            transition: 0.2s;
            font-size: 14px;
        }

        .menu a:hover,
        .menu a.active {
            background: #34495e;
            color: white;
            border-left-color: #ffc107;
            padding-left: 25px;
        }

        .menu i {
            margin-right: 15px;
            width: 20px;
            text-align: center;
            font-size: 16px;
        }

        .main-content {
            margin-left: 250px;
            width: calc(100% - 250px);
            display: flex;
            flex-direction: column;
        }

        .top-bar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            margin: 0;
            font-size: 20px;
            color: #333;
            font-weight: 600;
        }

        .user-info {
            font-size: 14px;
            color: #666;
        }

        .user-info strong {
            color: #004a99;
        }

        .content-wrapper {
            padding: 30px;
        }

        .card {
            background: white;
            border-radius: 6px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            padding: 25px;
            margin-bottom: 25px;
            border-top: 3px solid #004a99;
        }

        .btn-primary {
            background: #004a99;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            display: inline-block;
            transition: 0.3s;
        }

        .btn-warning {
            background: #ffc107;
            color: #333;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            display: inline-block;
            font-weight: bold;
            transition: 0.3s;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 14px;
        }

        /* Search Input Style */
        .search-box {
            position: relative;
            max-width: 300px;
            width: 100%;
        }

        .search-input {
            width: 100%;
            padding: 10px 10px 10px 35px;
            border: 1px solid #ddd;
            border-radius: 20px;
            outline: none;
            transition: 0.3s;
        }

        .search-input:focus {
            border-color: #004a99;
            box-shadow: 0 0 5px rgba(0, 74, 153, 0.2);
        }

        .search-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 0;
                overflow: hidden;
            }

            .main-content {
                margin-left: 0;
                width: 100%;
            }

            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
        }

        @media print {

            .sidebar,
            .top-bar,
            .search-box,
            .btn-primary,
            .btn-warning {
                display: none !important;
            }

            .main-content {
                margin: 0;
                width: 100%;
            }

            .card {
                box-shadow: none;
                border: 1px solid #ccc;
            }
        }
    </style>

    <script>
        // GLOBAL SEARCH FUNCTION
        function filterTable() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("searchInput");
            filter = input.value.toUpperCase();
            // Select the first table on the page
            table = document.querySelector("table");
            if (!table) return;

            tr = table.getElementsByTagName("tr");
            for (i = 1; i < tr.length; i++) { // Start from 1 to skip header
                var match = false;
                // Search in all columns
                var tds = tr[i].getElementsByTagName("td");
                for (var j = 0; j < tds.length; j++) {
                    if (tds[j]) {
                        txtValue = tds[j].textContent || tds[j].innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            match = true;
                            break;
                        }
                    }
                }
                if (match) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    </script>
</head>

<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <img src="../../logos.png" alt="Logo">
            <h3>Teacher Panel</h3>
        </div>
        <ul class="menu">
            <li><a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a></li>
            <li><a href="view_students.php" class="<?= basename($_SERVER['PHP_SELF']) == 'view_students.php' ? 'active' : '' ?>"><i class="fas fa-users"></i> <span>My Students</span></a></li>
            <li><a href="enter_marks.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'enter_marks.php' || basename($_SERVER['PHP_SELF']) == 'enter_marks_list.php') ? 'active' : '' ?>"><i class="fas fa-edit"></i> <span>Enter Marks</span></a></li>
            <li><a href="mark_attendance.php" class="<?= basename($_SERVER['PHP_SELF']) == 'mark_attendance.php' ? 'active' : '' ?>"><i class="fas fa-user-check"></i> <span>Attendance</span></a></li>
            <li><a href="generate_reports.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'generate_reports.php' || basename($_SERVER['PHP_SELF']) == 'print_bulk_cards.php') ? 'active' : '' ?>"><i class="fas fa-print"></i> <span>Report Cards</span></a></li>
            <li><a href="profile.php" class="<?= basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : '' ?>"><i class="fas fa-user-cog"></i> <span>Profile</span></a></li>
            <li style="margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;"><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="top-bar">
            <h2 class="page-title"><?php echo isset($pageTitle) ? $pageTitle : 'Dashboard'; ?></h2>
            <div class="user-info">Logged in as: <strong><?php echo htmlspecialchars($teacher_name); ?></strong></div>
        </div>
        <div class="content-wrapper">