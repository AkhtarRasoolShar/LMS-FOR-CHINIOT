<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../db.php';

// 1. SECURITY: Redirect if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit;
}

$student_id = $_SESSION['student_id'];

// 2. Fetch Student Data
$stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$std_res = $stmt->get_result();

if ($std_res->num_rows === 0) {
    session_destroy();
    header("Location: index.php");
    exit;
}
$current_student = $std_res->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle : 'Student Portal'; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Global Styles */
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f7f6;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background-color: #004a99;
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100%;
            overflow-y: auto;
            transition: 0.3s;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header img {
            width: 70px;
            background: white;
            border-radius: 50%;
            padding: 5px;
            margin-bottom: 10px;
        }

        .sidebar-header h3 {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .menu {
            list-style: none;
            padding: 20px 0;
            margin: 0;
        }

        .menu li {
            margin-bottom: 5px;
        }

        .menu a {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: 0.3s;
            border-left: 4px solid transparent;
            font-size: 15px;
        }

        .menu a:hover,
        .menu a.active {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border-left-color: #00ccff;
            padding-left: 30px;
        }

        .menu i {
            margin-right: 15px;
            width: 20px;
            text-align: center;
            font-size: 18px;
        }

        /* Main Content */
        .main-content {
            margin-left: 260px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            width: calc(100% - 260px);
        }

        /* Top Bar */
        .top-bar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-title {
            font-size: 22px;
            font-weight: bold;
            color: #333;
            margin: 0;
        }

        .user-info {
            font-size: 14px;
            color: #666;
            text-align: right;
        }

        .user-info strong {
            color: #004a99;
            display: block;
            font-size: 16px;
        }

        /* Content */
        .content-wrapper {
            padding: 0 30px 30px 30px;
        }

        /* Components */
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
            padding: 25px;
            margin-bottom: 25px;
            border-top: 3px solid #004a99;
        }

        .btn-primary {
            background: #004a99;
            color: white;
            padding: 8px 15px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            border: none;
            cursor: pointer;
        }

        .btn-primary:hover {
            background: #003366;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 0;
                overflow: hidden;
            }

            .main-content {
                margin-left: 0;
                width: 100%;
            }
        }

        @media print {

            .sidebar,
            .top-bar,
            .btn-primary {
                display: none !important;
            }

            .main-content {
                margin: 0;
                width: 100%;
            }

            .content-wrapper {
                padding: 0;
            }

            .card {
                box-shadow: none;
                border: 1px solid #ccc;
            }
        }
    </style>
</head>

<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <img src="../../logos.png" alt="Logo">
            <h3>Student Portal</h3>
        </div>
        <ul class="menu">
            <li><a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>"><i class="fas fa-th-large"></i> <span>Dashboard</span></a></li>
            <li><a href="results.php" class="<?= basename($_SERVER['PHP_SELF']) == 'results.php' ? 'active' : '' ?>"><i class="fas fa-poll"></i> <span>Exam Results</span></a></li>
            <li><a href="admit_card.php" class="<?= basename($_SERVER['PHP_SELF']) == 'admit_card.php' ? 'active' : '' ?>"><i class="fas fa-id-card"></i> <span>Admit Card</span></a></li>
            <li><a href="attendance.php" class="<?= basename($_SERVER['PHP_SELF']) == 'attendance.php' ? 'active' : '' ?>"><i class="fas fa-calendar-alt"></i> <span>Attendance</span></a></li>
            <li><a href="notices.php" class="<?= basename($_SERVER['PHP_SELF']) == 'notices.php' ? 'active' : '' ?>"><i class="fas fa-bell"></i> <span>Notices</span></a></li>
            <li><a href="profile.php" class="<?= basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : '' ?>"><i class="fas fa-user-circle"></i> <span>My Profile</span></a></li>
            <li style="margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 10px;">
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
            </li>
        </ul>
    </div>

    <div class="main-content">
        <div class="top-bar">
            <h2 class="page-title"><?php echo isset($pageTitle) ? $pageTitle : 'Dashboard'; ?></h2>
            <div class="user-info">
                <strong><?php echo htmlspecialchars($current_student['name']); ?></strong>
                <span>Class: <?php echo htmlspecialchars($current_student['class']); ?></span>
            </div>
        </div>
        <div class="content-wrapper">