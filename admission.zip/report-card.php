<?php
// Start the session
session_start();

// --- SECURITY CHECK ---
// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: portal.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Report Card - Chiniot Islamia Public School & College</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

    <header>
        <div class="container">
            <a href="index.php" class="logo">Chiniot School</a>
            <nav class="main-nav">
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="messages.php">Messages</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="page-header">
        <div class="container">
            <h1>E-Report Card</h1>
        </div>
    </section>

    <section class="page-content">
        <div class="container">

            <div class="report-card-container">
                <div class="report-header">
                    <h2>Chiniot Islamia Public School & College</h2>
                    <p>Mid-Term Report Card (2025)</p>
                    <div class="student-info">
                        <strong>Student Name:</strong> Ahmad <?php echo htmlspecialchars(explode(' ', $_SESSION["full_name"])[0]); ?><br>
                        <strong>Class:</strong> V-B<br>
                        <strong>Parent Name:</strong> <?php echo htmlspecialchars($_SESSION["full_name"]); ?><br>
                    </div>
                </div>

                <table class="report-table">
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Total Marks</th>
                            <th>Marks Obtained</th>
                            <th>Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>English</td>
                            <td>100</td>
                            <td>85</td>
                            <td>A</td>
                        </tr>
                        <tr>
                            <td>Mathematics</td>
                            <td>100</td>
                            <td>92</td>
                            <td>A+</td>
                        </tr>
                        <tr>
                            <td>Science</td>
                            <td>100</td>
                            <td>88</td>
                            <td>A</td>
                        </tr>
                        <tr>
                            <td>Urdu</td>
                            <td>100</td>
                            <td>79</td>
                            <td>B</td>
                        </tr>
                        <tr>
                            <td>Islamiat</td>
                            <td>100</td>
                            <td>95</td>
                            <td>A+</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Total</th>
                            <th>500</th>
                            <th>439</th>
                            <th>A</th>
                        </tr>
                    </tfoot>
                </table>

                <div class="report-footer">
                    <p><strong>Principal's Remarks:</strong> Excellent progress. Keep up the hard work.</p>
                    <button class="cta-button" onclick="window.print()">
                        <i class="fa-solid fa-print"></i> Print Report
                    </button>
                </div>
            </div>

        </div>
    </section>

    <footer>
        <div class="footer-bottom">
            <p>&copy; <?php echo date("Y"); ?> Chiniot Islamia Public School & College. All Rights Reserved.</p>
        </div>
    </footer>

</body>

</html>