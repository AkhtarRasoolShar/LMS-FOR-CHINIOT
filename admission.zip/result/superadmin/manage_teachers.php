<?php
include 'admin_check.php'; // Includes security and sets $logged_in_user_id

// --- FIX 1: Use the standardized session variable for current user ---
$current_user_id = $_SESSION['user_id'];

$message = '';
$error = '';
$filter_role = $_GET['role_filter'] ?? '';
$search_term = $_GET['search'] ?? '';

// --- Handle Deleting a user ---
if (isset($_GET['delete'])) {
    $teacher_id_to_delete = (int)$_GET['delete'];

    // Compare against standardized $current_user_id
    if ($teacher_id_to_delete == $current_user_id) {
        $message = "Error: You cannot delete your own account.";
    } else {
        $stmt = $conn->prepare("DELETE FROM teachers WHERE teacher_id = ?");
        $stmt->bind_param("i", $teacher_id_to_delete);
        if ($stmt->execute()) {
            $message = "User has been deleted.";
        } else {
            $message = "Error: Could not delete user. They may be linked to other data.";
        }
        $stmt->close();
    }
}

// --- Handle adding a new user (UPDATED logic to handle multi-assignment) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_teacher'])) {
    $username = $_POST['username'];
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $main_subject = $_POST['main_subject'];

    // Only process assignments if the role is 'teacher'
    $assignments = ($_POST['role'] == 'teacher') ? ($_POST['new_assignments'] ?? []) : [];

    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $conn->begin_transaction();

    try {
        // 1. Insert New User
        $stmt = $conn->prepare("INSERT INTO teachers (username, password_hash, role, full_name, email, main_subject) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $username, $password_hash, $role, $full_name, $email, $main_subject);
        $stmt->execute();
        $new_teacher_id = $conn->insert_id;
        $stmt->close();

        // 2. Insert Assignments (Only if role is 'teacher')
        if ($role == 'teacher') {
            if (!empty($assignments)) {

                foreach ($assignments as $assignment_pair) {
                    list($class_id, $subject_id) = explode('|', $assignment_pair);

                    // Fetch class name needed for the teacher_assignments table structure
                    $class_name_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
                    $class_name_stmt->bind_param("i", $class_id);
                    $class_name_stmt->execute();
                    $class_name = $class_name_stmt->get_result()->fetch_assoc()['class_name'] ?? '';
                    $class_name_stmt->close();

                    // Insert assignment
                    $stmt_assign = $conn->prepare("INSERT INTO teacher_assignments (teacher_id, class_id, class_name, subject_id) VALUES (?, ?, ?, ?)");
                    $stmt_assign->bind_param("iisi", $new_teacher_id, $class_id, $class_name, $subject_id);
                    $stmt_assign->execute();
                }
            }
        }

        $conn->commit();
        $message = "Success! User $full_name added with assignments.";

        // Redirect to self with a success message
        header("Location: manage_teachers.php?status=" . urlencode($message));
        exit;
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        // Handle Duplicate Entry Error (Error code 1062)
        if ($e->getCode() == 1062) {
            $error = "Error: The username '{$username}' already exists. Please choose a different one.";
        } else {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}

// Check for status message from redirect
if (isset($_GET['status'])) {
    $message = htmlspecialchars($_GET['status']);
}

// --- Get data for the forms ---
// Fetch all teachers, excluding the current admin
$users_result = $conn->query("SELECT teacher_id, username, full_name, email, role, main_subject FROM teachers WHERE teacher_id != $current_user_id ORDER BY role, username");

// --- Get all teacher assignments and subjects list (Existing logic) ---
$assignments_map = [];
$subjects_list = [];

$assignments_result = $conn->query("SELECT ta.teacher_id, c.class_name, s.subject_name FROM teacher_assignments ta JOIN classes c ON ta.class_id = c.class_id JOIN subjects s ON ta.subject_id = s.subject_id ORDER BY ta.teacher_id, c.class_name, s.subject_name");
if ($assignments_result) {
    while ($row = $assignments_result->fetch_assoc()) {
        $teacher_id = $row['teacher_id'];
        $class_name = $row['class_name'];
        $subject_name = $row['subject_name'];
        if (!isset($assignments_map[$teacher_id][$class_name])) {
            $assignments_map[$teacher_id][$class_name] = [];
        }
        $assignments_map[$teacher_id][$class_name][] = $subject_name;
    }
}

$subjects_list_result = $conn->query("SELECT subject_name FROM subjects ORDER BY subject_name");
if ($subjects_list_result) {
    while ($row = $subjects_list_result->fetch_assoc()) {
        $subjects_list[] = $row['subject_name'];
    }
}

// Get full class list and class-subject mapping for JS assignment loading
$full_classes_list = [];
$class_subject_map = [];
$classes_data_result = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");
if ($classes_data_result) {
    while ($row = $classes_data_result->fetch_assoc()) {
        $full_classes_list[] = $row;
    }
}
$class_subjects_result = $conn->query("
    SELECT cs.class_id, s.subject_id, s.subject_name 
    FROM class_subjects cs 
    JOIN subjects s ON cs.subject_id = s.subject_id 
    ORDER BY s.subject_name
");
if ($class_subjects_result) {
    while ($row = $class_subjects_result->fetch_assoc()) {
        $class_subject_map[$row['class_id']][] = [
            'subject_id' => $row['subject_id'],
            'subject_name' => $row['subject_name']
        ];
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Teachers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
        }

        .form-table-layout {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 30px;
        }

        .form-container,
        .table-container {
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        /* Multi-select styling */
        .assignment-selector {
            display: flex;
            gap: 10px;
            margin-bottom: 5px;
        }

        .assignment-selector select {
            flex: 1;
        }

        .assignment-selector button {
            width: 50px;
            padding: 5px 0;
            margin: 0;
            font-size: 14px;
            background: #006400;
            /* Green */
        }

        .assigned-list {
            list-style: none;
            padding: 0;
            margin-top: 10px;
        }

        .assigned-list li {
            background: #eee;
            padding: 5px 10px;
            border-radius: 4px;
            margin-bottom: 3px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9em;
        }

        .assigned-list li button {
            background: #b30000;
            /* Red */
            padding: 3px 8px;
            font-size: 12px;
        }


        button {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6fb;
        }

        .list-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .list-table th,
        .list-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            vertical-align: top;
        }

        .list-table th {
            background: #f2f2f2;
        }

        .actions-link {
            color: #006400;
            text-decoration: none;
        }

        .actions-link-danger {
            color: #b30000;
            text-decoration: none;
        }

        /* --- Filter and Search Styles --- */
        .filter-area {
            display: grid;
            grid-template-columns: 1fr 1fr 2fr;
            gap: 15px;
            margin-bottom: 20px;
        }

        .filter-area select,
        .filter-area input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-group {
            display: flex;
        }

        .search-group button {
            padding: 10px 15px;
            font-size: 16px;
            background: #b30000;
            color: white;
            border-radius: 0 4px 4px 0;
            margin-top: 0;
            width: 100px;
        }

        .search-group input {
            border-radius: 4px 0 0 4px;
            flex-grow: 1;
        }

        /* Style for initial hidden assignment groups */
        .hidden-group {
            display: none;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Manage Teachers & Admins</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <div class="form-table-layout">
            <div class="form-container">
                <h2>Add New User</h2>
                <?php if ($message): ?>
                    <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>"><?php echo $message; ?></p>
                <?php endif; ?>
                <?php if ($error): ?>
                    <p class="message error"><?php echo $error; ?></p>
                <?php endif; ?>

                <form action="manage_teachers.php" method="POST" id="add-teacher-form">
                    <input type="hidden" name="add_teacher" value="1">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" name="full_name" required>
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select name="role" id="role-select" required>
                            <option value="teacher">Teacher (Academics/Results)</option>
                            <option value="admin">Administrator (Super User)</option>
                            <option value="FrontDesk">FrontDesk (Admissions/Contact)</option>
                        </select>
                    </div>
                    <div class="form-group hidden-group" id="main-subject-group">
                        <label for="main_subject">Main Subject (Used for Teacher Roster)</label>
                        <select name="main_subject">
                            <option value="">-- Select Main Subject --</option>
                            <?php foreach ($subjects_list as $subject): ?>
                                <option value="<?php echo htmlspecialchars($subject); ?>"><?php echo htmlspecialchars($subject); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group assignments-area hidden-group" id="multi-assignment-section">
                        <label style="color: #b30000;">Multiple Class Assignments (Required for Teachers)</label>

                        <div class="assignment-selector">
                            <select id="class-select-form" required>
                                <option value="">-- Select Class --</option>
                                <?php
                                foreach ($full_classes_list as $class): ?>
                                    <option value="<?php echo $class['class_id']; ?>"><?php echo htmlspecialchars($class['class_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <select id="subject-select-form" required disabled>
                                <option value="">-- Select Subject --</option>
                            </select>
                            <button type="button" onclick="addAssignment()">Add</button>
                        </div>

                        <ul id="assigned-classes-list" class="assigned-list">
                        </ul>
                    </div>

                    <button type="submit" style="margin-top: 15px;">Add User</button>
                </form>
            </div>

            <div class="table-container">
                <h2>Current Users</h2>

                <form class="filter-area" method="GET" action="manage_teachers.php">
                    <select name="role_filter" onchange="this.form.submit()">
                        <option value="">-- Filter by Role --</option>
                        <option value="teacher" <?php echo ($filter_role == 'teacher') ? 'selected' : ''; ?>>Teacher</option>
                        <option value="admin" <?php echo ($filter_role == 'admin') ? 'selected' : ''; ?>>Administrator</option>
                        <option value="FrontDesk" <?php echo ($filter_role == 'FrontDesk') ? 'selected' : ''; ?>>FrontDesk</option>
                    </select>
                    <div class="search-group">
                        <input type="text" name="search" placeholder="Search Name or Username" value="<?php echo htmlspecialchars($search_term); ?>">
                        <button type="submit">Search</button>
                    </div>
                </form>

                <table class="list-table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Role</th>
                            <th>Main Subject</th>
                            <th>Assignments</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // FIX: Check if $users_result is valid before attempting to loop
                        if ($users_result && $users_result->num_rows > 0) {
                            while ($user = $users_result->fetch_assoc()):
                                $teacher_id = $user['teacher_id'];
                        ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                    <td>
                                        <?php
                                        $role_text = match ($user['role']) {
                                            'admin' => 'Administrator',
                                            'teacher' => 'Teacher',
                                            'FrontDesk' => 'FrontDesk/Admissions',
                                            default => 'Unknown'
                                        };
                                        echo htmlspecialchars($role_text);
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo !empty($user['main_subject']) ? htmlspecialchars($user['main_subject']) : 'N/A'; ?>
                                    </td>
                                    <td>
                                        <?php
                                        if (isset($assignments_map[$teacher_id])):
                                        ?>
                                            <ul style="padding-left: 15px; margin: 0;">
                                                <?php foreach ($assignments_map[$teacher_id] as $class => $subjects): ?>
                                                    <li style="margin-bottom: 5px;">
                                                        <strong><?php echo htmlspecialchars($class); ?>:</strong>
                                                        <?php echo htmlspecialchars(implode(', ', $subjects)); ?>
                                                    </li>
                                                <?php endforeach; ?>
                                            </ul>
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <a href="edit_teacher.php?id=<?php echo $user['teacher_id']; ?>" class="actions-link">Edit</a>
                                        |
                                        <a href="reset_teacher_password.php?id=<?php echo $user['teacher_id']; ?>" class="actions-link">Reset Pass</a>
                                        |
                                        <?php if ($user['teacher_id'] != $current_user_id): // Don't show Delete for self 
                                        ?>
                                            <a href="manage_teachers.php?delete=<?php echo $user['teacher_id']; ?>"
                                                class="actions-link-danger"
                                                onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone.');">Delete</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                        <?php endwhile;
                        } else {
                            echo '<tr><td colspan="6">No users found.</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Data maps needed for JS
        const classSubjectMap = <?php echo json_encode($class_subject_map); ?>;

        const classSelectForm = document.getElementById('class-select-form');
        const subjectSelectForm = document.getElementById('subject-select-form');
        const assignedList = document.getElementById('assigned-classes-list');
        const assignmentSection = document.getElementById('multi-assignment-section');
        const roleSelect = document.getElementById('role-select');
        const mainSubjectGroup = document.getElementById('main-subject-group');

        // Initial visibility check for assignment section (Assignment inputs are only needed for teachers/admins)
        document.addEventListener('DOMContentLoaded', () => {
            toggleAssignmentVisibility();
        });

        roleSelect.addEventListener('change', toggleAssignmentVisibility);

        function toggleAssignmentVisibility() {
            const role = roleSelect.value;
            // Only show assignment section and main subject for Teacher
            if (role === 'teacher') {
                assignmentSection.classList.remove('hidden-group');
                mainSubjectGroup.classList.remove('hidden-group');
            } else {
                assignmentSection.classList.add('hidden-group');
                mainSubjectGroup.classList.add('hidden-group');
            }
        }


        // Event listener to populate subjects when a class is selected
        classSelectForm.addEventListener('change', function() {
            const classId = this.value;
            subjectSelectForm.innerHTML = '<option value="">-- Select Subject --</option>';
            subjectSelectForm.disabled = true;

            if (classId && classSubjectMap[classId]) {
                const subjects = classSubjectMap[classId];
                subjects.forEach(subject => {
                    subjectSelectForm.innerHTML += `<option value="${subject.subject_id}">${subject.subject_name}</option>`;
                });
                subjectSelectForm.disabled = false;
            }
        });

        function addAssignment() {
            const classId = classSelectForm.value;
            const subjectId = subjectSelectForm.value;

            if (!classId || !subjectId) {
                alert("Please select both a Class and a Subject.");
                return;
            }

            // Get selected text names
            const className = classSelectForm.options[classSelectForm.selectedIndex].text;
            const subjectName = subjectSelectForm.options[subjectSelectForm.selectedIndex].text;

            // Unique identifier for this assignment
            const assignmentValue = `${classId}|${subjectId}`;

            // Check for duplicates
            if (document.querySelector(`input[value="${assignmentValue}"]`)) {
                alert(`Assignment ${className} / ${subjectName} is already added.`);
                return;
            }

            // Create list item and hidden input
            const listItem = document.createElement('li');
            listItem.innerHTML = `
                <span>${className} / ${subjectName}</span>
                <input type="hidden" name="new_assignments[]" value="${assignmentValue}">
                <button type="button" onclick="this.parentNode.remove()">Remove</button>
            `;

            assignedList.appendChild(listItem);
        }
    </script>

</body>

</html>