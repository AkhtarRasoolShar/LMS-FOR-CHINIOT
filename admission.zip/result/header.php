<?php
// Get the current page filename to change styles
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chiniot Islamia School - Result Portal</title>

    <style>
        /* General Body */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding-top: 60px;
            /* Make space for fixed header */
        }

        /* Main Header */
        .main-header {
            background: #fff;
            border-bottom: 2px solid #006400;
            padding: 10px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            box-sizing: border-box;
            /* Include padding in width */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .main-header .logo {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .main-header .logo img {
            width: 40px;
        }

        .main-header .logo h1 {
            font-size: 20px;
            color: #006400;
            margin: 0;
        }

        .main-header .nav-links a {
            color: #006400;
            text-decoration: none;
            font-weight: bold;
            margin-left: 20px;
        }

        /* Footer */
        .main-footer {
            text-align: center;
            padding: 20px;
            background: #333;
            color: white;
            margin-top: 30px;
            font-size: 14px;
        }

        /* Hide header/footer from printing */
        @media print {

            .main-header,
            .main-footer,
            .button-container {
                display: none !important;
            }

            body {
                padding-top: 0;
            }
        }
    </style>

    <?php if ($currentPage == 'view_result.php' || $currentPage == 'view_result_primary.php'): ?>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

        <style>
            .button-container {
                text-align: center;
                margin: 20px auto;
                padding: 10px;
                background: #fff;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                max-width: 210mm;
                box-sizing: border-box;
            }

            .action-button {
                display: inline-block;
                width: 180px;
                margin: 5px;
                padding: 12px;
                text-align: center;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                font-size: 16px;
                font-weight: bold;
                border: none;
                cursor: pointer;
            }

            .back-button {
                background: #555;
            }

            .print-button {
                background: #006400;
            }

            .pdf-button {
                background: #b30000;
            }

            /* College Report Card Styles */
            <?php if ($currentPage == 'view_result.php'): ?>.report-card {
                width: 210mm;
                min-height: 297mm;
                margin: 20px auto;
                background: #fff;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                padding: 15mm;
                box-sizing: border-box;
            }

            .header {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                border-bottom: 3px solid #006400;
                padding-bottom: 10px;
            }

            .header-logo {
                width: 100px;
            }

            .header-text {
                text-align: center;
                color: #006400;
            }

            .header-text h1 {
                font-size: 24px;
                margin: 0;
            }

            .header-text p {
                font-size: 18px;
                margin: 5px 0 0 0;
                font-weight: bold;
            }

            .header-photo {
                width: 100px;
                height: 120px;
                border: 2px solid #006400;
                object-fit: cover;
            }

            .student-info {
                width: 100%;
                margin-top: 20px;
                border-collapse: collapse;
            }

            .student-info th,
            .student-info td {
                border: 1px solid #333;
                padding: 6px 8px;
                font-size: 12px;
                text-align: left;
            }

            .student-info th {
                background-color: #f2f2f2;
                width: 15%;
                font-weight: bold;
            }

            .student-info td {
                width: 35%;
                font-weight: bold;
            }

            .section-title {
                text-align: center;
                font-size: 16px;
                font-weight: bold;
                margin-top: 20px;
                margin-bottom: 10px;
                color: #006400;
            }

            .marks-table,
            .summary-table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
                font-size: 12px;
            }

            .marks-table th,
            .marks-table td,
            .summary-table th,
            .summary-table td {
                border: 1px solid #333;
                padding: 6px;
                text-align: center;
            }

            .marks-table th,
            .summary-table th {
                background-color: #f2f2f2;
                font-weight: bold;
            }

            .marks-table .subject-name,
            .summary-table .summary-row {
                text-align: left;
                font-weight: bold;
            }

            .page-break {
                page-break-before: always;
                border-top: 2px dashed #ccc;
                margin-top: 20px;
                padding-top: 15mm;
            }

            <?php endif; ?>

            /* Primary Report Card Styles */
            <?php if ($currentPage == 'view_result_primary.php'): ?>.report-card {
                width: 1000px;
                margin: 20px auto;
                background: #fff;
                border: 2px solid #333;
                padding: 20px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }

            .header {
                text-align: center;
                line-height: 1.2;
            }

            .header h1 {
                color: #006400;
                margin: 0;
            }

            .header h2 {
                color: #333;
                margin: 5px 0;
            }

            .header h3 {
                background: #006400;
                color: white;
                padding: 5px;
                margin: 10px 0;
            }

            .info-table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 10px;
            }

            .info-table td {
                padding: 4px;
            }

            .info-table .label {
                font-weight: bold;
                width: 80px;
            }

            .info-table .value {
                border-bottom: 1px solid #333;
            }

            .marks-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
            }

            .marks-table th,
            .marks-table td {
                border: 1px solid #333;
                padding: 5px;
                text-align: center;
                font-size: 12px;
            }

            .marks-table th {
                background: #f2f2f2;
            }

            .marks-table .subject-name {
                text-align: left;
            }

            .summary-grid {
                display: grid;
                grid-template-columns: 1.5fr 1fr;
                gap: 20px;
                margin-top: 15px;
            }

            .summary-table {
                width: 100%;
                border-collapse: collapse;
            }

            .summary-table td {
                border: 1px solid #333;
                padding: 5px;
                font-size: 12px;
            }

            .summary-table .label {
                font-weight: bold;
            }

            .summary-table .value {
                text-align: center;
            }

            <?php endif; ?>@media print {
                body {
                    margin: 0;
                    background: #fff;
                    padding-top: 0;
                }

                .report-card {
                    margin: 0;
                    box-shadow: none;
                    border: none;
                }
            }
        </style>
    <?php endif; ?>

    <?php if ($currentPage == 'index.php' || $currentPage == 'admit_card.php'): ?>
        <style>
            .container {
                background: #fff;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                padding: 40px;
                text-align: center;
                max-width: 400px;
                margin: 50px auto;
            }

            .container img {
                width: 100px;
                margin-bottom: 20px;
            }

            .container h2 {
                margin: 0 0 20px 0;
            }

            .container .form-group {
                text-align: left;
            }

            .container .form-group label {
                font-weight: bold;
                margin-bottom: 5px;
                display: block;
            }

            .container input[type="text"] {
                width: 100%;
                padding: 12px;
                margin-bottom: 20px;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
            }

            .container button {
                background-color: #006400;
                color: white;
                padding: 14px 20px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                width: 100%;
                font-size: 16px;
                margin-top: 10px;
            }

            .container button:hover {
                background-color: #004d00;
            }

            .error-message {
                color: #b30000;
                font-weight: bold;
                margin-bottom: 15px;
            }

            /* Styles for index.php's notice board */
            .notice-board {
                max-width: 800px;
                margin: 30px auto;
                background: #fff;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                padding: 30px;
            }

            .notice-board h2 {
                margin: 0 0 20px 0;
                color: #006400;
                border-bottom: 2px solid #f4f4f4;
                padding-bottom: 10px;
            }

            .notice-item {
                margin-bottom: 15px;
                padding-bottom: 15px;
                border-bottom: 1px solid #eee;
            }

            .notice-item:last-child {
                border-bottom: none;
                margin-bottom: 0;
                padding-bottom: 0;
            }

            .notice-item h3 {
                margin: 0 0 5px 0;
            }

            .notice-item span {
                font-size: 12px;
                color: #777;
                display: block;
                margin-bottom: 10px;
            }

            .notice-item p {
                margin: 0;
                font-size: 14px;
                line-height: 1.5;
            }

            /* * NEW: Admit Card Styles 
             * This style block is for the printable admit card. 
             */
            <?php if ($currentPage == 'admit_card.php'): ?>.admit-card-container {
                width: 210mm;
                /* A4 width */
                min-height: 148.5mm;
                /* Half A4 height (A5) */
                margin: 20px auto;
                background: #fff;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                border: 2px solid #b30000;
                padding: 10mm;
                box-sizing: border-box;
                font-size: 14px;
            }

            .admit-card-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 3px solid #b30000;
                padding-bottom: 10px;
                margin-bottom: 20px;
            }

            .admit-card-header img {
                width: 80px;
            }

            .admit-card-header h1 {
                font-size: 20px;
                margin: 0;
                color: #b30000;
                text-align: center;
                line-height: 1.2;
            }

            .admit-card-info-grid {
                display: grid;
                grid-template-columns: 3fr 1fr;
                gap: 20px;
            }

            .admit-card-info-table {
                width: 100%;
                border-collapse: collapse;
            }

            .admit-card-info-table th,
            .admit-card-info-table td {
                padding: 8px;
                border: 1px solid #ccc;
                text-align: left;
            }

            .admit-card-info-table th {
                background-color: #f2f2f2;
                font-weight: bold;
                width: 30%;
            }

            .photo-box {
                width: 100px;
                height: 120px;
                border: 2px solid #b30000;
                margin: 0 auto;
                display: flex;
                align-items: center;
                justify-content: center;
                overflow: hidden;
            }

            .photo-box img {
                width: 100%;
                height: 100%;
                object-fit: cover;
            }

            .admit-card-footer {
                margin-top: 30px;
                padding-top: 10px;
                border-top: 1px solid #ccc;
                font-size: 12px;
                display: flex;
                justify-content: space-between;
                align-items: flex-end;
            }

            .admit-card-signature {
                text-align: center;
                width: 200px;
            }

            .admit-card-signature p {
                border-top: 1px dashed #333;
                margin-top: 40px;
                padding-top: 5px;
            }

            @media print {
                .admit-card-container {
                    box-shadow: none;
                    border: none;
                    margin: 0;
                }
            }

            <?php endif; ?>
        </style>
    <?php endif; ?>

</head>

<body>

    <header class="main-header">
        <div class="logo">
            <img src="logo.png" alt="School Logo">
            <h1>Chiniot Islamia School</h1>
        </div>
        <nav class="nav-links">
            <a href="index.php">Home</a>
        </nav>
    </header>

    <?php if ($currentPage == 'view_result.php' && isset($student_id)): ?>
        <div class="button-container">
            <a class="action-button back-button" href="index.php">&laquo; Back to Search</a>
            <button class="action-button print-button" onclick="window.print()">Print Report</button>
            <a class="action-button pdf-button" href="download_pdf.php?id=<?php echo $student_id; ?>">Download as PDF</a>
        </div>
    <?php endif; ?>

    <?php if ($currentPage == 'view_result_primary.php' && isset($student_id)): ?>
        <div class="button-container">
            <a href="index.php" class="action-button" style="background-color: #555;">&laquo; Back to Search</a>
            <button onclick="window.print()" class="action-button">Print Report</button>
            <a href="download_pdf_primary.php?id=<?php echo $student_id; ?>" class="action-button" style="background-color: #b30000;">Download as PDF</a>
        </div>
    <?php endif; ?>

    <?php
    // This check relies on $applicant being available in the global scope of admit_card.php
    if ($currentPage == 'admit_card.php' && isset($applicant) && !empty($applicant)):
    ?>
        <div class="button-container">
            <a class="action-button back-button" href="index.php">&laquo; Back to Home</a>
            <button class="action-button print-button" onclick="window.print()">Print Admit Card</button>
            <a class="action-button pdf-button"
                href="download_admit_card.php?form_no=<?php echo $applicant['form_no']; ?>"
                style="background-color: #b30000;">
                Download as PDF
            </a>
        </div>
    <?php endif; ?>