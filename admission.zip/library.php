<?php
$pageTitle = "Library";
include 'header.php';
?>

<style>
    .library-intro {
        text-align: center;
        font-size: 1.1em;
    }

    .search-button {
        display: inline-block;
        margin-top: 20px;
        padding: 12px 25px;
        background-color: #006400;
        color: white;
        text-decoration: none;
        font-weight: bold;
        border-radius: 5px;
    }

    .category-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .category-card {
        border: 1px solid #eee;
        border-radius: 5px;
    }

    .category-card h4 {
        margin: 0;
        padding: 10px 15px;
        background: #f9f9f9;
        border-bottom: 1px solid #eee;
    }

    .category-card ul {
        list-style: none;
        padding: 15px;
        margin: 0;
    }

    .category-card li {
        padding-bottom: 8px;
    }
</style>

<div class="container">
    <h2>CHINIOT LIBRARY</h2>

    <div class="library-intro">
        <p>
            A very commodious and rich Library, centrally located, boasts a collection of <strong>more than 13,396 books</strong> on various subjects.
            It is managed by <strong>two qualified librarians</strong> and uses a dedicated <strong>Software Program</strong> to organize the collection on modern lines.
        </p>
        <p>
            All widely circulated and important journals / periodicals (like <i>Reader's Digest</i>, <i>Newsweek</i>, etc.)
            and daily news papers are also kept to groom the interest of the students.
        </p>
        <a href="#" class="search-button">FOR GRAND SEARCH CLICK HERE →</a>
    </div>

    <h3>Collection Categories</h3>
    <div class="category-grid">
        <div class="category-card">
            <h4>LANGUAGE (Shelf 6)</h4>
            <ul>
                <li>Urdu Language</li>
                <li>English Language</li>
                <li>Arabic Language</li>
                <li>Sindhi Language</li>
            </ul>
        </div>
        <div class="category-card">
            <h4>TEXT BOOK (Shelf 22)</h4>
            <ul>
                <li>Islamiat & Urdu Text</li>
                <li>S Studies & Art Text</li>
                <li>English Text</li>
                <li>Biology & Comp Text</li>
                <li>Sindhi Language Text</li>
            </ul>
        </div>
        <div class="category-card">
            <h4>GENERALITIES (Shelf 6)</h4>
            <ul>
                <li>Art</li>
                <li>General Knowledge</li>
                <li>Psychology</li>
                <li>Philosophy</li>
            </ul>
        </div>
        <div class="category-card">
            <h4>URDU LITERATURE (Shelf 10, 11, 12)</h4>
            <ul>
                <li>Urdu Adab</li>
                <li>Urdu Fiction</li>
                <li>Urdu Poetry</li>
            </ul>
        </div>
        <div class="category-card">
            <h4>SOCIAL SCIENCE & TECHNOLOGY (Shelf 5)</h4>
            <ul>
                <li>Civics & Education</li>
                <li>Economics & Statistics</li>
                <li>Engineering</li>
                <li>Commerce</li>
                <li>Electronics</li>
            </ul>
        </div>
        <div class="category-card">
            <h4>PURE SCIENCE (Shelf 7, 8, 16, 21)</h4>
            <ul>
                <li>Science</li>
                <li>Biology</li>
                <li>Mathematics</li>
                <li>Physics</li>
                <li>Chemistry</li>
            </ul>
        </div>
        <div class="category-card">
            <h4>ISLAM & ISLAMIAT (Shelf 2, 4, 19, 20)</h4>
            <ul>
                <li>Islamic Reference Books</li>
                <li>Islamic Ethics</li>
                <li>Islamic Leaders</li>
                <li>Islamic History</li>
                <li>Seratun Nabi</li>
            </ul>
        </div>
        <div class="category-card">
            <h4>HISTORY & GEOGRAPHY (Shelf 13, 14, 15)</h4>
            <ul>
                <li>Pakistan Studies</li>
                <li>World History</li>
                <li>Indo Pak History</li>
            </ul>
        </div>
        <div class="category-card">
            <h4>ENGLISH LITERATURE (Shelf 9)</h4>
            <ul>
                <li>English Fiction</li>
            </ul>
        </div>
        <div class="category-card">
            <h4>REFERENCE BOOKS (Shelf 17, 18)</h4>
            <ul>
                <li>Dictionaries</li>
                <li>Encyclopedia</li>
            </ul>
        </div>
    </div>

    <h3>Periodicals</h3>
    <div class="category-grid">
        <div class="category-card">
            <h4>ENGLISH</h4>
            <ul>
                <li>Time (Monthly)</li>
                <li>Reader Digest (Monthly)</li>
                <li>V-Shine Magazine (Monthly)</li>
            </ul>
        </div>
        <div class="category-card">
            <h4>URDU</h4>
            <ul>
                <li>Taleem o Tarbiat (Monthly)</li>
                <li>Nonihal (Monthly)</li>
                <li>Jagmag Tare (Monthly)</li>
                <li>Urdu Digest (Monthly)</li>
                <li>Akhbar-e-Jehan (Weekly)</li>
                <li>Family Magazine (Weekly)</li>
            </ul>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>