<?php
include 'admin_check.php'; // Secure this page

$message = '';

// --- Handle adding a new subject (GLOBAL) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_subject'])) {
    $subject_name = $_POST['subject_name'];
    $stmt = $conn->prepare("INSERT INTO subjects (subject_name) VALUES (?)");
    $stmt->bind_param("s", $subject_name);
    if ($stmt->execute()) {
        $message = "Success! Subject '$subject_name' added globally.";
    } else {
        $message = "Error: Subject name may already exist. " . $stmt->error;
    }
    $stmt->close();
}

// --- Handle deleting a subject (GLOBAL) ---
if (isset($_GET['delete'])) {
    $subject_id = (int)$_GET['delete'];
    // Deleting a global subject is dangerous; it may break existing assignments/results due to foreign keys.
    // We rely on the database constraints to block deletion if links exist.
    $stmt = $conn->prepare("DELETE FROM subjects WHERE subject_id = ?");
    $stmt->bind_param("i", $subject_id);
    if ($stmt->execute()) {
        $message = "Subject deleted globally.";
    } else {
        $message = "Error: Cannot delete subject. It is linked to classes, results, or assignments.";
    }
    $stmt->close();
}

// --- Handle Assigning Subject to Class Curriculum ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_to_class'])) {
    $class_id = (int)$_POST['class_id'];
    $subject_id = (int)$_POST['subject_id_assign'];

    if ($class_id > 0 && $subject_id > 0) {
        // We use INSERT IGNORE because it's non-critical if the assignment already exists
        $stmt = $conn->prepare("INSERT IGNORE INTO class_subjects (class_id, subject_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $class_id, $subject_id);
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $message = "Success! Subject assigned to selected class.";
            } else {
                $message = "Warning: Subject was already assigned to that class.";
            }
        } else {
            $message = "Error assigning subject: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $message = "Error: Invalid Class or Subject ID provided.";
    }
}


// --- Get list of all subjects (Master List) and all classes ---
$subjects_result = $conn->query("SELECT * FROM subjects ORDER BY subject_name");
$classes_result = $conn->query("SELECT class_id, class_name FROM classes ORDER BY class_name");

$classes_list = [];
if ($classes_result) {
    while ($row = $classes_result->fetch_assoc()) {
        $classes_list[] = $row;
    }
}

// Get a list of all currently linked class_id/subject_id pairs for quick lookup
$linked_subjects_result = $conn->query("SELECT class_id, subject_id FROM class_subjects");
$linked_map = [];
if ($linked_subjects_result) {
    while ($row = $linked_subjects_result->fetch_assoc()) {
        $linked_map[$row['subject_id']][$row['class_id']] = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Subjects</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
            display: grid;
            grid-template-columns: 1fr 2fr;
            /* Adjusted grid ratio */
            gap: 30px;
        }

        .form-container,
        .table-container {
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        h3 {
            margin-top: 0;
            margin-bottom: 10px;
            color: #b30000;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button.assign-btn {
            background-color: #006400;
            /* Green for assignment */
            padding: 5px 10px;
            font-size: 14px;
            border-radius: 2px;
            white-space: nowrap;
        }

        button.assign-btn:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        .list-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .list-table th,
        .list-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .list-table th {
            background: #f2f2f2;
        }

        .list-table td select {
            padding: 5px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        .list-table a {
            color: #b30000;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Manage Subjects & Curriculum</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">

        <div class="form-container">
            <h2>1. Add New Global Subject</h2>
            <?php if ($message): ?>
                <p class="message <?php echo (strpos($message, 'Error') !== false) ? 'error' : ''; ?>"><?php echo $message; ?></p>
            <?php endif; ?>

            <form action="manage_subjects.php" method="POST">
                <input type="hidden" name="add_subject" value="1">
                <div class="form-group">
                    <label for="subject_name">Subject Name (Master List)</label>
                    <input type="text" name="subject_name" required>
                </div>
                <button type="submit">Add Subject</button>
            </form>

            <hr style="margin: 30px 0;">

            <h2>2. Manage Class Curricula</h2>
            <p>Use the "Manage Curriculum" link next to a class name to add/remove subjects for that specific class.</p>
            <a href="manage_classes.php" style="color: #006400; font-weight: bold;">&raquo; Go to Manage Classes & Curriculum</a>
        </div>

        <div class="table-container">
            <h2>Current Subjects (Master List)</h2>
            <h3>3. Assign Subjects to Classes</h3>
            <table class="list-table">
                <thead>
                    <tr>
                        <th>Subject Name</th>
                        <th>Global Actions</th>
                        <th>Assign to Class</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($subjects_result->num_rows > 0) {
                        $subjects_result->data_seek(0); // Rewind pointer
                        while ($subject = $subjects_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($subject['subject_name']); ?></td>
                                <td>
                                    <a href="manage_subjects.php?delete=<?php echo $subject['subject_id']; ?>"
                                        onclick="return confirm('WARNING: Deleting this global subject will remove it from ALL assignments and results. Are you sure?');">Delete</a>
                                </td>
                                <td>
                                    <form action="manage_subjects.php" method="POST" style="display: flex; gap: 5px; align-items: center;">
                                        <input type="hidden" name="assign_to_class" value="1">
                                        <input type="hidden" name="subject_id_assign" value="<?php echo $subject['subject_id']; ?>">

                                        <select name="class_id" required>
                                            <option value="">-- Select Class --</option>
                                            <?php
                                            foreach ($classes_list as $class) {
                                                $is_linked = isset($linked_map[$subject['subject_id']][$class['class_id']]);
                                                $disabled_text = $is_linked ? ' (Assigned)' : '';
                                                $disabled_attr = $is_linked ? 'disabled' : '';
                                                echo "<option value='{$class['class_id']}' {$disabled_attr}>" . htmlspecialchars($class['class_name']) . "{$disabled_text}</option>";
                                            }
                                            ?>
                                        </select>
                                        <button type="submit" class="assign-btn">Assign</button>
                                    </form>
                                </td>
                            </tr>
                    <?php endwhile;
                    } else {
                        echo '<tr><td colspan="3">No subjects found.</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>

    </div>
</body>

</html>