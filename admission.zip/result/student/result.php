<?php
$pageTitle = "Academic Records";
include 'header_student.php';

$selected_year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$years = range(date('Y'), 2022);
$terms = ['1st QUARTERLY', 'MID TERM', '2nd QUARTERLY', 'FINAL TERM'];
?>

<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th {
        background: #f8f9fa;
        color: #333;
        text-align: left;
        padding: 12px;
        border-bottom: 2px solid #ddd;
    }

    td {
        border-bottom: 1px solid #eee;
        padding: 12px;
    }

    .status-pass {
        color: green;
        font-weight: bold;
    }

    .status-fail {
        color: red;
        font-weight: bold;
    }

    .status-pending {
        color: orange;
        font-weight: bold;
    }
</style>

<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h3 style="margin:0; color:#004a99;">Exam History</h3>
        <form method="GET">
            <select name="year" onchange="this.form.submit()" style="padding:8px; border-radius:4px; border:1px solid #ccc;">
                <?php foreach ($years as $y): ?>
                    <option value="<?php echo $y; ?>" <?php echo ($y == $selected_year) ? 'selected' : ''; ?>>Session <?php echo $y; ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>Term Name</th>
                <th>Obtained Marks</th>
                <th>Total Marks</th>
                <th>Percentage</th>
                <th>Grade</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($terms as $t):
                $safe_term = $conn->real_escape_string($t);
                $safe_year = $conn->real_escape_string($selected_year);

                // Check if session_year column exists
                $col_check = $conn->query("SHOW COLUMNS FROM summaries LIKE 'session_year'");
                $sql = "SELECT * FROM summaries WHERE student_id = $student_id AND term_name = '$safe_term'";
                if ($col_check->num_rows > 0) $sql .= " AND session_year = '$safe_year'";

                $res = $conn->query($sql);
                $data = ($res && $res->num_rows > 0) ? $res->fetch_assoc() : null;
            ?>
                <tr>
                    <td style="font-weight: bold; color:#555;"><?php echo $t; ?></td>
                    <td><?php echo $data ? $data['obtained_marks'] : '-'; ?></td>
                    <td><?php echo $data ? $data['out_of_marks'] : '-'; ?></td>
                    <td>
                        <?php if ($data && isset($data['percentage'])) {
                            echo $data['percentage'] . "%";
                        } else {
                            echo '-';
                        } ?>
                    </td>
                    <td>
                        <?php
                        if ($data) {
                            echo $data['grade'] ?? '-';
                        } else {
                            echo '<span style="color:#999;">Pending</span>';
                        }
                        ?>
                    </td>
                    <td>
                        <?php if ($data): ?>
                            <a href="view_result.php?term=<?php echo urlencode($t); ?>&year=<?php echo $selected_year; ?>" class="btn-primary" style="font-size:12px; padding:6px 12px;"><i class="fas fa-eye"></i> View Card</a>
                        <?php else: ?>
                            <span style="color:#ccc; font-size:20px;">&minus;</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</div>
</div>
</body>

</html>