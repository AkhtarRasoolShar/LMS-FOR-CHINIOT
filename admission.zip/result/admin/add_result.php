<?php
include 'admin_check.php';

// --- FIX: Use the standardized session variable 'user_id' ---
$logged_in_teacher_id = $_SESSION['user_id'];

$message = '';

// --- Handle Form Submission (POST) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['student_id'])) {

    $student_id = (int)$_POST['student_id'];
    $term_name = $_POST['term_name'];

    try {
        // Teacher is clear to proceed. Begin transaction.
        $conn->begin_transaction();

        $subject_ids = $_POST['subject_id'];
        $marks_obtained = $_POST['marks_obtained'];
        $total_marks = $_POST['total_marks'];
        $unannounced_tests = $_POST['unannounced_test'];

        // --- 1. Prepare for insertion/update into 'results' table ---
        $stmt_results = $conn->prepare("
            INSERT INTO results 
                (student_id, subject_id, term_name, marks_obtained, total_marks, unannounced_test) 
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE 
                marks_obtained = VALUES(marks_obtained),
                total_marks = VALUES(total_marks),
                unannounced_test = VALUES(unannounced_test)
        ");

        // --- Get the student's class_id (needed for permission checks) ---
        $class_check_stmt = $conn->prepare("
            SELECT c.class_id, st.class 
            FROM students st 
            JOIN classes c ON st.class LIKE CONCAT('%', c.class_name, '%') 
            WHERE st.student_id = ?
        ");
        $class_check_stmt->bind_param("i", $student_id);
        $class_check_stmt->execute();
        $student_class_data = $class_check_stmt->get_result()->fetch_assoc();
        $student_class_id = $student_class_data['class_id'] ?? 0;
        $class_check_stmt->close();

        if ($student_class_id === 0) {
            throw new Exception("Student's class ID could not be found.");
        }


        // Prepare statement to quickly verify the assignment exists
        $assignment_exists_stmt = $conn->prepare("
            SELECT assignment_id FROM teacher_assignments 
            WHERE teacher_id = ? AND class_id = ? AND subject_id = ?
        ");

        // Loop through all subjects submitted from the form
        for ($i = 0; $i < count($subject_ids); $i++) {
            $current_subject_id = (int)$subject_ids[$i];

            // Verify teacher is assigned to this specific subject in this class
            $assignment_exists_stmt->bind_param("iii", $logged_in_teacher_id, $student_class_id, $current_subject_id);
            $assignment_exists_stmt->execute();

            // Use get_result() to check num_rows
            $assignment_result = $assignment_exists_stmt->get_result();

            if ($assignment_result->num_rows > 0) {
                // Assignment confirmed. Process marks.
                $ua_test_score = !empty($unannounced_tests[$i]) ? $unannounced_tests[$i] : NULL;
                $stmt_results->bind_param("iisdis", $student_id, $current_subject_id, $term_name, $marks_obtained[$i], $total_marks[$i], $ua_test_score);
                $stmt_results->execute();
            }
        }
        $assignment_exists_stmt->close();
        $stmt_results->close();

        // --- 3. Insert/Update 'summaries' table ---
        $stmt_summary = $conn->prepare("
            INSERT INTO summaries 
                (student_id, teacher_id, term_name, obtained_marks, out_of_marks, percentage, rank, grade, attendance, remarks, is_locked) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            ON DUPLICATE KEY UPDATE 
                teacher_id = VALUES(teacher_id), 
                obtained_marks = VALUES(obtained_marks), out_of_marks = VALUES(out_of_marks),
                percentage = VALUES(percentage), rank = VALUES(rank), grade = VALUES(grade),
                attendance = VALUES(attendance), remarks = VALUES(remarks), is_locked = 1
        ");

        $stmt_summary->bind_param(
            "iisddisiss",
            $student_id,
            $logged_in_teacher_id,
            $term_name,
            $_POST['summary_obtained'],
            $_POST['summary_outof'],
            $_POST['summary_percentage'],
            $_POST['summary_rank'],
            $_POST['summary_grade'],
            $_POST['summary_attendance'],
            $_POST['summary_remarks']
        );
        $stmt_summary->execute();
        $stmt_summary->close();

        // If no exception was thrown, commit the transaction
        $conn->commit();
        $message = "Success! Results for Student $student_id for $term_name have been SUBMITTED AND LOCKED.";
    } catch (mysqli_sql_exception $e) {
        // Rollback the transaction if any query failed
        if (isset($conn) && $conn->in_transaction) {
            $conn->rollback();
        }
        // Log the real error for debugging
        error_log("add_result.php DB Error: " . $e->getMessage());
        // Show user-friendly error
        $message = "Database Error: Could not save results. Please contact an administrator.";
    } catch (Exception $e) {
        // Handle general PHP/logic errors
        $message = "Error: " . $e->getMessage();
    }
}

// --- Fetch only the classes assigned to THIS teacher for the dropdown ---
$class_stmt = $conn->prepare("
    SELECT DISTINCT c.class_id, c.class_name 
    FROM teacher_assignments ta
    JOIN classes c ON ta.class_id = c.class_id
    WHERE ta.teacher_id = ? 
    ORDER BY c.class_name
");
$class_stmt->bind_param("i", $logged_in_teacher_id);
$class_stmt->execute();
$class_result = $class_stmt->get_result();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Upload Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #006400;
            /* Dark Green */
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 900px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #006400;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        fieldset {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 20px;
        }

        legend {
            font-weight: bold;
            color: #006400;
            padding: 0 10px;
        }

        .split-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .grid-4 {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 15px;
            padding-bottom: 5px;
        }

        hr {
            border-color: #ccc;
            margin-bottom: 15px;
        }

        .split-3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 15px;
        }

        .split-4 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr 1fr;
            gap: 15px;
        }

        #summary_attendance,
        #summary_obtained,
        #summary_outof,
        #summary_percentage {
            background: #eee;
            cursor: not-allowed;
        }

        #attendance_loader,
        #subject_loader {
            color: #006400;
            font-size: 12px;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Upload Student Result</h1>
        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <form action="add_result.php" method="POST" id="result-form">
            <fieldset>
                <legend>Student & Term</legend>
                <div class="split-2">
                    <div class="form-group">
                        <label for="class_select">Select Class</label>
                        <select id="class_select" name="class_name" required>
                            <option value="">-- Select Your Class --</option>
                            <?php
                            if (isset($class_result)) {
                                $class_result->data_seek(0);
                                while ($class = $class_result->fetch_assoc()): ?>
                                    <option value="<?php echo $class['class_id']; ?>"><?php echo htmlspecialchars($class['class_name']); ?></option>
                            <?php endwhile;
                            } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="student_id">Select Student</label>
                        <select id="student_id" name="student_id" required>
                            <option value="">-- First Select a Class --</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="term_name">Select Term</label>
                    <select id="term_name" name="term_name" required>
                        <option value="">-- Select a Term --</option>
                        <option value="1st QUARTERLY">1st QUARTERLY</option>
                        <option value="MID TERM">MID TERM (1st Term)</option>
                        <option value="2nd QUARTERLY">2nd QUARTERLY</option>
                        <option value="FINAL TERM">FINAL TERM (2nd Term)</option>
                    </select>
                </div>
            </fieldset>

            <fieldset>
                <legend>Subject Marks <span id="subject_loader"></span></legend>
                <div id="subject-marks-container">
                    <div class="grid-4">
                        <b>Subject Name</b>
                        <b>Marks Obtained</b>
                        <b>Total Marks</b>
                        <b>Unannounced Test (10)</b>
                    </div>
                    <hr>
                    <p>Please select a class and term first.</p>
                </div>
            </fieldset>

            <fieldset>
                <legend>Term Summary</legend>
                <div class="split-4">
                    <div class="form-group"><label>Obtained Marks (Total)</label><input type="number" step="0.01" name="summary_obtained" id="summary_obtained" readonly></div>
                    <div class="form-group"><label>Out Of Marks (Total)</label><input type="number" name="summary_outof" id="summary_outof" readonly></div>
                    <div class="form-group"><label>Percentage (%)</label><input type="number" step="0.01" name="summary_percentage" id="summary_percentage" readonly></div>
                    <div class="form-group"><label>Rank</label><input type="text" name="summary_rank" placeholder="e.g., 1st"></div>
                </div>
                <div class="split-3">
                    <div class="form-group"><label>Grade</label><input type="text" name="summary_grade" placeholder="e.g., A+"></div>
                    <div class="form-group"><label>Attendance (Auto-Calculated)</label><input type="number" id="summary_attendance" name="summary_attendance" readonly><span id="attendance_loader"></span></div>
                    <div class="form-group"><label>Remarks</label><select name="summary_remarks">
                            <option value="PASSED">PASSED</option>
                            <option value="FAILED">FAILED</option>
                        </select></div>
                </div>
            </fieldset>

            <button type="submit">Submit & Lock Result</button>
        </form>
    </div>

    <script>
        const classSelect = document.getElementById('class_select');
        const studentSelect = document.getElementById('student_id');
        const termSelect = document.getElementById('term_name');
        const subjectContainer = document.getElementById('subject-marks-container');
        const subjectLoader = document.getElementById('subject_loader');

        const obtainedTotalEl = document.getElementById('summary_obtained');
        const outOfTotalEl = document.getElementById('summary_outof');
        const percentageEl = document.getElementById('summary_percentage');
        const attendanceInput = document.getElementById('summary_attendance');
        const attendanceLoader = document.getElementById('attendance_loader');

        // --- 1. Load Students & Subjects when Class changes ---
        classSelect.addEventListener('change', () => {
            const classId = classSelect.value;
            // Clear student and subject containers
            studentSelect.innerHTML = '<option value="">Loading...</option>';
            subjectContainer.innerHTML = '<p>Please select a student.</p>';

            if (!classId) {
                studentSelect.innerHTML = '<option value="">-- First Select a Class --</option>';
                return;
            }

            // 1a. Fetch Students (calls ajax_get_students.php)
            // The status=current flag ensures only actively enrolled students are returned
            fetch(`../ajax_get_students.php?class_id=${classId}&status=current`)
                .then(response => response.json())
                .then(data => {
                    studentSelect.innerHTML = '<option value="">-- Select a Student --</option>';
                    data.forEach(student => {
                        // We use student.name which is already escaped from the PHP file
                        studentSelect.innerHTML += `<option value="${student.student_id}">${student.name} (S.NO: ${student.student_id})</option>`;
                    });
                })
                .catch(error => {
                    console.error('Error fetching students:', error);
                    studentSelect.innerHTML = '<option value="">Error loading students</option>';
                });


            // 1b. Fetch Subjects (calls ajax_get_subjects.php)
            subjectLoader.textContent = 'Loading subjects...';

            fetch(`../ajax_get_subjects.php?class_id=${classId}`)
                .then(response => response.json())
                .then(data => {
                    subjectLoader.textContent = '';

                    // --- FIX: Clear the container and re-add the static header ---
                    subjectContainer.innerHTML = `
                    <div class="grid-4">
                        <b>Subject Name</b>
                        <b>Marks Obtained</b>
                        <b>Total Marks</b>
                        <b>Unannounced Test (10)</b>
                    </div><hr>`;

                    if (data.length === 0) {
                        subjectContainer.innerHTML += '<p style="color: #b30000; font-weight: bold;">You are not assigned any subjects for this class, or the class has no subjects set up in the curriculum.</p>';
                    }

                    data.forEach(subject => {
                        // We use subject.subject_name which is already escaped from the PHP file
                        subjectContainer.innerHTML += `
                        <div class="grid-4 form-group">
                            <label>${subject.subject_name}</label>
                            <input type="hidden" name="subject_id[]" value="${subject.subject_id}">
                            <input type="number" step="0.01" name="marks_obtained[]" placeholder="e.g., 92.5" class="subject-marks">
                            <input type="number" name="total_marks[]" placeholder="e.g., 100" class="subject-total">
                            <input type="number" step="0.01" name="unannounced_test[]" placeholder="e.g., 10">
                        </div>`;
                    });

                    // Add event listeners after HTML is inserted
                    attachCalculationListeners();
                })
                .catch(error => {
                    console.error('Error fetching subjects:', error);
                    subjectLoader.textContent = 'Error loading subjects.';
                });
        });

        // --- 2. Get Attendance on Student/Term Change (calls ajax_get_attendance.php) ---
        function getAttendance() {
            const studentId = studentSelect.value;
            const termName = termSelect.value;

            if (studentId && termName) {
                attendanceInput.value = '';
                attendanceLoader.textContent = 'Calculating...';

                const formData = new FormData();
                formData.append('student_id', studentId);
                formData.append('term_name', termName);

                fetch(`../ajax_get_attendance.php`, { // Corrected path
                        method: 'POST',
                        body: formData
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        attendanceInput.value = data.present_days;
                        attendanceLoader.textContent = 'Done!';
                    })
                    .catch(error => {
                        console.error('Error fetching attendance:', error);
                        attendanceLoader.textContent = 'Error!';
                    });
            }
        }
        studentSelect.addEventListener('change', getAttendance);
        termSelect.addEventListener('change', getAttendance);

        // --- 3. Auto-Sum Totals (on marks input) ---
        function calculateTotals() {
            let totalObtained = 0;
            let totalOutOf = 0;

            const subjectMarksInputs = subjectContainer.querySelectorAll('.subject-marks');
            const subjectTotalInputs = subjectContainer.querySelectorAll('.subject-total');

            subjectMarksInputs.forEach(input => {
                totalObtained += parseFloat(input.value) || 0;
            });
            subjectTotalInputs.forEach(input => {
                totalOutOf += parseFloat(input.value) || 0;
            });

            obtainedTotalEl.value = totalObtained.toFixed(2);
            outOfTotalEl.value = totalOutOf;

            if (totalOutOf > 0) {
                percentageEl.value = ((totalObtained / totalOutOf) * 100).toFixed(2);
            } else {
                percentageEl.value = '0.00';
            }
        }

        // Function to attach listeners to dynamic inputs
        function attachCalculationListeners() {
            const subjectMarksInputs = subjectContainer.querySelectorAll('.subject-marks');
            const subjectTotalInputs = subjectContainer.querySelectorAll('.subject-total');

            subjectMarksInputs.forEach(input => {
                input.addEventListener('input', calculateTotals);
            });
            subjectTotalInputs.forEach(input => {
                input.addEventListener('input', calculateTotals);
            });
        }

        // Initial call in case form is pre-filled
        window.addEventListener('load', attachCalculationListeners);
    </script>
</body>

</html>