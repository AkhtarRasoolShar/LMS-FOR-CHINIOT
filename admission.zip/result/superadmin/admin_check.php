<?php
session_start();
require_once '../db.php';

// Check if the user is logged in, has the correct role, AND has the required session data
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'superadmin')) {
    // If not, destroy the session and redirect to the login page
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}

// Check for required session data (to avoid 'Undefined array key' warnings)
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_name'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}

// Store user info in a variable for easy use on other pages
$logged_in_user_id = $_SESSION['user_id'];
$logged_in_user_name = $_SESSION['user_name']; // <--- FIX: Access user_name
