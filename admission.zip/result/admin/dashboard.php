<?php
$pageTitle = "Dashboard";
include 'header_teacher.php';

// Fetch Assigned Classes
$sql = "SELECT ta.assignment_id, c.class_id, c.class_name, s.subject_id, s.subject_name 
        FROM teacher_assignments ta 
        JOIN classes c ON ta.class_id = c.class_id 
        JOIN subjects s ON ta.subject_id = s.subject_id 
        WHERE ta.teacher_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$res = $stmt->get_result();
?>

<div class="card" style="border-left: 5px solid #ffc107;">
    <h3 style="margin-top:0;">Overview</h3>
    <p style="color:#666;">Welcome to the teacher's portal. Select a class below to manage marks and attendance.</p>
</div>

<h3 style="color:#333; margin-bottom:15px;">My Assigned Classes</h3>
<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px;">
    <?php if ($res->num_rows > 0):
        while ($row = $res->fetch_assoc()): ?>
            <div class="card">
                <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                    <h2 style="margin:0; color:#2c3e50;"><?php echo htmlspecialchars($row['class_name']); ?></h2>
                    <i class="fas fa-book" style="font-size:24px; color:#ddd;"></i>
                </div>
                <p style="color:#7f8c8d; margin-bottom:20px;">Subject: <strong><?php echo htmlspecialchars($row['subject_name']); ?></strong></p>

                <div style="display:flex; gap:10px;">
                    <a href="enter_marks.php?class_id=<?php echo $row['class_id']; ?>&subject_id=<?php echo $row['subject_id']; ?>" class="btn-primary" style="flex:1; text-align:center;">
                        <i class="fas fa-pen"></i> Marks
                    </a>
                    <a href="mark_attendance.php?class_id=<?php echo $row['class_id']; ?>" class="btn-warning" style="flex:1; text-align:center;">
                        <i class="fas fa-check"></i> Attd.
                    </a>
                </div>
            </div>
        <?php endwhile;
    else: ?>
        <div class="card" style="grid-column:1/-1; text-align:center;">
            <p style="color:#666;">No classes assigned. Please contact the Super Admin to assign subjects.</p>
        </div>
    <?php endif; ?>
</div>
</div>
</div>
</body>

</html>