<?php
include 'admin_check.php'; // --- SECURITY FIRST ---

// --- Get count of unread contact messages ---
$contact_msg_count_result = $conn->query("SELECT COUNT(*) as count FROM contact_messages WHERE is_read = 0");
$contact_msg_count = $contact_msg_count_result->fetch_assoc()['count'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Front Desk Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
        }

        .header {
            background: #004a99;
            /* Blue */
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 20px;
        }

        .grid-item {
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            padding: 25px;
            text-decoration: none;
            color: #333;
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
            /* For the badge */
        }

        .grid-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 74, 153, 0.1);
            color: #004a99;
        }

        .badge {
            position: absolute;
            top: -10px;
            right: -10px;
            background: #dc3545;
            /* Red */
            color: white;
            border-radius: 50%;
            width: 28px;
            height: 28px;
            line-height: 28px;
            font-size: 14px;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Front Desk Dashboard</h1>
        <span>Welcome, <?php echo htmlspecialchars($logged_in_user_name); ?></span>
        <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <div class="grid-container">
            <a href="manage_applicants.php" class="grid-item">
                Manage Applicants
            </a>

            <a href="manage_fees.php" class="grid-item">
                Manage Student Fees
            </a>

            <a href="view_contact_messages.php" class="grid-item">
                <?php if ($contact_msg_count > 0): ?>
                    <span class="badge"><?php echo $contact_msg_count; ?></span>
                <?php endif; ?>
                Contact Messages
            </a>

            <a href="view_admin_messages.php" class="grid-item">
                Admin Messages
            </a>
        </div>
    </div>
</body>

</html>