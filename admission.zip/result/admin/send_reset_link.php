<?php
// We need the database connection from the parent folder
include '../db.php';

// We need a library to send email. 
// You MUST install this using 'composer require phpmailer/phpmailer'
// For this demo, we will just *display* the link instead of emailing it.
// use PHPMailer\PHPMailer\PHPMailer;
// use PHPMailer\PHPMailer\Exception;
// require '../vendor/autoload.php'; // Path to PHPMailer's autoload

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    // Find the teacher by email
    $stmt = $conn->prepare("SELECT * FROM teachers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $teacher = $result->fetch_assoc();

        // --- 1. Generate Secure Token ---
        $token = bin2hex(random_bytes(32));

        // --- 2. Set Expiration Time (e.g., 1 hour from now) ---
        $expires = date("Y-m-d H:i:s", time() + 3600); // 3600 seconds = 1 hour

        // --- 3. Save Token to Database ---
        $stmt_update = $conn->prepare("UPDATE teachers SET reset_token = ?, reset_expires = ? WHERE email = ?");
        $stmt_update->bind_param("sss", $token, $expires, $email);
        $stmt_update->execute();

        // --- 4. Send the Email ---

        // ##################################################################
        // ##  THIS IS THE CORRECTED LINE:                                ##
        // ##################################################################
        $reset_link = "http://localhost/result/admin/reset_password.php?token=" . $token;


        /*
        // --- REAL EMAIL CODE (using PHPMailer) ---
        // $mail = new PHPMailer(true);
        // try {
        //     $mail->isSMTP();
        //     $mail->Host       = 'smtp.yourmailserver.com';
        //     $mail->SMTPAuth   = true;
        //     $mail->Username   = 'your-email@example.com';
        //     $mail->Password   = 'your-email-password';
        //     $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        //     $mail->Port       = 587;
        // 
        //     $mail->setFrom('no-reply@chiniotschool.com', 'Chiniot School Admin');
        //     $mail->addAddress($teacher['email'], $teacher['full_name']);
        // 
        //     $mail->isHTML(true);
        //     $mail->Subject = 'Password Reset Request';
        //     $mail->Body    = "Hello,<br><br>Please click the link below to reset your password:<br>"
        //                    . "<a href='$reset_link'>$reset_link</a><br><br>"
        //                    . "This link is valid for 1 hour.";
        // 
        //     $mail->send();
        // } catch (Exception $e) {
        //     // Handle mail error
        // }
        */

        // --- DEMO: Show the link instead of emailing ---
        echo "<div style='font-family: Arial; padding: 20px; border: 2px solid #006400; background: #f4f4f4;'>";
        echo "<h2>Email Sending Simulated</h2>";
        echo "<p>In a real application, this link would be emailed to <strong>" . htmlspecialchars($email) . "</strong>.</p>";
        echo "<p><strong>Click this link to continue:</strong></p>";
        echo "<a href='$reset_link' style='font-size: 16px; color: #006400;'>$reset_link</a>";
        echo "</div>";
        exit(); // Stop here for the demo
    }

    // Even if the email doesn't exist, we show a success message
    // This prevents attackers from guessing which emails are registered.
    header("Location: forgot_password.php?status=success");
    exit();
}
// If not a POST request, redirect to forgot password page