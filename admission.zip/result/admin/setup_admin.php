<?php
// Include your database connection
require_once '../db.php';

// 1. Create the 'admin' table if it doesn't exist
$sql_create_table = "CREATE TABLE IF NOT EXISTS `admin` (
    `admin_id` int(11) NOT NULL AUTO_INCREMENT,
    `username` varchar(50) NOT NULL UNIQUE,
    `password` varchar(255) NOT NULL,
    PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($conn->query($sql_create_table) === TRUE) {
    echo "<h3>Table 'admin' checked/created successfully.</h3>";
} else {
    die("Error creating table: " . $conn->error);
}

// 2. Check if an admin user exists
$check_user = "SELECT * FROM admin LIMIT 1";
$result = $conn->query($check_user);

if ($result->num_rows == 0) {
    // 3. Create a default admin user
    // Default Credentials -> Username: admin, Password: admin123
    $username = 'admin';
    $password = 'admin123';
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql_insert = "INSERT INTO admin (username, password) VALUES (?, ?)";

    if ($stmt = $conn->prepare($sql_insert)) {
        $stmt->bind_param("ss", $username, $hashed_password);
        if ($stmt->execute()) {
            echo "<p style='color:green; font-weight:bold;'>Success! Default Admin User Created.</p>";
            echo "<p>Username: <b>admin</b><br>Password: <b>admin123</b></p>";
        } else {
            echo "Error inserting user: " . $stmt->error;
        }
        $stmt->close();
    }
} else {
    echo "<p>Admin user already exists. You are ready to login.</p>";
}

echo "<br><a href='admin_login.php'>Go to Login Page</a>";
