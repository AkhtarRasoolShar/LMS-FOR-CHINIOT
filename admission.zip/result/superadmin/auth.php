<?php
session_start();
require '../db.php'; // Connect to the database

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    // --- 1. Prepare statement to find the user (Only Admin/Superadmin) ---
    // This checks the role explicitly in the database query.
    $stmt = $conn->prepare("SELECT teacher_id, password_hash, role, full_name FROM teachers WHERE username = ? AND (role = 'admin' OR role = 'superadmin')");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        // --- 2. Verify the BCRYPT hashed password ---
        if (password_verify($password, $user['password_hash'])) {

            // Set standardized session variables
            $_SESSION['user_id'] = $user['teacher_id'];
            $_SESSION['username'] = $username;
            $_SESSION['user_name'] = $user['full_name']; // Standardized name key
            $_SESSION['role'] = $user['role'];

            // Redirect to the dashboard
            header("Location: dashboard.php");
            exit;
        }
    }

    // If login fails (user not found or wrong password)
    header("Location: index.php?error=1");
    exit;
} else {
    // Not a POST request
    header("Location: index.php");
    exit;
}
