<?php
// admit_card.php - Handles checking payment status and displaying the admit card.

include 'db.php';

$applicant = null;
$error = '';
$payment_pending = false;

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_no'])) {
    $form_no = $_POST['form_no'];

    // 1. Fetch Applicant details AND payment status
    $stmt = $conn->prepare("SELECT * FROM applicants WHERE form_no = ?");
    $stmt->bind_param("s", $form_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $data = $result->fetch_assoc();

        // 2. Check the Payment Status flag (1 = Paid, 0 = Pending)
        if ($data['payment_status'] == 1) {
            $applicant = $data; // Payment confirmed, show the card
        } else {
            $payment_pending = true;
            $applicant = null; // Payment pending, hide card details
        }
    } else {
        $error = "No application found for Form No. " . htmlspecialchars($form_no);
    }
}

// Include the header
include 'header.php';
?>

<div class="container">
    <img src="logo.png" alt="School Logo">
    <h2>Admit Card Portal</h2>

    <?php if ($error): ?>
        <p class="error-message"><?php echo $error; ?></p>
    <?php endif; ?>

    <!-- Custom Message when Payment is Pending -->
    <?php if ($payment_pending): ?>
        <div class="error-message payment-message" style="background-color: #ffe0b2; padding: 15px; border-radius: 4px; border: 1px solid #ffb300;">
            <p style="color: #003366; margin-top: 0;">
                **Action Required:** Your Admit Card cannot be downloaded yet.
                The school records show your **admission fee payment is pending**.
            </p>
            <p style="color: #555;">
                Please ensure the fee is paid using your Application Number.
                If you have paid, please contact the Administration for status update:
                <a href="../contact.php" style="color: #b30000; font-weight: bold;">Contact Help Center &rarr;</a>
            </p>
        </div>
    <?php endif; ?>

    <form action="admit_card.php" method="POST">
        <div class="form-group">
            <label for="form_no">Enter Your Form No. / Roll No:</label>
            <input type="text" id="form_no" name="form_no" placeholder="e.g., APP-12345ABC" required>
        </div>
        <button type="submit" style="background-color: #b30000;">Download Admit Card</button>
    </form>
</div>

<?php if ($applicant): ?>
    <style>
        /* Specific styles for the admit card print (Omitted for brevity) */
        .admit-card-container {
            width: 800px;
            margin: 30px auto;
            background: #fff;
            border: 2px solid #333;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        /* ... (Rest of CSS omitted for brevity) ... */

        @media print {
            body {
                background: #fff;
            }

            .container,
            .main-footer,
            .main-header {
                display: none !important;
            }

            .admit-card-container {
                margin: 0;
                box-shadow: none;
                border: none;
            }
        }
    </style>

    <div class="admit-card-container">
        <div class="admit-header">
            <img src="logo.png" alt="School Logo" class="logo">
            <h2>CHINIOT ISLAMIA PUBLIC SCHOOL & COLLEGE</h2>
            <h3>Plot no.ST-13/2-2A,Block-7, Gulshan-e-Iqbal</h3>
            <p>Main university Road, Karachi-75300 Tel: 34815341</p>
            <h4>Entrance Test Session 2025-2026 - ADMIT CARD</h4>
        </div>

        <div class="admit-body">
            <div>
                <div class="info-grid">
                    <div class="info-item">
                        <label>Roll No.</label>
                        <span><?php echo htmlspecialchars($applicant['form_no']); ?></span>
                    </div>
                    <div class="info-item">
                        <label>Form No.</label>
                        <span><?php echo htmlspecialchars($applicant['form_no']); ?></span>
                    </div>
                    <div class="info-item full-width">
                        <label>Student's Name</label>
                        <span><?php echo htmlspecialchars($applicant['student_name']); ?></span>
                    </div>
                    <div class="info-item full-width">
                        <label>Father's/Guardian's Name</label>
                        <span><?php echo htmlspecialchars($applicant['father_name']); ?></span>
                    </div>
                    <div class="info-item">
                        <label>Class</label>
                        <span><?php echo htmlspecialchars($applicant['applying_for_class']); ?></span>
                    </div>
                    <div class="info-item">
                        <label>Syllabus</label>
                        <span><a href="<?php echo htmlspecialchars($applicant['syllabus_url']); ?>" target="_blank">Click here for Syllabus</a></span>
                    </div>
                    <div class="info-item">
                        <label>Test Date</label>
                        <span><?php echo date('d-M-Y', strtotime($applicant['test_date'])); ?></span>
                    </div>
                    <div class="info-item">
                        <label>Test Time</label>
                        <span><?php echo date('h:i A', strtotime($applicant['test_time'])); ?></span>
                    </div>
                    <div class="info-item full-width">
                        <label>Address</label>
                        <span><?php echo htmlspecialchars($applicant['address']); ?></span>
                    </div>
                    <div class="info-item full-width">
                        <label>Phone No.</label>
                        <span><?php echo htmlspecialchars($applicant['phone_no']); ?></span>
                    </div>
                </div>
            </div>

            <div>
                <!-- Show uploaded photo -->
                <?php
                $photo_src = !empty($applicant['photo_filename']) ? "uploads/" . htmlspecialchars($applicant['photo_filename']) : 'https://placehold.co/160x180/003366/FFFFFF?text=Photo';
                ?>
                <img src="<?php echo $photo_src; ?>"
                    alt="Applicant Photo"
                    class="admit-photo"
                    onerror="this.onerror=null; this.src='https://placehold.co/160x180/003366/FFFFFF?text=Photo'">
            </div>
        </div>

        <div class="instructions">
            <h3>INSTRUCTIONS FOR CANDIDATE</h3>
            <ol>
                <li>Without admit card no candidate will be allowed to appear in the test.</li>
                <li>The candidate should bring pen, pencil, eraser etc.</li>
                <li>Use ink to write in answer sheet.</li>
                <li>No candidate will be allowed to enter examination hall 30 minutes after the start of the admission test.</li>
                <li>No candidate is allowed to carry home the question paper or the answer copy.</li>
            </ol>
        </div>
    </div>
<?php endif; ?>

<?php
// Finally, include the footer
include 'footer.php';
?>