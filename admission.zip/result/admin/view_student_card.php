<?php
session_start();
require '../db.php';

if (!isset($_SESSION['teacher_id'])) die("Access Denied");

$student_id = (int)$_GET['student_id'];
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// 1. Fetch Student
$student = $conn->query("SELECT * FROM students WHERE student_id = $student_id")->fetch_assoc();

// 2. Fetch All Class Subjects (Crucial Step for showing all subjects)
$class_search = str_replace("Class ", "", $student['class']);
$class_id_res = $conn->query("SELECT class_id FROM classes WHERE class_name LIKE '%$class_search%' LIMIT 1");
$class_id = ($class_id_res->num_rows > 0) ? $class_id_res->fetch_assoc()['class_id'] : 0;

$subjects = [];
if ($class_id > 0) {
    // Fetch ALL subjects linked to this class
    $sub_res = $conn->query("SELECT s.subject_id, s.subject_name FROM class_subjects cs JOIN subjects s ON cs.subject_id=s.subject_id WHERE cs.class_id=$class_id ORDER BY s.subject_id");
    while ($r = $sub_res->fetch_assoc()) $subjects[$r['subject_id']] = $r['subject_name'];
}

// 3. Fetch Marks
$terms = ['1st QUARTERLY', 'MID TERM', '2nd QUARTERLY', 'FINAL TERM'];
$res_map = [];

foreach ($terms as $t) {
    // Fetch marks for this term
    $r = $conn->query("SELECT subject_id, marks_obtained, total_marks FROM results WHERE student_id=$student_id AND term_name='$t' AND session_year='$year'");
    while ($row = $r->fetch_assoc()) {
        $res_map[$row['subject_id']][$t] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Result Card</title>
    <style>
        /* Use styles from previous responses for PDF layout */
        body {
            font-family: 'Times New Roman', serif;
            background: #eee;
            margin: 0;
            padding: 20px;
        }

        .card {
            max-width: 1000px;
            background: white;
            margin: 0 auto;
            padding: 40px;
            box-shadow: 0 0 10px #ccc;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border: 2px solid #000;
            margin-bottom: 20px;
            font-family: Arial, sans-serif;
            font-size: 12px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 6px;
            text-align: center;
        }

        th {
            background: #f0f0f0;
            font-weight: bold;
            text-transform: uppercase;
        }

        .sub-col {
            text-align: left;
            font-weight: bold;
            width: 25%;
        }

        @media print {
            body {
                background: white;
            }

            .card {
                box-shadow: none;
                margin: 0;
            }

            .no-print {
                display: none;
            }
        }
    </style>
</head>

<body>

    <div class="no-print" style="text-align:center; margin-bottom:20px;">
        <button onclick="window.print()" style="padding:10px 20px; background:#004a99; color:white; cursor:pointer;">Print Card</button>
    </div>

    <div class="card">
        <h2 style="text-align:center; color:#004a99; border-bottom:2px double #004a99; padding-bottom:10px;">CHINIOT ISLAMIA PUBLIC SCHOOL</h2>
        <h3 style="text-align:center;">RESULT CARD (SESSION <?php echo $year; ?>)</h3>

        <div style="border:2px solid #000; padding:10px; margin-bottom:20px; display:grid; grid-template-columns:1fr 1fr; gap:10px; font-weight:bold; font-family:Arial;">
            <div>Name: <span style="font-weight:normal;"><?php echo $student['name']; ?></span></div>
            <div>Father: <span style="font-weight:normal;"><?php echo $student['f_name']; ?></span></div>
            <div>Class: <span style="font-weight:normal;"><?php echo $student['class']; ?></span></div>
            <div>Roll No: <span style="font-weight:normal;"><?php echo $student['student_id']; ?></span></div>
        </div>

        <table>
            <thead>
                <tr>
                    <th rowspan="2" class="sub-col">SUBJECTS</th>
                    <?php foreach ($terms as $t): ?><th colspan="2"><?php echo $t; ?></th><?php endforeach; ?>
                </tr>
                <tr><?php foreach ($terms as $t): ?><th>M</th>
                        <th>%</th><?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php $totals = [];
                foreach ($subjects as $sid => $sname): ?>
                    <tr>
                        <td class="sub-col"><?php echo htmlspecialchars($sname); ?></td>
                        <?php foreach ($terms as $term):
                            $d = $res_map[$sid][$term] ?? [];
                            $m = $d['marks_obtained'] ?? '-';
                            $t = $d['total_marks'] ?? 0;
                            $p = ($t > 0 && is_numeric($m)) ? round(($m / $t) * 100) . '%' : '-';
                            if (is_numeric($m)) $totals[$term] = ($totals[$term] ?? 0) + $m;
                        ?>
                            <td><?php echo $m; ?></td>
                            <td><?php echo $p; ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
                <tr style="background:#f9f9f9; font-weight:bold;">
                    <td class="sub-col" style="text-align:right;">TOTAL</td>
                    <?php foreach ($terms as $t): ?><td><?php echo $totals[$t] ?? '-'; ?></td>
                        <td></td><?php endforeach; ?>
                </tr>
            </tbody>
        </table>

    </div>
</body>

</html>