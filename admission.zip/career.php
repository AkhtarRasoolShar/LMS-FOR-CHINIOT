<?php
$pageTitle = "Career";
include 'header.php';
?>

<div class="container-padded">
    <h2>Career Opportunities</h2>

    <p>Thank you for your interest in a career at Chiniot Islamia Public School & College. We are always looking for passionate and qualified individuals to join our team.</p>

    <h3>Current Openings</h3>
    <p>There are no active openings at this time. Please check back later.</p>

    <h3>How to Apply</h3>
    <p>
        To be considered for future positions, you may email your resume (CV) and a cover letter to:
        <br>
        <strong>Email: <a href="mailto:jobs@chiniotschool.edu.pk">jobs@chiniotschool.edu.pk</a></strong>
    </p>
    <p>
        Please specify the role or department you are interested in (e.g., "Senior School English Teacher," "Admin Staff," "Science Lab Assistant") in your email subject line.
    </p>
    <p>
        We thank all applicants for their interest; however, only those selected for an interview will be contacted.
    </p>
</div>

<?php include 'footer.php'; ?>