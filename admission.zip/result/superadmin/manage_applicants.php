<?php
include 'admin_check.php'; // Includes session and db connection (../db.php)

// Only Super Admins can access this page
if ($_SESSION['role'] !== 'admin') {
    die("Access Denied. You must be a Super Admin.");
}

$message = '';

// Handle Delete Action
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id_to_delete = (int)$_GET['id'];

    // Optional: Delete photo file from server
    $photo_stmt = $conn->prepare("SELECT photo_filename FROM applicants WHERE applicant_id = ?");
    $photo_stmt->bind_param("i", $id_to_delete);
    $photo_stmt->execute();
    $photo_row = $photo_stmt->get_result()->fetch_assoc();
    if ($photo_row && !empty($photo_row['photo_filename'])) {
        $filepath = '../uploads/' . $photo_row['photo_filename'];
        if (file_exists($filepath)) {
            @unlink($filepath); // Suppress errors if file not found
        }
    }
    $photo_stmt->close();

    // Delete the applicant record
    $delete_stmt = $conn->prepare("DELETE FROM applicants WHERE applicant_id = ?");
    $delete_stmt->bind_param("i", $id_to_delete);
    if ($delete_stmt->execute()) {
        $message = "Applicant deleted successfully.";
    } else {
        $message = "Error deleting applicant.";
    }
    $delete_stmt->close();
}

// Fetch all applicants
$applicants_result = $conn->query("SELECT * FROM applicants ORDER BY applicant_id DESC");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Applicants</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #004d40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th,
        .data-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .data-table th {
            background: #f2f2f2;
        }

        .data-table tr:nth-child(even) {
            background: #f9f9f9;
        }

        .action-links a {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
            margin-right: 5px;
        }

        .action-view {
            background-color: #007bff;
            color: white;
        }

        .action-edit {
            background-color: #ffc107;
            color: black;
        }

        .action-delete {
            background-color: #dc3545;
            color: white;
        }

        .paid {
            color: green;
            font-weight: bold;
        }

        .pending {
            color: red;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Manage Applicants</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Form No</th>
                    <th>Student Name</th>
                    <th>Father's Name</th>
                    <th>Applying for Class</th>
                    <th>Payment</th>
                    <th>Test Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($applicants_result->num_rows > 0): ?>
                    <?php while ($row = $applicants_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['form_no']); ?></td>
                            <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['father_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['applying_for_class']); ?></td>
                            <td>
                                <span class="<?php echo $row['payment_status'] ? 'paid' : 'pending'; ?>">
                                    <?php echo $row['payment_status'] ? 'Paid' : 'Pending'; ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($row['test_date'] ?? 'N/A'); ?></td>
                            <td class="action-links">
                                <a href="view_applicant_details.php?id=<?php echo $row['applicant_id']; ?>" class="action-view">View</a>
                                <a href="edit_applicant.php?id=<?php echo $row['applicant_id']; ?>" class="action-edit">Edit</a>
                                <a href="manage_applicants.php?action=delete&id=<?php echo $row['applicant_id']; ?>" class="action-delete" onclick="return confirm('Are you sure you want to delete this applicant?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No applicants found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html>