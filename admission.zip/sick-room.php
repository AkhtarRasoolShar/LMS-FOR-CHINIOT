<?php
$pageTitle = "Sick Room";
include 'header.php';
?>

<div class="container">
    <h2>Sick Room</h2>

    <p>The health and well-being of our students is a top priority. Our campus is equipped with a clean and well-maintained sick room, staffed with a qualified professional to provide first-aid and care for any student who feels unwell during school hours.</p>



</div>

<?php include 'footer.php'; ?>