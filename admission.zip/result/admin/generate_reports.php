<?php
$pageTitle = "Generate Reports";
include 'header_teacher.php';

// 1. Fetch Teacher's Assigned Classes
$teacher_id = $_SESSION['teacher_id'];
$sql = "SELECT DISTINCT c.class_id, c.class_name 
        FROM teacher_assignments ta 
        JOIN classes c ON ta.class_id = c.class_id 
        WHERE ta.teacher_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$classes = $stmt->get_result();

// 2. Handle Selection
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');
?>

<div class="card">
    <h3 style="margin-top:0; color:#004a99;">Report Card Generator</h3>
    <p style="color:#666;">Select a class to generate result cards.</p>

    <form method="GET" style="background:#f9f9f9; padding:20px; border-radius:8px; border:1px solid #eee; display:flex; gap:15px; align-items:end; margin-bottom:20px;">
        <div style="flex:1;">
            <label style="font-weight:bold; display:block; margin-bottom:5px;">Select Class</label>
            <select name="class_id" class="form-control" style="width:100%; padding:10px;">
                <option value="">-- Choose Class --</option>
                <?php while ($c = $classes->fetch_assoc()): ?>
                    <option value="<?php echo $c['class_id']; ?>" <?php echo ($c['class_id'] == $class_id) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($c['class_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div style="flex:1;">
            <label style="font-weight:bold; display:block; margin-bottom:5px;">Session Year</label>
            <select name="year" class="form-control" style="width:100%; padding:10px;">
                <?php for ($y = date('Y'); $y >= 2023; $y--) echo "<option value='$y' " . ($y == $year ? 'selected' : '') . ">$y</option>"; ?>
            </select>
        </div>
        <button type="submit" class="btn-primary" style="padding:12px 25px;">Load Students</button>
    </form>

    <?php if ($class_id > 0):
        // Get Class Name
        $c_res = $conn->query("SELECT class_name FROM classes WHERE class_id=$class_id");
        if ($c_res->num_rows == 0) {
            echo "<p class='alert alert-danger'>Invalid Class</p>";
        } else {
            $c_name = $c_res->fetch_assoc()['class_name'];
            // Smart Search for Students
            $search_name = str_replace("Class ", "", $c_name);
            $students = $conn->query("SELECT * FROM students WHERE class LIKE '%$search_name%' ORDER BY name ASC");
    ?>

            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; padding-bottom:10px; border-bottom:1px solid #eee;">
                <h4 style="margin:0; color:#333;">Student List (<?php echo $students->num_rows; ?>)</h4>

                <a href="print_bulk_cards.php?class_id=<?php echo $class_id; ?>&year=<?php echo $year; ?>" target="_blank" class="btn-warning" style="color:#333;">
                    <i class="fas fa-print"></i> Print All Cards
                </a>
            </div>

            <div class="search-box" style="margin-bottom:15px;">
                <i class="fas fa-search search-icon"></i>
                <input type="text" id="searchInput" onkeyup="filterTable()" class="search-input" placeholder="Filter students...">
            </div>

            <table style="width:100%; border-collapse:collapse;">
                <thead>
                    <tr style="background:#f8f9fa; text-align:left; border-bottom:2px solid #ddd;">
                        <th style="padding:12px;">Roll No</th>
                        <th style="padding:12px;">Student Name</th>
                        <th style="padding:12px;">Father Name</th>
                        <th style="padding:12px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($s = $students->fetch_assoc()): ?>
                        <tr style="border-bottom:1px solid #eee;">
                            <td style="padding:12px;"><?php echo $s['student_id']; ?></td>
                            <td style="padding:12px; font-weight:bold; color:#004a99;"><?php echo htmlspecialchars($s['name']); ?></td>
                            <td style="padding:12px; color:#666;"><?php echo htmlspecialchars($s['f_name']); ?></td>
                            <td style="padding:12px;">
                                <a href="view_student_card.php?student_id=<?php echo $s['student_id']; ?>&year=<?php echo $year; ?>" target="_blank" class="btn-primary" style="padding:6px 12px; font-size:13px;">
                                    <i class="fas fa-eye"></i> View Card
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

    <?php }
    endif; ?>
</div>

<?php include '../../footer.php'; ?>