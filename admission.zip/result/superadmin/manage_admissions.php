<?php
include 'admin_check.php'; // Includes session and db connection (../db.php)

// Only Super Admins can access this page
if ($_SESSION['role'] !== 'admin') {
    die("Access Denied. You must be a Super Admin.");
}

$message = '';

// --- Handle Form Submission (POST) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['toggle_admissions'])) {
        // Get the current status
        $current_status_row = $conn->query("SELECT setting_value FROM system_settings WHERE setting_name = 'admissions_status'")->fetch_assoc();
        $current_status = $current_status_row['setting_value'];

        // Toggle the status
        $new_status = ($current_status == 'open') ? 'closed' : 'open';

        // Update the database
        $stmt = $conn->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_name = 'admissions_status'");
        $stmt->bind_param("s", $new_status);
        $stmt->execute();
        $stmt->close();

        $message = "Admissions are now " . strtoupper($new_status) . "!";
    }
}

// --- Fetch Current Status (GET) ---
$status_row = $conn->query("SELECT setting_value FROM system_settings WHERE setting_name = 'admissions_status'")->fetch_assoc();
$admissions_status = $status_row['setting_value'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Admissions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #004d40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 800px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .status-box {
            padding: 30px;
            border-radius: 8px;
            text-align: center;
        }

        .status-open {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }

        .status-closed {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }

        .status-box p {
            margin: 0 0 20px 0;
            font-size: 1.2em;
        }

        .status-box strong {
            font-size: 1.5em;
            text-transform: uppercase;
        }

        .status-box button {
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .btn-open {
            background: #28a745;
            color: white;
        }

        .btn-close {
            background: #dc3545;
            color: white;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Manage Admissions</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>

        <form action="manage_admissions.php" method="POST">
            <?php if ($admissions_status == 'open'): ?>
                <div class="status-box status-open">
                    <p>Admissions are currently:</p>
                    <strong>OPEN</strong>
                    <p style="margin-top: 20px; margin-bottom: 0;">Click to close admissions. This will hide the form from the public.</p>
                </div>
                <button type="submit" name="toggle_admissions" class="btn-close" style="width:100%; margin-top: 20px;">
                    CLOSE ADMISSIONS
                </button>
            <?php else: ?>
                <div class="status-box status-closed">
                    <p>Admissions are currently:</p>
                    <strong>CLOSED</strong>
                    <p style="margin-top: 20px; margin-bottom: 0;">Click to open admissions. This will make the form visible to the public.</p>
                </div>
                <button type="submit" name="toggle_admissions" class="btn-open" style="width:100%; margin-top: 20px;">
                    OPEN ADMISSIONS
                </button>
            <?php endif; ?>
        </form>
    </div>
</body>

</html>