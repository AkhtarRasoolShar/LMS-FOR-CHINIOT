<?php
session_start();
$pageTitle = "Student Results"; // This will set the "active" class in your header
// We must go UP one directory to include the main site header
include '../header.php';

$error_message = '';
$student_details = null;

if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'not_found':
            $error_message = 'Student ID not found. Please check and try again.';
            break;
        case 'fee_unpaid':
            // Check if the student details were passed for verification
            if (isset($_SESSION['unpaid_student_details'])) {
                $student_details = $_SESSION['unpaid_student_details'];
                // Unset the session variable so it doesn't show again on refresh
                unset($_SESSION['unpaid_student_details']);
            }
            $error_message = 'Your result is locked. Please pay the Fess first your fess is not paid.';
            break;
        case 'session_expired':
            $error_message = 'Your session has expired. Please log in again.';
            break;
        default:
            $error_message = 'An unknown error occurred. Please try again.';
            break;
    }
}
?>

<style>
    /* This uses the .container-padded class from header.php */
    .login-container {
        max-width: 500px;
        /* Narrower for a login form */
        margin: 30px auto;
    }

    .login-form h1 {
        color: #004a99;
        /* Blue */
        margin-top: 0;
        margin-bottom: 20px;
        font-size: 22px;
        text-align: center;
    }

    .form-group {
        margin-bottom: 15px;
    }

    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
        color: #555;
    }

    .form-group input,
    .form-group select {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    .login-btn {
        background-color: #004a99;
        /* Blue */
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
        font-weight: bold;
        width: 100%;
        margin-top: 10px;
    }

    .login-btn:hover {
        background-color: #003b7a;
    }

    .error-message {
        color: #dc3545;
        background: #f8d7da;
        border: 1px solid #f5c6cb;
        padding: 10px;
        border-radius: 4px;
        margin-bottom: 15px;
        font-weight: bold;
        text-align: center;
    }

    /* --- NEW Verification Table Styles --- */
    .verification-box {
        background: #fff8e1;
        border: 1px solid #fdb813;
        border-radius: 4px;
        padding: 20px;
        margin-bottom: 20px;
    }

    .verification-box h3 {
        color: #004a99;
        margin-top: 0;
        text-align: center;
    }

    .verification-table {
        width: 100%;
    }

    .verification-table td {
        padding: 8px 0;
        font-size: 16px;
    }

    .verification-table td:first-child {
        font-weight: bold;
        color: #555;
        width: 120px;
    }
</style>

<div class="container-padded login-container">
    <form class="login-form" action="student_router.php" method="POST">
        <img src="/chiniot/logos.png" alt="School Logo" style="width: 80px; margin: 0 auto 15px auto; display: block;">
        <h1>Student Result Portal</h1>

        <?php if ($error_message): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>

        <?php if ($student_details): ?>
            <div class="verification-box">
                <h3>Student Details for Verification</h3>
                <table class="verification-table">
                    <tr>
                        <td>Student ID:</td>
                        <td><?php echo htmlspecialchars($student_details['student_id']); ?></td>
                    </tr>
                    <tr>
                        <td>Name:</td>
                        <td><?php echo htmlspecialchars($student_details['name']); ?></td>
                    </tr>
                    <tr>
                        <td>Father's Name:</td>
                        <td><?php echo htmlspecialchars($student_details['f_name']); ?></td>
                    </tr>
                    <tr>
                        <td>Class:</td>
                        <td><?php echo htmlspecialchars($student_details['class']); ?></td>
                    </tr>
                </table>
            </div>
        <?php endif; ?>
        <div class="form-group">
            <label for="student_id">Student ID</label>
            <input type="text" id="student_id" name="student_id" required>
        </div>
        <div class="form-group">
            <label for="term_name">Select Term</label>
            <select id="term_name" name="term_name" required>
                <option value="">-- Select a Term --</option>
                <option value="1st QUARTERLY">1st QUARTERLY</option>
                <option value="MID TERM">MID TERM (1st Term)</option>
                <option value="2nd QUARTERLY">2nd QUARTERLY</option>
                <option value="FINAL TERM">FINAL TERM (2nd Term)</option>
            </select>
        </div>
        <button type="submit" class="login-btn">View Result</button>
    </form>
</div>

<?php
// We must go UP one directory to include the main site footer
include '../footer.php';
?>