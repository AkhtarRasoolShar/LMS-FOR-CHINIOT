<?php
// ajax_get_students.php
// This file is called by JavaScript to fetch students for a class.

include 'admin_check.php'; // Includes session and db connection

// NEW: Get the class ID from the URL
$class_id = (int)$_GET['class_id'] ?? 0;
$logged_in_teacher_id = $_SESSION['teacher_id'];

if ($class_id === 0) {
    echo json_encode([]);
    exit;
}

// 1. Get the actual class_name from the class_id (used to query the 'students' table)
$class_name_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
$class_name_stmt->bind_param("i", $class_id);
$class_name_stmt->execute();
// We use fetch_assoc directly here since we only expect one row
$class_name = $class_name_stmt->get_result()->fetch_assoc()['class_name'] ?? '';
$class_name_stmt->close();

$students = [];

if (!empty($class_name)) {
    // 2. Security Check: Verify that this teacher is assigned to this class_id
    $check_stmt = $conn->prepare("
        SELECT assignment_id FROM teacher_assignments 
        WHERE teacher_id = ? AND class_id = ?
    ");
    $check_stmt->bind_param("ii", $logged_in_teacher_id, $class_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        // 3. Security Check Passed: Fetch all students in this class using the class_name
        $stmt = $conn->prepare("
            SELECT student_id, name 
            FROM students 
            WHERE class = ? 
            ORDER BY name
        ");
        $stmt->bind_param("s", $class_name);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $students[] = $row;
        }
        $stmt->close();
    }
}

// Set the header to return JSON
header('Content-Type: application/json');
// Send the list of students back to the JavaScript
echo json_encode($students);
exit();
