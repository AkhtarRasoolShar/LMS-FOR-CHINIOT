<?php
include 'admin_check.php';

// Only Super Admins can access this page
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'superadmin') {
    die("Access Denied.");
}

$portalTitle = "Manage Approved Students";
include 'portal_header.php';

$message = '';
$error = '';

// --- Handle Status Toggling (Lock/Unlock) ---
if (isset($_GET['action']) && isset($_GET['id'])) {
    $applicant_id = (int)$_GET['id'];
    $action = $_GET['action'];

    // Toggle the lock status on the applicant record
    // is_locked = 1 is Locked, is_locked = 0 is Unlocked/Ready
    $new_lock_status = ($action == 'lock') ? 1 : 0;

    $stmt = $conn->prepare("UPDATE applicants SET is_locked = ? WHERE applicant_id = ?");
    $stmt->bind_param("ii", $new_lock_status, $applicant_id);
    if ($stmt->execute()) {
        $message = "Applicant ID {$applicant_id} status updated to " . ($new_lock_status ? 'LOCKED' : 'UNLOCKED/READY') . ".";
    } else {
        $error = "Error updating lock status.";
    }
    $stmt->close();
}

// --- Fetch Applicants who are APPROVED (Finalized) ---
$applicants_result = $conn->query("
    SELECT applicant_id, form_no, student_name, applying_for_class, student_sn_number, is_locked
    FROM applicants
    WHERE approval_status = 'Approved' 
    ORDER BY student_sn_number ASC
");

?>
<style>
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .data-table th,
    .data-table td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
        font-size: 14px;
    }

    .data-table th {
        background: #f2f2f2;
    }

    .action-links a {
        text-decoration: none;
        padding: 5px 10px;
        border-radius: 3px;
        font-size: 13px;
        margin-right: 5px;
    }

    .status-locked {
        background-color: #dc3545;
        color: white;
    }

    .status-unlocked {
        background-color: #007bff;
        color: white;
    }

    .action-lock {
        background-color: #004d40;
        color: white;
    }

    /* Teal */
    .action-unlock {
        background-color: #ff9800;
        color: white;
    }

    /* Orange */
</style>

<div class="container">
    <?php if ($message && !$error): ?>
        <p class="message enrollment-success"><?php echo $message; ?></p>
    <?php endif; ?>
    <?php if ($error): ?>
        <p class="message error"><?php echo $error; ?></p>
    <?php endif; ?>

    <h2>Finalized Students (Approved & Enrolled)</h2>
    <p>These students have been approved and assigned a Student S.N. No. The lock status is for internal administrative control before final student roll enrollment.</p>

    <table class="data-table">
        <thead>
            <tr>
                <th>S.N. No.</th>
                <th>Form No</th>
                <th>Student Name</th>
                <th>Applying for Class</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($applicants_result->num_rows > 0): ?>
                <?php while ($row = $applicants_result->fetch_assoc()): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($row['student_sn_number']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['form_no']); ?></td>
                        <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['applying_for_class']); ?></td>
                        <td>
                            <?php if ($row['is_locked'] == 1): ?>
                                <span class="status-locked">LOCKED</span>
                            <?php else: ?>
                                <span class="status-unlocked">READY</span>
                            <?php endif; ?>
                        </td>
                        <td class="action-links">
                            <a href="view_applicant_details.php?id=<?php echo $row['applicant_id']; ?>" class="action-view" target="_blank">View Details</a>

                            <?php if ($row['is_locked'] == 1): ?>
                                <a href="?action=unlock&id=<?php echo $row['applicant_id']; ?>" class="action-link action-unlock" onclick="return confirm('Unlock this student?');">Unlock</a>
                            <?php else: ?>
                                <a href="?action=lock&id=<?php echo $row['applicant_id']; ?>" class="action-link action-lock" onclick="return confirm('Lock this student?');">Lock Data</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No students have been fully approved yet.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'portal_footer.php'; ?>