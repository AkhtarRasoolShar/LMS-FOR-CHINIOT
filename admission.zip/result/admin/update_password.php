<?php
include '../db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $token = $_POST['token'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // 1. Check if passwords match
    if ($new_password !== $confirm_password) {
        die("Error: Passwords do not match. Please go back and try again.");
    }

    // 2. Check if token is still valid (as a final security check)
    $stmt = $conn->prepare("SELECT * FROM teachers WHERE reset_token = ? AND reset_expires > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // 3. Hash the new password
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

        // 4. Update the password and clear the token
        $stmt_update = $conn->prepare("UPDATE teachers SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE reset_token = ?");
        $stmt_update->bind_param("ss", $password_hash, $token);
        $stmt_update->execute();

        // 5. Redirect to login with a success message
        header("Location: admin_login.php?status=reset_success");
        exit();
    } else {
        // Token is invalid or expired
        header("Location: forgot_password.php?status=invalid");
        exit();
    }
}
