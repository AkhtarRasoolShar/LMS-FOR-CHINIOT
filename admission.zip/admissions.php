<?php
$pageTitle = "Admission Form";
include 'header.php';
require_once 'result/db.php'; // --- Use require_once and get DB connection ---

// --- Check admission status from database (NOW WITH ERROR CHECKING) ---
$admissions_status = 'closed'; // Default to closed
$sql = "SELECT setting_value FROM system_settings WHERE setting_name = 'admissions_status'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $status_row = $result->fetch_assoc();
    $admissions_status = $status_row['setting_value'];
} else {
    // This will happen if the table/row doesn't exist.
    // The page will safely default to 'closed'.
    error_log("Warning: 'system_settings' table or 'admissions_status' row not found. Defaulting to closed.");
}
$conn->close(); // Close the connection
?>

<style>
    /* --- ADMISSION HEADER --- */
    .admission-header {
        text-align: center;
        margin: 20px auto;
        padding: 0 20px;
        max-width: 900px;
    }

    .admission-header h2 {
        font-size: 18px;
        color: #555;
        margin: 0;
        font-weight: normal;
    }

    .admission-header h1 {
        font-size: 36px;
        color: #006400;
        margin: 5px 0 15px 0;
    }

    .admission-nav {
        background: #f8f9fa;
        border-bottom: 1px solid #ddd;
        border-top: 1px solid #ddd;
        text-align: center;
        margin-bottom: 30px;
    }

    .admission-nav ul {
        margin: 0;
        padding: 0;
        list-style: none;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
    }

    .admission-nav li {
        display: inline-block;
    }

    .admission-nav a {
        display: block;
        padding: 15px 20px;
        text-decoration: none;
        color: #006400;
        font-weight: bold;
        font-size: 16px;
        border-bottom: 3px solid transparent;
    }

    .admission-nav a:hover {
        background: #e9ecef;
    }

    .admission-nav a.active {
        border-bottom-color: #006400;
        color: #333;
        background: #e9ecef;
    }

    /* --- FORM STYLES --- */
    .admission-form {
        max-width: 900px;
        margin: 0 auto 30px auto;
        padding: 30px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }

    .admission-form h3 {
        color: #006400;
        border-bottom: 2px solid #f0f0f0;
        padding-bottom: 10px;
        margin-top: 30px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        font-weight: bold;
        margin-bottom: 8px;
        font-size: 14px;
    }

    .form-group label span {
        color: #dc3545;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .form-grid-3 {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
    }

    .form-grid-4 {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 15px;
        align-items: end;
    }

    .full-width {
        grid-column: 1 / -1;
    }

    .file-note {
        font-size: 12px;
        color: #555;
        margin-top: 5px;
    }

    .undertaking {
        background: #fdfdfd;
        border: 1px solid #eee;
        padding: 20px;
        border-radius: 5px;
        font-size: 14px;
        line-height: 1.6;
    }

    .undertaking ul {
        padding-left: 20px;
    }

    .checkbox-group {
        display: flex;
        align-items: center;
        margin-top: 20px;
    }

    .checkbox-group input {
        width: auto;
        margin-right: 10px;
    }

    .submit-btn {
        display: block;
        width: 100%;
        padding: 12px;
        background: #006400;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 18px;
        font-weight: bold;
        margin-top: 30px;
    }

    /* --- THIS IS THE "CLOSED" NOTICE --- */
    .closed-notice {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
        padding: 20px;
        border-radius: 5px;
        text-align: center;
        font-size: 1.2em;
        font-weight: bold;
    }

    @media (max-width: 768px) {

        .form-grid,
        .form-grid-3,
        .form-grid-4 {
            grid-template-columns: 1fr;
        }

        .admission-nav ul {
            flex-direction: column;
        }

        .admission-nav a {
            border-bottom: 1px solid #ddd;
        }

        .admission-nav a.active {
            border-bottom-color: #006400;
        }
    }
</style>

<div class="admission-header">
    <h2>Chiniot Islamia Public School & College</h2>
    <h1>Admissions</h1>
</div>

<nav class="admission-nav">
    <ul>
        <li><a href="admission-procedure.php">Admission Procedure</a></li>
        <li><a href="admissions.php" class="active">Admission Form</a></li>
        <li><a href="fee-structure.php">Fee Structure</a></li>
        <li><a href="admission-policy.php">Admission Policy</a></li>
        <li><a href="admission-faqs.php">FAQs</a></li>
        <li><a href="how-to-pay.php">How to Pay Fee Bill</a></li>
        <li><a href="uniform.php">Uniform</a></li>
    </ul>
</nav>

<div class="admission-form">

    <?php if ($admissions_status == 'open'): ?>

        <form action="send-admission.php" method="POST" enctype="multipart/form-data">

            <h3>Undertaking by Parents</h3>
            <div class="undertaking">
                <p><strong>Please Read the Following Instructions Carefully Before Filling the Form.</strong></p>
                <ul>
                    <li>Filling of the application form only means that a candidate is eligible to apply for admission and does not guarantee admission.</li>
                    <li>Admission remains provisional and is not confirmed unless the following documents are submitted.</li>
                    <li>School leaving Certificate from the previous School attended.</li>
                    <li>Birth Certificate and Form-B (Both NADRA Only)</li>
                    <li>CNIC of Father / Mother (Both)</li>
                    <li>Medical Fitness Certificate (In Original)</li>
                    <li>Passport size Photographs with Blue Background</li>
                    <li>HOPE Certificate (XI Only) From Previous Institution</li>
                    <li>This institution has no transport arrangements. Pick and drop is managed by Parents through local transport under own arrangements /responsibility.</li>
                    <li>Non-payment of dues of two months will result in cancellation of admission without notice.</li>
                    <li>Decision of Academic Council for academic results regarding promotion to next class will be final and I Solemnly affirms that it will not be challenged in any Court of Law.</li>
                    <li>Any student found smoking / vaping or in possession of related items will be expelled from the School without notice.</li>
                    <li>Any willful damage to the School Property will result in CANCELLATION of the admission without notice.</li>
                    <li>I have gone through fee structure of Chiniot Islamia School and College. It can be revised by management as per rules / regulations.</li>
                    <li>I hereby declare that I have COMPUTER and PRINTER with INTERNET facility at my residence for use by the student for academic purpose.</li>
                    <li>I have carefully read the prospectus containing the rules, regulations and requirements of the Institution and agree to abide by them and to co-operate with the authorities in every way required. <a href="prospectus.pdf" target="_blank">Click Here for Prospectus</a>.</li>
                    <li>Examinations (First and Second Quarterly, First and Second Terms) will not be retaken if missed on any account.</li>
                </ul>
            </div>

            <h3 style="margin-top: 40px;">Student Information</h3>
            <p>TO BE FILLED IN BLOCK LETTERS</p>

            <div class="form-grid-3">
                <div class="form-group full-width">
                    <label for="student_name">Student's Name (as per CNIC or B-Form) <span>*</span></label>
                    <input type="text" id="student_name" name="student_name" required>
                </div>
                <div class="form-group">
                    <label for="dob">Date of Birth <span>*</span></label>
                    <input type="date" id="dob" name="dob" required>
                </div>
                <div class="form-group">
                    <label for="gender">Gender <span>*</span></label>
                    <select id="gender" name="gender" required>
                        <option value="">—Choose option—</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="place_of_birth">Place of Birth</label>
                    <input type="text" id="place_of_birth" name="place_of_birth">
                </div>
                <div class="form-group">
                    <label for="district">District</label>
                    <input type="text" id="district" name="district">
                </div>
                <div class="form-group">
                    <label for="religion">Religion <span>*</span></label>
                    <input type="text" id="religion" name="religion" value="Islam" required>
                </div>
                <div class="form-group">
                    <label for="nationality">Nationality <span>*</span></label>
                    <input type="text" id="nationality" name="nationality" value="Pakistani" required>
                </div>
            </div>
            <div class="form-group">
                <label for="student_cnic_bform">Student CNIC/Form B (13 digits, e.g. 42XXXXXX)</label>
                <input type="text" id="student_cnic_bform" name="student_cnic_bform" pattern="\d{13}">
            </div>

            <h3>Academic Information</h3>
            <div class="form-grid-3">
                <div class="form-group">
                    <label for="applying_for_class">Class to which admission is sought <span>*</span></label>
                    <select id="applying_for_class" name="applying_for_class" required>
                        <option value="">—Select Class—</option>
                        <option value="Montessori Junior (Morning)">Montessori Junior (Morning)</option>
                        <option value="Montessori Senior (Morning)">Montessori Senior (Morning)</option>
                        <option value="Montessori Advance (Morning)">Montessori Advance (Morning)</option>
                        <option value="Class I (Morning)">Class I (Morning)</option>
                        <option value="Class VI">Class VI</option>
                        <option value="Class VIII">Class VIII</option>
                        <option value="XI (Pre-Engineering)">XI (Pre-Engineering)</option>
                        <option value="XI (Pre-Medical)">XI (Pre-Medical)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="last_school_name">Class studying at present / school last attended</label>
                    <input type="text" id="last_school_name" name="last_school_name">
                </div>
                <div class="form-group">
                    <label for="last_school_cert_no">School Leaving Certificate No.</label>
                    <input type="text" id="last_school_cert_no" name="last_school_cert_no">
                </div>
            </div>
            <div class="form-group">
                <label for="last_school_date">School Leaving Date</label>
                <input type="date" id="last_school_date" name="last_school_date">
            </div>

            <h3>Parent / Guardian Information</h3>
            <div class="form-grid">
                <div class="form-group">
                    <label for="father_name">Father's Name (as per CNIC) <span>*</span></label>
                    <input type="text" id="father_name" name="father_name" required>
                </div>
                <div class="form-group">
                    <label for="father_cnic">Father's CNIC (13 digits, e.g. 42XXXXXX) <span>*</span></label>
                    <input type="text" id="father_cnic" name="father_cnic" pattern="\d{13}" required>
                </div>
                <div class="form-group">
                    <label for="guardian_name">Guardian's Name (If Applicable)</label>
                    <input type="text" id="guardian_name" name="guardian_name">
                </div>
                <div class="form-group">
                    <label for="occupation">Father’s / Guardian’s Occupation</label>
                    <input type="text" id="occupation" name="occupation">
                </div>
                <div class="form-group">
                    <label for="designation">Designation</label>
                    <input type="text" id="designation" name="designation">
                </div>
                <div class="form-group">
                    <label for="monthly_income">Monthly Income</label>
                    <input type="text" id="monthly_income" name="monthly_income">
                </div>
            </div>
            <div class="form-group">
                <label for="office_address">Office / Business Address</label>
                <textarea id="office_address" name="office_address" rows="3"></textarea>
            </div>
            <div class="form-grid-3">
                <div class="form-group">
                    <label for="tel_number">Telephone Number (Optional)</label>
                    <input type="tel" id="tel_number" name="tel_number">
                </div>
                <div class="form-group">
                    <label for="whatsapp_father">WhatsApp No. (Father) (e.g. 92333XXXXXXX) <span>*</span></label>
                    <input type="tel" id="whatsapp_father" name="whatsapp_father" required>
                </div>
                <div class="form-group">
                    <label for="whatsapp_mother">WhatsApp No. (Mother)</label>
                    <input type="tel" id="whatsapp_mother" name="whatsapp_mother">
                </div>
                <div class="form-group">
                    <label for="email_father">Parent's Email (Father)</label>
                    <input type="email" id="email_father" name="email_father">
                </div>
                <div class="form-group">
                    <label for="email_mother">Parent's Email (Mother)</label>
                    <input type="email" id="email_mother" name="email_mother">
                </div>
            </div>
            <div class="form-group">
                <label for="address">Local Address <span>*</span></label>
                <textarea id="address" name="address" rows="3" required></textarea>
            </div>
            <div class="form-group">
                <label for="permanent_address">Permanent Address</label>
                <textarea id="permanent_address" name="permanent_address" rows="3"></textarea>
            </div>

            <h3>Brothers / Sisters already studying in this School / College</h3>
            <div class="form-grid-4">
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="sibling_name[]">
                </div>
                <div class="form-group">
                    <label>Class</label>
                    <input type="text" name="sibling_class[]">
                </div>
                <div class="form-group">
                    <label>Name</label>
                    <input type="text" name="sibling_name[]">
                </div>
                <div class="form-group">
                    <label>Class</label>
                    <input type="text" name="sibling_class[]">
                </div>
            </div>

            <h3>Required Documents <span>*</span></h3>
            <p class="file-note">Attachments Formats: .jpg, .jpeg, .png, .pdf | Max Size 250KB. All documents are required.</p>

            <div class="form-grid-3">
                <div class="form-group">
                    <label for="photo_filename">Picture (Passport size, Blue Background) <span>*</span></label>
                    <input type="file" id="photo_filename" name="photo_filename" accept=".jpg,.jpeg,.png,.pdf" required>
                </div>
                <div class="form-group">
                    <label for="doc_birth_cert">Birth Certificate (NADRA Only) <span>*</span></label>
                    <input type="file" id="doc_birth_cert" name="doc_birth_cert" accept=".jpg,.jpeg,.png,.pdf" required>
                </div>
                <div class="form-group">
                    <label for="doc_bform">B-Form (NADRA Only) <span>*</span></label>
                    <input type="file" id="doc_bform" name="doc_bform" accept=".jpg,.jpeg,.png,.pdf" required>
                </div>
                <div class="form-group">
                    <label for="doc_father_cnic_front">Father's CNIC: Front Side <span>*</span></label>
                    <input type="file" id="doc_father_cnic_front" name="doc_father_cnic_front" accept=".jpg,.jpeg,.png,.pdf" required>
                </div>
                <div class="form-group">
                    <label for="doc_father_cnic_back">Father's CNIC: Back Side <span>*</span></label>
                    <input type="file" id="doc_father_cnic_back" name="doc_father_cnic_back" accept=".jpg,.jpeg,.png,.pdf" required>
                </div>
                <div class="form-group">
                    <label for="doc_mother_cnic_front">Mother's CNIC: Front Side <span>*</span></label>
                    <input type="file" id="doc_mother_cnic_front" name="doc_mother_cnic_front" accept=".jpg,.jpeg,.png,.pdf" required>
                </div>
                <div class="form-group">
                    <label for="doc_mother_cnic_back">Mother's CNIC: Back Side <span>*</span></label>
                    <input type="file" id="doc_mother_cnic_back" name="doc_mother_cnic_back" accept=".jpg,.jpeg,.png,.pdf" required>
                </div>
                <div class="form-group">
                    <label for="doc_last_school_cert">School Leaving Cert/Marksheet (XI Only) <span>*</span></label>
                    <input type="file" id="doc_last_school_cert" name="doc_last_school_cert" accept=".jpg,.jpeg,.png,.pdf" required>
                </div>
                <div class="form-group">
                    <label for="doc_medical_cert">Medical Certificate <span>*</span></label>
                    <input type="file" id="doc_medical_cert" name="doc_medical_cert" accept=".jpg,.jpeg,.png,.pdf" required>
                </div>
            </div>

            <h3>Final Steps</h3>
            <div class="form-group">
                <label for="heard_about_us">How did you hear about us? <span>*</span></label>
                <select id="heard_about_us" name="heard_about_us" required>
                    <option value="">—Please choose an option—</option>
                    <option value="Social Media (FaceBook/Instagram)">Social Media (FaceBook/Instagram)</option>
                    <option value="Personal Reference">Personal Reference</option>
                    <option value="School Visit">School Visit</option>
                    <option value="Billboard/Banner">Billboard/Banner</option>
                    <option value="Other">Other</option>
                </select>
            </div>

            <div class="checkbox-group">
                <input type="checkbox" id="verify" name="verify" required>
                <label for="verify">I agree with all the terms and conditions of Chiniot Islamia Public School, and verify that given data is correct. <span>*</span></label>
            </div>

            <button type="submit" class="submit-btn">Submit Application</button>
        </form>

    <?php else: ?>
        <div class="closed-notice">
            Admissions / Registration for Session 2025-2026 are now Closed.
            <br><br>
            <p style="font-size: 0.8em; font-weight: normal; margin-bottom: 0;">Please check back later for updates on the next admission cycle.</p>
        </div>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>