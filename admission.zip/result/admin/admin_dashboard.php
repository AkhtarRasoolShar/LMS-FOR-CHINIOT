<?php
include 'admin_check.php';

$logged_in_teacher_id = $_SESSION['user_id'];
$message = '';
$students = [];
$selected_class_id = $_GET['class_id'] ?? 0;
$selected_class_name = '';

// --- Get ALL classes assigned to THIS teacher for the dropdown ---
$class_stmt = $conn->prepare("
    SELECT DISTINCT c.class_id, c.class_name 
    FROM teacher_assignments ta
    JOIN classes c ON ta.class_id = c.class_id
    WHERE ta.teacher_id = ? 
    ORDER BY c.class_name
");
$class_stmt->bind_param("i", $logged_in_teacher_id);
$class_stmt->execute();
$class_result = $class_stmt->get_result();

// --- Get Students if a class was selected ---
if ($selected_class_id > 0) {
    // --- SECURITY CHECK ---
    $check_stmt = $conn->prepare("
        SELECT c.class_name 
        FROM teacher_assignments ta
        JOIN classes c ON ta.class_id = c.class_id
        WHERE ta.teacher_id = ? AND ta.class_id = ?
    ");
    $check_stmt->bind_param("ii", $logged_in_teacher_id, $selected_class_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        $class_data = $check_result->fetch_assoc();
        $selected_class_name = $class_data['class_name'];

        $like_class_name = '%' . $selected_class_name . '%';

        // --- FIX: Added condition to only select 'Current' students ---
        $student_stmt = $conn->prepare("
            SELECT student_id, name, f_name 
            FROM students 
            WHERE class LIKE ? AND enrollment_status = 'Current'
            ORDER BY student_id, name
        ");
        $student_stmt->bind_param("s", $like_class_name);
        $student_stmt->execute();
        $student_result = $student_stmt->get_result();

        while ($row = $student_result->fetch_assoc()) {
            $students[] = $row;
        }
        $student_stmt->close();
    } else {
        $message = "Error: You do not have permission to view this class.";
        $selected_class_id = 0; // Reset selection
    }
    $check_stmt->close();
}
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Teacher Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #006400;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1000px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #006400;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        fieldset {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 20px;
        }

        legend {
            font-weight: bold;
            color: #006400;
            padding: 0 10px;
        }

        .split-form {
            display: grid;
            grid-template-columns: 3fr 1fr;
            gap: 15px;
            align-items: flex-end;
        }

        .split-form button {
            padding: 10px;
        }

        .student-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .student-table th,
        .student-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .student-table th {
            background: #f2f2f2;
        }

        .student-table tr:nth-child(even) {
            background: #f9f9f9;
        }

        .quick-actions {
            margin-top: 30px;
        }

        .quick-actions ul {
            list-style-type: none;
            padding: 0;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        .quick-actions li a {
            display: block;
            padding: 15px 20px;
            background: #f0f0f0;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        .quick-actions li a:hover {
            background: #e0e0e0;
            border-color: #ccc;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Teacher Dashboard</h1>
        <a href="admin_logout.php">Logout</a>
    </div>

    <div class="container">

        <?php if ($message): ?>
            <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>"><?php echo $message; ?></p>
        <?php endif; ?>

        <fieldset class="quick-actions">
            <legend>Quick Actions</legend>
            <ul>
                <li><a href="mark_attendance.php">Mark Daily Attendance</a></li>
                <li><a href="add_result.php">Upload Student Results</a></li>
                <li><a href="request_edit.php">Request Result Unlock</a></li>
                <li><a href="edit_result.php">Edit Unlocked Results</a></li>
            </ul>
        </fieldset>

        <fieldset>
            <legend>View Class Roster</legend>
            <p>Select one of your assigned classes to see the list of current students.</p>
            <form action="admin_dashboard.php" method="GET" class="split-form">
                <div class="form-group">
                    <label for="class_select">Your Assigned Classes</label>
                    <select id="class_select" name="class_id" required>
                        <option value="">-- Select a Class --</option>
                        <?php
                        $class_result->data_seek(0);
                        while ($class = $class_result->fetch_assoc()): ?>
                            <option value="<?php echo $class['class_id']; ?>" <?php echo ($selected_class_id == $class['class_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <button type="submit">View Students</button>
            </form>
        </fieldset>

        <?php if (!empty($students)): ?>
            <fieldset>
                <legend>Students in <?php echo htmlspecialchars($selected_class_name); ?></legend>
                <table class="student-table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Father's Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($student['name']); ?></td>
                                <td><?php echo htmlspecialchars($student['f_name']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </fieldset>
        <?php elseif ($selected_class_id > 0): ?>
            <p>No students found for this class.</p>
        <?php endif; ?>

    </div>
</body>

</html>