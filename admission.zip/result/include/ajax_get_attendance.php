<?php
// ajax_get_attendance.php
// This file is called by JavaScript to get the attendance count.

include 'admin_check.php'; // Includes session and db connection

// Get POST data from JavaScript
$student_id = (int)$_POST['student_id'];
$term_name = $_POST['term_name'];
$logged_in_teacher_id = $_SESSION['teacher_id'];

// --- IMPORTANT: DEFINE YOUR TERM DATES ---
// You MUST set the start and end dates for your school terms here.
// I am using 2023/2024 as an example.
$term_dates = [
    '1st QUARTERLY' => ['start' => '2023-08-01', 'end' => '2023-10-20'],
    'MID TERM'      => ['start' => '2023-08-01', 'end' => '2023-12-22'],
    '2nd QUARTERLY' => ['start' => '2023-10-23', 'end' => '2023-12-22'],
    'FINAL TERM'    => ['start' => '2023-01-08', 'end' => '2024-03-15']
];
// ----------------------------------------

$present_count = 0;

// Check if the selected term has a defined date range
if (array_key_exists($term_name, $term_dates)) {

    // --- NEW: Security Check ---
    // Check if this teacher is assigned to this student's class
    $check_stmt = $conn->prepare("
        SELECT ta.assignment_id 
        FROM teacher_assignments ta
        JOIN students s ON ta.class_name = s.class
        WHERE ta.teacher_id = ? AND s.student_id = ?
    ");
    $check_stmt->bind_param("ii", $logged_in_teacher_id, $student_id);
    $check_stmt->execute();

    if ($check_stmt->get_result()->num_rows > 0) {
        // --- Security Check Passed ---
        $start_date = $term_dates[$term_name]['start'];
        $end_date = $term_dates[$term_name]['end'];

        // Query the database
        $stmt = $conn->prepare("
            SELECT COUNT(*) as present_days 
            FROM attendance 
            WHERE 
                student_id = ? 
                AND status = 'Present' 
                AND attendance_date BETWEEN ? AND ?
        ");
        $stmt->bind_param("iss", $student_id, $start_date, $end_date);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $present_count = $row['present_days'];
    }
    // If security check fails, $present_count will just be 0.
}

// Set the header to return JSON
header('Content-Type: application/json');
// Return the count
echo json_encode(['present_days' => $present_count]);
exit();
