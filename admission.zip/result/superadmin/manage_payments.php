<?php
// Secure this page! This checks if the user's role is 'admin' or 'FrontDesk'.
include 'admin_check.php';

$message = '';

// --- Handle Toggling the Payment Status ---
if (isset($_GET['toggle_payment'])) {
    $applicant_id = (int)$_GET['toggle_payment'];
    $new_status = (int)$_GET['status']; // 0 = Pending, 1 = Paid

    $stmt = $conn->prepare("UPDATE applicants SET payment_status = ? WHERE applicant_id = ?");
    $stmt->bind_param("ii", $new_status, $applicant_id);

    if ($stmt->execute()) {
        $status_text = ($new_status == 1) ? "MARKED AS PAID" : "MARKED AS PENDING";
        $message = "Success! Applicant payment status updated to: " . $status_text;
    } else {
        $message = "Error updating payment status: " . $stmt->error;
    }
    $stmt->close();

    // Redirect back to the same page
    header("Location: manage_payments.php?status=" . urlencode($message));
    exit();
}

// Check for status message from redirect
if (isset($_GET['status'])) {
    $message = htmlspecialchars($_GET['status']);
}

// --- Fetch all applicants ---
// Order by pending status first, then by test date.
$sql = "SELECT applicant_id, form_no, student_name, applying_for_class, payment_status, test_date FROM applicants ORDER BY payment_status ASC, test_date ASC";
$applicants_result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Admissions Payments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1000px;
            margin: auto;
        }

        .table-container {
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .message-alert {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .list-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .list-table th,
        .list-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .list-table th {
            background: #f2f2f2;
        }

        .status-paid {
            color: #006400;
            /* Green */
            font-weight: bold;
        }

        .status-pending {
            color: #b30000;
            /* Red */
            font-weight: bold;
        }

        .btn {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 4px;
            color: white;
            font-weight: bold;
            display: inline-block;
        }

        .btn-pay {
            background-color: #006400;
            /* Green Pay Button */
        }

        .btn-pending {
            background-color: #f0ad4e;
            /* Amber Pending Button */
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Admissions Payment Status</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">

        <div class="table-container">
            <h2>Admissions Fee Management</h2>
            <?php if ($message): ?>
                <p class="message-alert <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>"><?php echo $message; ?></p>
            <?php endif; ?>

            <p>Toggle the status to confirm fee payment. Only paid applicants can download their Admit Card.</p>

            <table class="list-table">
                <thead>
                    <tr>
                        <th style="width: 10%;">Form No.</th>
                        <th style="width: 30%;">Student Name</th>
                        <th style="width: 15%;">Applying Class</th>
                        <th style="width: 15%;">Test Date</th>
                        <th style="width: 15%;">Payment Status</th>
                        <th style="width: 15%;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($applicants_result && $applicants_result->num_rows > 0) {
                        while ($row = $applicants_result->fetch_assoc()):
                            $is_paid = $row['payment_status'] == 1;
                    ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['form_no']); ?></td>
                                <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['applying_for_class']); ?></td>
                                <td><?php echo !empty($row['test_date']) ? date('d-M-Y', strtotime($row['test_date'])) : 'N/A'; ?></td>
                                <td>
                                    <span class="<?php echo $is_paid ? 'status-paid' : 'status-pending'; ?>">
                                        <?php echo $is_paid ? 'PAID (1)' : 'PENDING (0)'; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if (!$is_paid): ?>
                                        <a href="manage_payments.php?toggle_payment=<?php echo $row['applicant_id']; ?>&status=1" class="btn btn-pay">Mark Paid</a>
                                    <?php else: ?>
                                        <a href="manage_payments.php?toggle_payment=<?php echo $row['applicant_id']; ?>&status=0" class="btn btn-pending">Revert to Pending</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                    <?php
                        endwhile;
                    } else {
                        echo "<tr><td colspan='6' style='text-align: center;'>No new applicants found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

    </div>
</body>

</html>