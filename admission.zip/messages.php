<?php
// Start the session
session_start();

// --- SECURITY CHECK ---
// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: portal.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - Chiniot Islamia Public School & College</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

    <header>
        <div class="container">
            <a href="index.php" class="logo">Chiniot School</a>
            <nav class="main-nav">
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="messages.php" class="active">Messages</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="page-header">
        <div class="container">
            <h1>Parent Inbox</h1>
        </div>
    </section>

    <section class="page-content">
        <div class="container">

            <div class="message-container">
                <div class="message-list">
                    <div class="message-item active">
                        <div class="message-sender">School Administration</div>
                        <div class="message-subject">Announcement: Sports Day Postponed</div>
                        <div class="message-date">Oct 27, 2025</div>
                    </div>
                    <div class="message-item">
                        <div class="message-sender">Ms. Saima (Class Teacher)</div>
                        <div class="message-subject">Parent-Teacher Meeting Schedule</div>
                        <div class="message-date">Oct 24, 2025</div>
                    </div>
                    <div class="message-item">
                        <div class="message-sender">School Administration</div>
                        <div class="message-subject">Welcome to the Parent Portal</div>
                        <div class="message-date">Oct 20, 2025</div>
                    </div>
                </div>

                <div class="message-view">
                    <div class="message-view-header">
                        <h3>Announcement: Sports Day Postponed</h3>
                        <p>From: <strong>School Administration</strong></p>
                        <p>Date: October 27, 2025</p>
                    </div>
                    <div class="message-view-body">
                        <p>Dear Parents,</p>
                        <p>Please be informed that the Annual Sports Day, originally scheduled for October 29th, has been postponed due to a poor weather forecast.</p>
                        <p>The new date for the Sports Day will be **November 5th, 2025**.</p>
                        <p>We apologize for any inconvenience this may cause and look forward to seeing you all on the new date.</p>
                        <p>Sincerely,<br>Chiniot School Administration</p>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <footer>
        <div class="footer-bottom">
            <p>&copy; <?php echo date("Y"); ?> Chiniot Islamia Public School & College. All Rights Reserved.</p>
        </div>
    </footer>

</body>

</html>