<?php
include 'admin_check.php'; // Includes security and sets $logged_in_user_id

// Only Super Admins can access this page
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'superadmin') {
    die("Access Denied.");
}

$message = '';
$error = '';
$teacher_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($teacher_id === 0) {
    die("Invalid Teacher ID.");
}

// Fetch the teacher's name for display
$name_stmt = $conn->prepare("SELECT full_name FROM teachers WHERE teacher_id = ?");
$name_stmt->bind_param("i", $teacher_id);
$name_stmt->execute();
$teacher_data = $name_stmt->get_result()->fetch_assoc();
$teacher_name = $teacher_data['full_name'] ?? "Unknown User";
$name_stmt->close();


// --- Handle Form Submission ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['new_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($new_password) || empty($confirm_password)) {
        $error = "Password fields cannot be empty.";
    } elseif ($new_password !== $confirm_password) {
        $error = "New passwords do not match.";
    } elseif (strlen($new_password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } else {
        // Generate secure BCRYPT hash
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

        // Update the teacher's password in the database
        $update_stmt = $conn->prepare("UPDATE teachers SET password_hash = ? WHERE teacher_id = ?");
        $update_stmt->bind_param("si", $password_hash, $teacher_id);

        if ($update_stmt->execute()) {
            $message = "Success! Password for " . htmlspecialchars($teacher_name) . " has been reset.";
        } else {
            $error = "Database Error: Could not update password.";
        }
        $update_stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7f6;
            margin: 0;
        }

        .header {
            background: #004d40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 500px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #004d40;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .reset-btn {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            margin-top: 10px;
        }

        .reset-btn:hover {
            background-color: #8c0000;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Reset Password</h1>
        <a href="manage_teachers.php">Back to Teachers</a>
    </div>

    <div class="container">
        <h2>Resetting Password for: <?php echo htmlspecialchars($teacher_name); ?></h2>

        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="message error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="POST" action="reset_teacher_password.php?id=<?php echo $teacher_id; ?>">
            <div class="form-group">
                <label for="new_password">New Password (Min 6 characters)</label>
                <input type="password" id="new_password" name="new_password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm New Password</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            <button type="submit" class="reset-btn">Reset Password</button>
        </form>
    </div>
</body>

</html>