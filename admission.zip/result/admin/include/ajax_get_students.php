<?php
// ajax_get_students.php
// Fetches students belonging to the selected class (by ID).

// --- FIX ---
// The db.php file is in the parent directory (result/), not in the admin/ directory.
// We must go up one level (../) to include it.
include '../db.php';

// --- Security Check ---
// We must also include the admin_check.php to secure this file
// and get the logged_in_teacher_id.
// It's in the *same* folder, so 'admin_check.php' is correct.
include 'admin_check.php';

$class_id = (int)$_GET['class_id'] ?? 0;
// $logged_in_teacher_id is now available from admin_check.php

$students = [];

if ($class_id === 0) {
    header('Content-Type: application/json');
    echo json_encode([]);
    exit;
}

// 1. Get the actual class_name from the class_id (used to query the 'students' table)
$class_name_stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
$class_name_stmt->bind_param("i", $class_id);
$class_name_stmt->execute();
$class_data = $class_name_stmt->get_result()->fetch_assoc();
$class_name = $class_data['class_name'] ?? '';
$class_name_stmt->close();

if (!empty($class_name)) {
    // 2. Fetch all students in this class using the class_name
    // We don't need a security check here, because the main form
    // (add_result.php) only loaded classes the teacher is assigned to.
    $stmt = $conn->prepare("
        SELECT student_id, name, f_name
        FROM students 
        WHERE class = ? 
        ORDER BY name
    ");
    $stmt->bind_param("s", $class_name);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
    $stmt->close();
}

header('Content-Type: application/json');
echo json_encode($students);
exit();
