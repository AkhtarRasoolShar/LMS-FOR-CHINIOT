<?php
$pageTitle = "Uniform";
include 'header.php';
?>
<style>
    .admission-header {
        text-align: center;
        margin: 20px auto;
        padding: 0 20px;
        max-width: 900px;
    }

    .admission-header h2 {
        font-size: 18px;
        color: #555;
        margin: 0;
        font-weight: normal;
    }

    .admission-header h1 {
        font-size: 36px;
        color: #006400;
        margin: 5px 0 15px 0;
    }

    .admission-nav {
        background: #f8f9fa;
        border-bottom: 1px solid #ddd;
        border-top: 1px solid #ddd;
        text-align: center;
        margin-bottom: 30px;
    }

    .admission-nav ul {
        margin: 0;
        padding: 0;
        list-style: none;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
    }

    .admission-nav li {
        display: inline-block;
    }

    .admission-nav a {
        display: block;
        padding: 15px 20px;
        text-decoration: none;
        color: #006400;
        font-weight: bold;
        font-size: 16px;
        border-bottom: 3px solid transparent;
    }

    .admission-nav a:hover {
        background: #e9ecef;
    }

    .admission-nav a.active {
        border-bottom-color: #006400;
        color: #333;
        background: #e9ecef;
    }

    .content-page {
        max-width: 900px;
        margin: 0 auto 30px auto;
        padding: 30px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        font-size: 16px;
        line-height: 1.7;
        color: #333;
    }

    .content-page h2 {
        color: #006400;
        border-bottom: 2px solid #f0f0f0;
        padding-bottom: 10px;
        margin-top: 0;
    }

    .content-page h3 {
        color: #006400;
        margin-top: 30px;
    }

    .content-page ol {
        padding-left: 20px;
        margin-top: 15px;
    }

    .content-page ol li {
        margin-bottom: 10px;
    }

    .uniform-split {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 30px;
    }

    .tie-gallery {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 15px;
        margin-top: 20px;
        text-align: center;
    }

    .tie-gallery img {
        width: 100%;
        border: 1px solid #ddd;
        border-radius: 5px;
    }

    .tie-gallery p {
        font-weight: bold;
        color: #333;
        margin-top: 5px;
    }

    @media (max-width: 768px) {
        .admission-nav ul {
            flex-direction: column;
        }

        .admission-nav a {
            border-bottom: 1px solid #ddd;
        }

        .admission-nav a.active {
            border-bottom-color: #006400;
        }

        .uniform-split {
            grid-template-columns: 1fr;
        }

        .tie-gallery {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="admission-header">
    <h2>Chiniot Islamia Public School & College</h2>
    <h1>Admissions</h1>
</div>

<nav class="admission-nav">
    <ul>
        <li><a href="admission-procedure.php">Admission Procedure</a></li>
        <li><a href="admissions.php">Admission Form</a></li>
        <li><a href="fee-structure.php">Fee Structure</a></li>
        <li><a href="admission-policy.php">Admission Policy</a></li>
        <li><a href="admission-faqs.php">FAQs</a></li>
        <li><a href="how-to-pay.php">How to Pay Fee Bill</a></li>
        <li><a href="uniform.php" class="active">Uniform</a></li>
    </ul>
</nav>

<div class="content-page">
    <h2>Uniform</h2>
    <p>The following is the uniform for boys/girls from Class I to XII.</p>
    <div class="uniform-split">
        <div>
            <h3>BOYS – School (Class I – X / O Level)</h3>
            <ol>
                <li>White half sleeves shirt with school monogram on the pocket. (for Summer).</li>
                <li>Grey Trousers (students up to Class-I may wear shorts).</li>
                <li>Black Socks.</li>
                <li>Plain Black shoes with laces.</li>
                <li>Grey V-necked pullovers with full sleeves shirt (for Winters). In case of severe clod only plain black Jacket can be worn additionally.</li>
                <li>Black leather belt.</li>
                <li>Neck Tie with Maroon and Grey stripes.</li>
                <li>Neck tie with Golden and Blue stripes (for O Level).</li>
            </ol>

            <h3>BOYS – College (Class XI & XII)</h3>
            <ol>
                <li>White half sleeves shirt with school monogram on the pocket. (for Summer).</li>
                <li>Navy blue Trousers.</li>
                <li>Black Socks.</li>
                <li>Plain Black shoes with laces.</li>
                <li>Blue V-necked pullovers with full sleeves shirt (for Winters). In case of severe cold only plain black jacket can be worn additionally.</li>
                <li>Neck Tie with Navy Blue and Golden stripes.</li>
                <li>Black leather belt.</li>
            </ol>
        </div>
        <div>
            <h3>GIRLS – School (Class I – X)</h3>
            <ol>
                <li>Gray full sleeves Kameez with collar and school monogram on the pocket.</li>
                <li>White Shalwar.</li>
                <li>White Dupatta with grey border.</li>
                <li>White head scarf (Compulsory from class VI to X)</li>
                <li>White socks.</li>
                <li>Black leather shoes.</li>
                <li>Grey cardigan for winters.</li>
            </ol>

            <h3>GIRLS – College (Class XI & XII)</h3>
            <ol>
                <li>White full sleeves Kameez with Blue cuffs, collar and school monogram on the pocket.</li>
                <li>White Shalwar.</li>
                <li>White Dupatta with Blue Border.</li>
                <li>Compulsory white head scarf</li>
                <li>White socks.</li>
                <li>Black leather shoes.</li>
                <li>Blue cardigan for winters.</li>
            </ol>
        </div>
    </div>

    <div class="tie-gallery">
        <div>
            <img src="class I TO X.jpg" alt="Tie for Class I to X">
            <p>Class I to X</p>
        </div>
        <div>
            <img src="O'Level.jpg" alt="Tie for O'Level">
            <p>O'Level</p>
        </div>
        <div>
            <img src="XI & XII.webp" alt="Tie for XI & XII">
            <p>XI & XII</p>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>