<?php
include 'admin_check.php'; // Includes session and db connection (../db.php)

// Only Super Admins can access this page
if ($_SESSION['role'] !== 'admin') {
    die("Access Denied. You must be a Super Admin.");
}

$message = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $recipient_id = $_POST['recipient_teacher_id'];
    $subject = $_POST['subject'];
    $message_body = $_POST['message_body'];

    if (empty($subject) || empty($message_body)) {
        $error = "Subject and Message Body are required.";
    } else {
        try {
            if ($recipient_id == 'all') {
                // Send to ALL teachers (set recipient_teacher_id to NULL)
                $stmt = $conn->prepare("
                    INSERT INTO teacher_messages (subject, message_body, recipient_teacher_id) 
                    VALUES (?, ?, NULL)
                ");
                $stmt->bind_param("ss", $subject, $message_body);
            } else {
                // Send to a specific teacher
                $recipient_id = (int)$recipient_id;
                $stmt = $conn->prepare("
                    INSERT INTO teacher_messages (subject, message_body, recipient_teacher_id) 
                    VALUES (?, ?, ?)
                ");
                $stmt->bind_param("ssi", $subject, $message_body, $recipient_id);
            }

            $stmt->execute();
            $stmt->close();
            $message = "Message sent successfully!";
        } catch (mysqli_sql_exception $e) {
            error_log("send_message.php DB Error: " . $e->getMessage());
            $error = "Database Error: Could not send message.";
        }
    }
}

// Fetch all teachers for the dropdown
$teacher_stmt = $conn->prepare("SELECT teacher_id, full_name, username FROM teachers WHERE role = 'teacher'");
$teacher_stmt->execute();
$teachers_result = $teacher_stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Send Message to Teachers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #006400;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 800px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group textarea {
            height: 150px;
            font-family: Arial, sans-serif;
        }

        button {
            background-color: #006400;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Send Message</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="message error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form action="send_message.php" method="POST">
            <fieldset>
                <legend>Compose Message</legend>

                <div class="form-group">
                    <label for="recipient_teacher_id">To:</label>
                    <select id="recipient_teacher_id" name="recipient_teacher_id" required>
                        <option value="all">-- ALL TEACHERS --</option>
                        <?php while ($teacher = $teachers_result->fetch_assoc()): ?>
                            <option value="<?php echo $teacher['teacher_id']; ?>">
                                <?php echo htmlspecialchars($teacher['full_name']); ?> (<?php echo htmlspecialchars($teacher['username']); ?>)
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="subject">Subject:</label>
                    <input type="text" id="subject" name="subject" required>
                </div>

                <div class="form-group">
                    <label for="message_body">Message:</label>
                    <textarea id="message_body" name="message_body" required></textarea>
                </div>

                <button type="submit">Send Message</button>
            </fieldset>
        </form>
    </div>
</body>

</html>