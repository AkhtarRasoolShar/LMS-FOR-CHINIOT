<?php
$pageTitle = "My Profile";
include 'header_student.php';

$msg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_pass = $_POST['new_pass'];
    $confirm = $_POST['confirm_pass'];

    if ($new_pass === $confirm && !empty($new_pass)) {
        $hash = password_hash($new_pass, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE students SET password_hash = ? WHERE student_id = ?");
        $stmt->bind_param("si", $hash, $student_id);
        if ($stmt->execute()) {
            $msg = "<div style='color:green; margin-bottom:15px; font-weight:bold;'>Password updated successfully!</div>";
        } else {
            $msg = "<div style='color:red; margin-bottom:15px;'>Update failed.</div>";
        }
    } else {
        $msg = "<div style='color:red; margin-bottom:15px;'>Passwords do not match.</div>";
    }
}
?>

<div class="card">
    <h3 style="border-bottom:1px solid #eee; padding-bottom:10px; margin-top:0;">Personal Information</h3>
    <table style="width:100%; max-width:600px;">
        <tr>
            <td style="width:150px; font-weight:bold;">Student Name:</td>
            <td><?php echo htmlspecialchars($current_student['name']); ?></td>
        </tr>
        <tr>
            <td style="font-weight:bold;">Student ID:</td>
            <td><?php echo $current_student['student_id']; ?></td>
        </tr>
        <tr>
            <td style="font-weight:bold;">Father's Name:</td>
            <td><?php echo htmlspecialchars($current_student['f_name']); ?></td>
        </tr>
        <tr>
            <td style="font-weight:bold;">Class:</td>
            <td><?php echo htmlspecialchars($current_student['class']); ?></td>
        </tr>
        <tr>
            <td style="font-weight:bold;">Gender:</td>
            <td><?php echo htmlspecialchars($current_student['gender']); ?></td>
        </tr>
    </table>
</div>

<div class="card">
    <h3 style="border-bottom:1px solid #eee; padding-bottom:10px; margin-top:0;">Security Settings</h3>
    <?php echo $msg; ?>
    <form method="POST" style="max-width:400px;">
        <div style="margin-bottom:15px;">
            <label style="display:block; margin-bottom:5px; font-weight:bold; color:#555;">New Password</label>
            <input type="password" name="new_pass" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
        </div>
        <div style="margin-bottom:20px;">
            <label style="display:block; margin-bottom:5px; font-weight:bold; color:#555;">Confirm Password</label>
            <input type="password" name="confirm_pass" required style="width:100%; padding:10px; border:1px solid #ccc; border-radius:4px;">
        </div>
        <button type="submit" class="btn-primary">Change Password</button>
    </form>
</div>

</div>
</div>
</body>

</html>