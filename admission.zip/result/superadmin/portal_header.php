<?php
// This header is localized for the Super Admin Portal

// Note: admin_check.php must run BEFORE this file is included
$portalTitle = isset($portalTitle) ? $portalTitle : 'Super Admin Portal';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo $portalTitle; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
        }

        .portal-main-header {
            background: #004d40;
            /* Teal/Green Theme */
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .portal-main-header h1 {
            margin: 0;
            font-size: 24px;
        }

        .portal-main-header .user-info {
            font-size: 14px;
            margin-right: 15px;
        }

        .portal-main-header a {
            color: #fdb813;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <div class="portal-main-header">
        <h1><?php echo $portalTitle; ?></h1>
        <div>
            <span class="user-info">Welcome, <?php echo htmlspecialchars($logged_in_user_name ?? 'Admin'); ?></span>
            <a href="logout.php">Logout</a>
        </div>
    </div>