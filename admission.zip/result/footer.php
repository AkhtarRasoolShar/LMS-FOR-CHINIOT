<footer class="main-footer">
    &copy; <?php echo date('Y'); ?> Chiniot Islamia Public School & College. All Rights Reserved.
</footer>

<?php
// This is now the single, safe place to close the database connection
// We check if the $conn variable exists before closing it.
if (isset($conn) && $conn) {
    $conn->close();
}
?>

</body>

</html>