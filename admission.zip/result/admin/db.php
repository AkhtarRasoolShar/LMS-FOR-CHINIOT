<?php
/*
  db.php
  This file connects to your MySQL database.
*/

// --- 1. SET YOUR TIMEZONE ---
// This forces PHP to use your local time (Pakistan Standard Time)
date_default_timezone_set('Asia/Karachi');

// NEW: Enable MySQLi exception reporting for better error handling
// This means any query/prepare failure will throw a mysqli_sql_exception
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Database credentials
$servername = "localhost"; // Usually 'localhost'
$username = "root";        // Your database username (default for XAMPP)
$password = "";            // Your database password (default for XAMPP is empty)
$dbname = "result"; // The name of the database you created

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Set the character set to utf8 (good for all languages, including Urdu)
$conn->set_charset("utf8");

// --- 2. SET MYSQL'S TIMEZONE ---
// This forces MySQL to use the same timezone for this connection
// PKT is UTC+5, so we use '+05:00'
$conn->query("SET time_zone = '+05:00'");

}