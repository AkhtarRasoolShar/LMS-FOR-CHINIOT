<?php
session_start();
session_unset();
session_destroy();
header("Location: frontdesk_login.php");
exit;
