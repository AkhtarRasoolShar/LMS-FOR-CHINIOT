<?php
include 'admin_check.php'; // --- SECURITY FIRST ---
$message = '';
$error = '';

// --- Handle Actions (Approve/Deny) ---
if (isset($_GET['action']) && isset($_GET['req_id'])) {
    $action = $_GET['action'];
    $request_id = (int)$_GET['req_id'];
    $student_id = (int)$_GET['student_id'];
    $term_name = $_GET['term_name'];

    $conn->begin_transaction();
    try {
        if ($action == 'approve') {
            // 1. Approve the request (Update the request status)
            $stmt1 = $conn->prepare("UPDATE result_edit_requests SET status = 'Approved' WHERE request_id = ?");
            $stmt1->bind_param("i", $request_id);
            $stmt1->execute();

            // 2. Unlock the result in the summaries table (is_locked = 0)
            $stmt2 = $conn->prepare("UPDATE summaries SET is_locked = 0 WHERE student_id = ? AND term_name = ?");
            $stmt2->bind_param("is", $student_id, $term_name);
            $stmt2->execute();

            $conn->commit();
            $message = "Request approved. The result for student $student_id is now unlocked for editing.";
        } elseif ($action == 'deny') {
            // 1. Deny the request
            $stmt1 = $conn->prepare("UPDATE result_edit_requests SET status = 'Denied' WHERE request_id = ?");
            $stmt1->bind_param("i", $request_id);
            $stmt1->execute();

            $conn->commit();
            $message = "Request denied.";
        }
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        $error = "Database error: " . $e->getMessage();
    }
}

// Fetch all requests
$requests_result = $conn->query("
    SELECT r.*, s.name as student_name, t.full_name as requested_by_name
    FROM result_edit_requests r
    JOIN students s ON r.student_id = s.student_id
    JOIN teachers t ON r.requested_by_id = t.teacher_id
    ORDER BY r.request_date DESC
");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Result Edit Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #004d40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th,
        .data-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .data-table th {
            background: #f2f2f2;
        }

        .action-link {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 14px;
            color: white;
            margin-right: 5px;
        }

        .action-approve {
            background-color: #28a745;
        }

        .action-deny {
            background-color: #dc3545;
        }

        .status-Pending {
            color: #ffc107;
            font-weight: bold;
        }

        .status-Approved {
            color: #28a745;
            font-weight: bold;
        }

        .status-Denied {
            color: #dc3545;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Manage Result Edit Requests</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?><p class="message"><?php echo $message; ?></p><?php endif; ?>
        <?php if ($error): ?><p class="message error"><?php echo $error; ?></p><?php endif; ?>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Term</th>
                    <th>Reason</th>
                    <th>Requested By</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($requests_result->num_rows > 0): ?>
                    <?php while ($row = $requests_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_name']); ?> (ID: <?php echo $row['student_id']; ?>)</td>
                            <td><?php echo htmlspecialchars($row['term_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['reason']); ?></td>
                            <td><?php echo htmlspecialchars($row['requested_by_name']); ?></td>
                            <td><?php echo date('M j, Y g:i A', strtotime($row['request_date'])); ?></td>
                            <td><span class="status-<?php echo $row['status']; ?>"><?php echo $row['status']; ?></span></td>
                            <td>
                                <?php if ($row['status'] == 'Pending'): ?>
                                    <a href="?action=approve&req_id=<?php echo $row['request_id']; ?>&student_id=<?php echo $row['student_id']; ?>&term_name=<?php echo $row['term_name']; ?>" class="action-link action-approve">Approve</a>
                                    <a href="?action=deny&req_id=<?php echo $row['request_id']; ?>&student_id=<?php echo $row['student_id']; ?>&term_name=<?php echo $row['term_name']; ?>" class="action-link action-deny">Deny</a>
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No edit requests found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html>