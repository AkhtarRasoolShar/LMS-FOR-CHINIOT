<?php
$pageTitle = "Gallery";
include 'header.php';
?>

<style>
    .gallery-section {
        margin-bottom: 40px;
    }

    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .gallery-item {
        border: 1px solid #ddd;
        border-radius: 5px;
        overflow: hidden;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    }

    .gallery-item img {
        width: 100%;
        height: 200px;
        object-fit: cover;
        display: block;
    }

    .gallery-item p {
        text-align: center;
        font-weight: bold;
        padding: 10px;
        margin: 0;
        background: #f9f9f9;
    }
</style>

<div class="container">
    <h2>Pictorial Gallery</h2>
    <p>A glimpse into the vibrant student life at Chiniot Islamia Public School & College.</p>

    <section id="prize-distribution" class="gallery-section">
        <h3>Annual Day & Prize Distribution</h3>
        <div class="gallery-grid">
            <div class="gallery-item">
                <img src="Annual Day & Prize Distribution Ceremony.jpg" alt="Prize Distribution Ceremony">
                <p>Receiving Awards</p>
            </div>
            <div class="gallery-item">
                <img src="Annual Day & Prize Distribution Ceremonys.jpg" alt="Prize Distribution Ceremony">
                <p>Student Performances</p>
            </div>
            <div class="gallery-item">
                <img src="Unknown000653-768x512.jpg" alt="Annual Day Event">
                <p>Annual Day Event</p>
            </div>
        </div>
    </section>

    <section id="sports-day" class="gallery-section">
        <h3>Annual Sports Day / Sports Gala</h3>
        <div class="gallery-grid">
            <div class="gallery-item">
                <img src="Unknown000542-768x512.jpg" alt="Sports Gala">
                <p>March Past</p>
            </div>


        </div>
    </section>

    <section id="independence-day" class="gallery-section">
        <h3>Independence Day Celebrations</h3>
        <div class="gallery-grid">


            [Image of students with flags celebrating Independence Day]


        </div>
    </section>

    <section id="defence-day" class="gallery-section">
        <h3>Defence Day</h3>
        <div class="gallery-grid">

        </div>
    </section>

    <section id="open-day" class="gallery-section">
        <h3>Open Day</h3>
        <div class="gallery-grid">
            <div class="gallery-item">
                <img src="img/Open Day/Open Day.jpg" alt="Open Day">
                <p>Open Day</p>
            </div>
            <div class="gallery-item">
                <img src="img/Open Day/Open Day1.jpg" alt="Open Day">
                <p>Student Projects</p>
            </div>
            <div class="gallery-item">
                <img src="img/Open Day/Open Day3.jpg" alt="Open Day">
                <p>Science Projects</p>
            </div>
        </div>
    </section>

    <section id="fun-fair" class="gallery-section">
        <h3>Fun Fair</h3>
        <div class="gallery-grid">


            [Image of students at a food stall during the fun fair]



            [Image of games and activities at the fun fair]

        </div>
    </section>

    <section id="scouts" class="gallery-section">
        <h3>Scout Camp</h3>
        <div class="gallery-grid">


        </div>
    </section>

    <section id="class-activity" class="gallery-section">
        <h3>Class Activity & Student of the Month</h3>
        <div class="gallery-grid">
            <div class="gallery-item">
                <img src="img/DSC_6870-768x512.jpg" alt="Class Activity">
                <p>Library Activity</p>
            </div>
            <div class="gallery-item">
                <img src="img/DSC_4500-768x512.jpg" alt="Class Activity">
                <p>Reading Session</p>
            </div>

        </div>
    </section>
</div>

<?php include 'footer.php'; ?>