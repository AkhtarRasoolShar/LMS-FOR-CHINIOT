<?php
session_start();
$pageTitle = "Student Dashboard";
include '../header.php'; // Main site header
include 'db.php';

// 1. Session Verification
if (!isset($_SESSION['student_data']) || !isset($_SESSION['term_name'])) {
    header("Location: index.php?error=session_expired");
    exit;
}

$student = $_SESSION['student_data'];
$student_id = (int)$student['student_id'];
$current_term = $_SESSION['term_name']; // Term selected at login
$year_session = date('Y');

// 2. Fetch Class Info if missing
if (!isset($student['class_id'])) {
    $class_stmt = $conn->prepare("SELECT class_id FROM classes WHERE ? LIKE CONCAT('%', class_name, '%')");
    $class_stmt->bind_param("s", $student['class']);
    $class_stmt->execute();
    $class_data = $class_stmt->get_result()->fetch_assoc();
    $student['class_id'] = $class_data['class_id'] ?? 0;
    $class_stmt->close();
}

// 3. Fetch Subjects
$subjects = [];
$sub_stmt = $conn->prepare("
    SELECT s.subject_id, s.subject_name 
    FROM class_subjects cs
    JOIN subjects s ON cs.subject_id = s.subject_id
    WHERE cs.class_id = ? ORDER BY s.subject_id
");
$sub_stmt->bind_param("i", $student['class_id']);
$sub_stmt->execute();
$sub_res = $sub_stmt->get_result();
while ($row = $sub_res->fetch_assoc()) {
    $subjects[$row['subject_id']] = $row['subject_name'];
}
$sub_stmt->close();

// 4. Fetch Results & Summaries (With Teacher Name)
$all_terms = ['1st QUARTERLY', 'MID TERM', '2nd QUARTERLY', 'FINAL TERM'];
$results_data = [];
$summary_data = [];

foreach ($all_terms as $term) {
    // Results
    $res_stmt = $conn->prepare("SELECT subject_id, marks_obtained, total_marks FROM results WHERE student_id = ? AND term_name = ?");
    $res_stmt->bind_param("is", $student_id, $term);
    $res_stmt->execute();
    $r_res = $res_stmt->get_result();
    while ($row = $r_res->fetch_assoc()) {
        $results_data[$term][$row['subject_id']] = $row;
    }
    $res_stmt->close();

    // Summaries (Joined with Teacher table)
    // Note: Assuming table name is 'teacher' or 'teachers'. Using 'teacher' based on your SQL dump.
    $sum_stmt = $conn->prepare("
        SELECT s.*, t.full_name as teacher_name 
        FROM summaries s
        LEFT JOIN teacher t ON s.teacher_id = t.teacher_id
        WHERE s.student_id = ? AND s.term_name = ?
    ");
    $sum_stmt->bind_param("is", $student_id, $term);
    $sum_stmt->execute();
    $summary_data[$term] = $sum_stmt->get_result()->fetch_assoc();
    $sum_stmt->close();
}

// 5. Fetch Daily Attendance History
$att_data = [];
$att_stmt = $conn->prepare("SELECT attendance_date, status FROM attendance WHERE student_id = ? ORDER BY attendance_date DESC");
$att_stmt->bind_param("i", $student_id);
$att_stmt->execute();
$att_res = $att_stmt->get_result();
while ($row = $att_res->fetch_assoc()) {
    $att_data[] = $row;
}
$att_stmt->close();

// 6. Fetch Announcements
$news_data = [];
$news_stmt = $conn->prepare("SELECT * FROM announcements ORDER BY post_date DESC LIMIT 5");
$news_stmt->execute();
$news_res = $news_stmt->get_result();
while ($row = $news_res->fetch_assoc()) {
    $news_data[] = $row;
}
$news_stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .main-container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 0 15px;
        }

        /* Profile Card */
        .profile-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            border-left: 5px solid #004a99;
        }

        .profile-details h2 {
            margin: 0 0 5px 0;
            color: #004a99;
        }

        .profile-details p {
            margin: 3px 0;
            color: #666;
        }

        .logout-btn {
            padding: 8px 15px;
            background: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
        }

        /* Tabs */
        .tab-nav {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }

        .tab-btn {
            padding: 10px 20px;
            background: #e9ecef;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            color: #555;
        }

        .tab-btn.active {
            background: #004a99;
            color: white;
        }

        .tab-content {
            display: none;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .tab-content.active {
            display: block;
        }

        /* Tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f8f9fa;
            color: #004a99;
        }

        .status-Present {
            color: green;
            font-weight: bold;
        }

        .status-Absent {
            color: red;
            font-weight: bold;
        }

        .status-Leave {
            color: orange;
            font-weight: bold;
        }

        /* Announcement Box */
        .notice-item {
            border-bottom: 1px solid #eee;
            padding: 10px 0;
        }

        .notice-item:last-child {
            border-bottom: none;
        }

        .notice-date {
            font-size: 0.85em;
            color: #888;
        }

        .notice-title {
            font-weight: bold;
            color: #333;
            display: block;
            margin-bottom: 4px;
        }

        /* Print Friendly */
        @media print {

            .tab-nav,
            .logout-btn {
                display: none;
            }

            .tab-content {
                display: block !important;
                margin-bottom: 30px;
                box-shadow: none;
                border: 1px solid #ddd;
            }
        }
    </style>
</head>

<body>

    <div class="main-container">
        <div class="profile-card">
            <div class="profile-details">
                <h2><?php echo htmlspecialchars($student['name']); ?></h2>
                <p><strong>ID:</strong> <?php echo $student['student_id']; ?> | <strong>Class:</strong> <?php echo htmlspecialchars($student['class']); ?></p>
                <p><strong>Father:</strong> <?php echo htmlspecialchars($student['f_name']); ?></p>
            </div>
            <div>
                <a href="index.php" class="logout-btn">Logout</a>
            </div>
        </div>

        <div class="tab-nav">
            <button class="tab-btn active" onclick="openTab(event, 'ResultCard')">Result Card</button>
            <button class="tab-btn" onclick="openTab(event, 'Attendance')">Daily Attendance</button>
            <button class="tab-btn" onclick="openTab(event, 'Announcements')">Announcements</button>
        </div>

        <div id="ResultCard" class="tab-content active">
            <h3 style="color:#004a99; border-bottom:2px solid #eee; padding-bottom:10px;">
                Academic Performance (Current Selection: <?php echo htmlspecialchars($current_term); ?>)
            </h3>

            <table>
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th><?php echo htmlspecialchars($current_term); ?> Marks</th>
                        <th>Total</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $labels = [];
                    $data_points = [];
                    foreach ($subjects as $sub_id => $sub_name):
                        $m = $results_data[$current_term][$sub_id]['marks_obtained'] ?? '-';
                        $t = $results_data[$current_term][$sub_id]['total_marks'] ?? '-';
                        $p = ($t > 0 && is_numeric($m)) ? round(($m / $t) * 100, 1) : 0;

                        if (is_numeric($m)) {
                            $labels[] = $sub_name;
                            $data_points[] = $p;
                        }
                    ?>
                        <tr>
                            <td><?php echo htmlspecialchars($sub_name); ?></td>
                            <td><?php echo $m; ?></td>
                            <td><?php echo $t; ?></td>
                            <td><?php echo is_numeric($m) ? $p . '%' : '-'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div style="background: #f9f9f9; padding: 15px; border-left: 4px solid #004a99; margin-bottom: 20px;">
                <strong>Teacher Remarks:</strong>
                <?php
                $rem = $summary_data[$current_term]['remarks'] ?? 'No remarks available.';
                $teach = $summary_data[$current_term]['teacher_name'] ?? 'Class Teacher';
                echo htmlspecialchars($rem);
                ?>
                <br>
                <small style="color: #666;">- Signed by: <?php echo htmlspecialchars($teach); ?></small>
            </div>

            <div style="height: 300px; width: 100%;">
                <canvas id="resultChart"></canvas>
            </div>
        </div>

        <div id="Attendance" class="tab-content">
            <h3 style="color:#004a99;">Daily Attendance Record</h3>
            <?php if (empty($att_data)): ?>
                <p>No attendance records found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($att_data as $att): ?>
                            <tr>
                                <td><?php echo date('F j, Y', strtotime($att['attendance_date'])); ?></td>
                                <td class="status-<?php echo $att['status']; ?>">
                                    <?php echo htmlspecialchars($att['status']); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <div id="Announcements" class="tab-content">
            <h3 style="color:#004a99;">School Notice Board</h3>
            <?php if (empty($news_data)): ?>
                <p>No announcements at this time.</p>
            <?php else: ?>
                <?php foreach ($news_data as $news): ?>
                    <div class="notice-item">
                        <span class="notice-title"><?php echo htmlspecialchars($news['title']); ?></span>
                        <span class="notice-date"><?php echo date('M d, Y h:i A', strtotime($news['post_date'])); ?></span>
                        <p><?php echo nl2br(htmlspecialchars($news['content'])); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

    </div>

    <script>
        // Tab Switching Logic
        function openTab(evt, tabName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
                tabcontent[i].classList.remove('active');
            }
            tablinks = document.getElementsByClassName("tab-btn");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
            }
            document.getElementById(tabName).style.display = "block";
            document.getElementById(tabName).classList.add('active');
            evt.currentTarget.className += " active";
        }

        // Render Chart
        const ctx = document.getElementById('resultChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{
                    label: 'Percentage (%)',
                    data: <?php echo json_encode($data_points); ?>,
                    backgroundColor: '#004a99',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    </script>

</body>

</html>