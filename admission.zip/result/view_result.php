<?php
session_start(); // Start the session
$pageTitle = "Student Results"; // This will set the "active" class in your header
include '../header.php'; // Use main site header
include 'db.php';

// --- THIS IS THE FIX ---
// Get student data from the SESSION, not the URL
if (!isset($_SESSION['student_data']) || !isset($_SESSION['term_name'])) {
    // If session data is missing, redirect to login
    header("Location: /chiniot/result/index.php?error=session_expired");
    exit;
}

$student = $_SESSION['student_data'];
$student_id = (int)$student['student_id'];
$term_name_from_session = $_SESSION['term_name'];
$year_session = date('Y'); // We'll just use the current year
// --- END OF FIX ---


// 1. Student Info is already in $student variable
if (!isset($student['class_id'])) {
    $class_stmt = $conn->prepare("
        SELECT c.class_id, c.report_template 
        FROM classes c 
        WHERE ? LIKE CONCAT('%', c.class_name, '%')
    ");
    $class_stmt->bind_param("s", $student['class']);
    $class_stmt->execute();
    $class_data = $class_stmt->get_result()->fetch_assoc();
    $student['class_id'] = $class_data['class_id'] ?? 0;
    $class_stmt->close();
}

// 2. Define Terms
$all_terms = ['1st QUARTERLY', 'MID TERM', '2nd QUARTERLY', 'FINAL TERM'];
$results_data = [];
$summary_data = [];

// 3. Get All Subjects for this student's class
$subjects_stmt = $conn->prepare("
    SELECT s.subject_id, s.subject_name 
    FROM class_subjects cs
    JOIN subjects s ON cs.subject_id = s.subject_id
    WHERE cs.class_id = ?
    ORDER BY s.subject_id
");
$subjects_stmt->bind_param("i", $student['class_id']);
$subjects_stmt->execute();
$subjects_result = $subjects_stmt->get_result();
$subjects = [];
while ($row = $subjects_result->fetch_assoc()) {
    $subjects[$row['subject_id']] = $row['subject_name'];
}
$subjects_stmt->close();


// 4. Get ALL Results and Summaries for the year
foreach ($all_terms as $term) {
    // Get individual subject results
    $res_stmt = $conn->prepare("
        SELECT subject_id, marks_obtained, total_marks 
        FROM results 
        WHERE student_id = ? AND term_name = ?
    ");
    $res_stmt->bind_param("is", $student_id, $term);
    $res_stmt->execute();
    $res_result = $res_stmt->get_result();

    $term_results = [];
    while ($row = $res_result->fetch_assoc()) {
        $term_results[$row['subject_id']] = $row;
    }
    $results_data[$term] = $term_results;
    $res_stmt->close();

    // Get summary data
    $sum_stmt = $conn->prepare(
        "SELECT * FROM summaries 
        WHERE student_id = ? AND term_name = ?"
    );
    $sum_stmt->bind_param("is", $student_id, $term);
    $sum_stmt->execute();
    $summary_data[$term] = $sum_stmt->get_result()->fetch_assoc();
    $sum_stmt->close();
}

$conn->close();

// --- Data for the graph ---
$js_subject_labels = [];
$js_subject_percents = [];
if (isset($results_data[$term_name_from_session])) {
    foreach ($subjects as $sub_id => $sub_name) {
        $marks = $results_data[$term_name_from_session][$sub_id]['marks_obtained'] ?? 0;
        $total = $results_data[$term_name_from_session][$sub_id]['total_marks'] ?? 0;
        $percent = ($total > 0) ? ($marks / $total) * 100 : 0;

        $js_subject_labels[] = $sub_name;
        $js_subject_percents[] = $percent;
    }
}
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    /* These styles are now inside the main page body */
    .report-card {
        max-width: 800px;
        margin: auto;
        background: #fff;
        border: 1px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-top: 30px;
        /* Added margin from header */
    }

    .report-header {
        /* Renamed from .header to avoid conflicts */
        display: flex;
        align-items: center;
        padding: 20px;
        border-bottom: 2px solid #004a99;
    }

    .report-header img {
        height: 80px;
        margin-right: 20px;
    }

    .report-header h1 {
        color: #004a99;
        margin: 0;
        font-size: 20px;
    }

    .report-header h2 {
        margin: 0;
        font-size: 16px;
        color: #555;
    }

    .title {
        text-align: center;
        background: #004a99;
        color: white;
        padding: 10px;
        font-size: 24px;
        font-weight: bold;
    }

    .student-info {
        padding: 20px;
        border-bottom: 1px solid #eee;
    }

    .info-table {
        width: 100%;
        border-collapse: collapse;
    }

    .info-table td {
        padding: 5px;
        font-size: 14px;
    }

    .info-table td:first-child {
        font-weight: bold;
        width: 100px;
    }

    .content {
        padding: 20px;
    }

    .term-title {
        font-size: 18px;
        font-weight: bold;
        color: #004a99;
        border-bottom: 1px solid #ccc;
        padding-bottom: 5px;
        margin-bottom: 15px;
    }

    .results-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
    }

    .results-table th,
    .results-table td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: center;
        font-size: 14px;
    }

    .results-table th {
        background: #f2f2f2;
    }

    .results-table .subject-name {
        text-align: left;
        font-weight: bold;
    }

    .summary-section {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }

    .summary-table {
        width: 100%;
        border-collapse: collapse;
    }

    .summary-table th {
        background: #004a99;
        color: white;
        padding: 8px;
        font-size: 16px;
    }

    .summary-table td {
        border: 1px solid #ccc;
        padding: 8px;
        font-size: 14px;
    }

    .summary-table td:first-child {
        font-weight: bold;
        background: #f2f2f2;
    }

    .graph-container {
        width: 100%;
        height: 250px;
    }

    @media print {
        body {
            background: #fff;
            padding: 0;
        }

        .report-card {
            box-shadow: none;
            border: none;
            max-width: 100%;
            margin-top: 0;
        }

        .summary-section {
            grid-template-columns: 1fr;
        }

        /* Hide main nav on print */
        .header,
        .nav,
        .footer {
            display: none;
        }
    }
</style>

<div class="report-card">
    <div class="report-header">
        <img src="/chiniot/img/logos.png" alt="School Logo">
        <div>
            <h1>CHINIOT ISLAMIA PUBLIC SCHOOL & COLLEGE</h1>
            <h2>E-REPORT CARD</h2>
        </div>
    </div>
    <div class="title">
        E-REPORT CARD <?php echo htmlspecialchars($year_session); ?>
    </div>

    <div class="student-info">
        <table class="info-table">
            <tr>
                <td>S.NO:</td>
                <td><?php echo htmlspecialchars($student['student_id']); ?></td>
                <td>GENDER:</td>
                <td><?php echo htmlspecialchars($student['gender']); ?></td>
            </tr>
            <tr>
                <td>NAME:</td>
                <td><?php echo htmlspecialchars($student['name']); ?></td>
                <td>CLASS:</td>
                <td><?php echo htmlspecialchars($student['class']); ?></td>
            </tr>
            <tr>
                <td>F.NAME:</td>
                <td colspan="3"><?php echo htmlspecialchars($student['f_name']); ?></td>
            </tr>
        </table>
    </div>

    <div class="content">
        <div class="term-title">1st Quarterly / MID TERM</div>
        <table class="results-table">
            <thead>
                <tr>
                    <th>SUBJECTS</th>
                    <th>1st QUARTERLY MARKS</th>
                    <th>%</th>
                    <th>MID TERM MARKS</th>
                    <th>%</th>
                </tr>
            </thead>
            <tbody id="subject-data-tbody">
                <?php
                foreach ($subjects as $sub_id => $sub_name):
                    // Data for 1st Quarterly
                    $q1_marks = $results_data['1st QUARTERLY'][$sub_id]['marks_obtained'] ?? '0.00';
                    $q1_total = $results_data['1st QUARTERLY'][$sub_id]['total_marks'] ?? '0';
                    $q1_percent = ($q1_total > 0) ? ($q1_marks / $q1_total) * 100 : 0;

                    // Data for Mid Term
                    $mid_marks = $results_data['MID TERM'][$sub_id]['marks_obtained'] ?? '0.00';
                    $mid_total = $results_data['MID TERM'][$sub_id]['total_marks'] ?? '0';
                    $mid_percent = ($mid_total > 0) ? ($mid_marks / $mid_total) * 100 : 0;
                ?>
                    <tr>
                        <td class="subject-name"><?php echo $sub_name; ?></td>
                        <td><?php echo $q1_marks; ?></td>
                        <td><?php echo number_format($q1_percent, 2); ?>%</td>
                        <td><?php echo $mid_marks; ?></td>
                        <td><?php echo number_format($mid_percent, 2); ?>%</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="summary-section">
            <div>
                <table class="summary-table">
                    <thead>
                        <tr>
                            <th colspan="3">SUMMARY</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td><b>1st QUARTERLY</b></td>
                            <td><b>MID TERM</b></td>
                        </tr>
                        <tr>
                            <td>OUT OF MARKS</td>
                            <td><?php echo $summary_data['1st QUARTERLY']['out_of_marks'] ?? '0'; ?></td>
                            <td><?php echo $summary_data['MID TERM']['out_of_marks'] ?? '0'; ?></td>
                        </tr>
                        <tr>
                            <td>OBTAINED MARKS</td>
                            <td><?php echo $summary_data['1st QUARTERLY']['obtained_marks'] ?? '0.00'; ?></td>
                            <td><?php echo $summary_data['MID TERM']['obtained_marks'] ?? '0.00'; ?></td>
                        </tr>
                        <tr>
                            <td>PERCENTAGE</td>
                            <td><?php echo $summary_data['1st QUARTERLY']['percentage'] ?? '0.00'; ?>%</td>
                            <td><?php echo $summary_data['MID TERM']['percentage'] ?? '0.00'; ?>%</td>
                        </tr>
                        <tr>
                            <td>RANK</td>
                            <td><?php echo htmlspecialchars($summary_data['1st QUARTERLY']['rank'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($summary_data['MID TERM']['rank'] ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td>GRADE</td>
                            <td><?php echo htmlspecialchars($summary_data['1st QUARTERLY']['grade'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($summary_data['MID TERM']['grade'] ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td>ATTENDANCE</td>
                            <td><?php echo htmlspecialchars($summary_data['1st QUARTERLY']['attendance'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($summary_data['MID TERM']['attendance'] ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td>REMARKS</td>
                            <td><?php echo htmlspecialchars($summary_data['1st QUARTERLY']['remarks'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($summary_data['MID TERM']['remarks'] ?? '-'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="graph-container">
                <canvas id="subjectGraph"></canvas>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const ctx = document.getElementById('subjectGraph').getContext('2d');

        const subjectLabels = <?php echo json_encode($js_subject_labels); ?>;
        const subjectData = <?php echo json_encode($js_subject_percents); ?>;

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: subjectLabels,
                datasets: [{
                    label: '<?php echo htmlspecialchars($term_name_from_session); ?> %',
                    data: subjectData,
                    backgroundColor: 'rgba(0, 74, 153, 0.6)', // Blue
                    borderColor: 'rgba(0, 74, 153, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%'
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true
                    },
                    title: {
                        display: true,
                        text: 'Subject Percentage (<?php echo htmlspecialchars($term_name_from_session); ?>)'
                    }
                }
            }
        });
    });
</script>

<?php
// We must go UP one directory to include the main site footer
include '../footer.php';
?>