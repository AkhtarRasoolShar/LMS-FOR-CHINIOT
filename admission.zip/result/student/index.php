<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check DB path
if (file_exists('../db.php')) {
    require '../db.php';
} else {
    die("Database configuration missing.");
}

if (file_exists('../../header.php')) {
    include '../../header.php';
}

if (isset($_SESSION['student_id'])) {
    echo "<script>window.location.href='dashboard.php';</script>";
    exit;
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = (int)$_POST['student_id'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $student = $result->fetch_assoc();

        if (empty($student['password_hash'])) {
            $error = "Account not created yet. <a href='register.php'>Register here</a>.";
        } elseif (password_verify($password, $student['password_hash'])) {
            if ($student['is_fee_paid'] == 0) {
                $error = "Login blocked. Please clear your outstanding fees.";
            } else {
                $_SESSION['student_id'] = $student['student_id'];
                $_SESSION['student_name'] = $student['name'];
                $_SESSION['student_class'] = $student['class'];
                echo "<script>window.location.href='dashboard.php';</script>";
                exit;
            }
        } else {
            $error = "Invalid Password.";
        }
    } else {
        $error = "Student ID not found.";
    }
    $stmt->close();
}
?>
<div class="container-padded" style="max-width: 400px; margin: 60px auto;">
    <form method="POST" style="background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 20px rgba(0,0,0,0.1); border-top: 5px solid #004a99;">
        <div style="text-align: center; margin-bottom: 20px;">
            <img src="../../logos.png" alt="Logo" style="width: 80px;">
            <h2 style="color: #004a99; margin-top: 10px;">Student Portal</h2>
        </div>

        <?php if ($error) echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px; text-align: center;'>$error</div>"; ?>

        <div class="form-group">
            <label style="font-weight: bold; color: #555;">Student ID (SN)</label>
            <input type="text" name="student_id" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 15px;">
        </div>

        <div class="form-group">
            <label style="font-weight: bold; color: #555;">Password</label>
            <input type="password" name="password" required style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; margin-bottom: 20px;">
        </div>

        <button type="submit" style="width: 100%; background: #004a99; color: white; padding: 12px; border: none; border-radius: 4px; font-size: 16px; font-weight: bold; cursor: pointer;">Login</button>

        <div style="margin-top: 15px; text-align: center;">
            <a href="register.php" style="color: #666; text-decoration: none;">First time? <strong>Create Account</strong></a>
        </div>
    </form>
</div>

<?php
if (file_exists('../../footer.php')) {
    include '../../footer.php';
}
?>