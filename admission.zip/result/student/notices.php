<?php
$pageTitle = "Notice Board";
include 'header_student.php';

// Get Class ID for Teacher Notices
$class_name = $current_student['class'];
$c_stmt = $conn->prepare("SELECT class_id FROM classes WHERE ? LIKE CONCAT('%', class_name, '%') LIMIT 1");
$c_stmt->bind_param("s", $class_name);
$c_stmt->execute();
$c_res = $c_stmt->get_result();
$class_id = ($c_res->num_rows > 0) ? $c_res->fetch_assoc()['class_id'] : 0;

// Fetch Notices
$class_notices = [];
if ($class_id > 0) {
    $sql = "SELECT ca.*, t.full_name as teacher_name FROM class_announcements ca 
            LEFT JOIN teacher t ON ca.teacher_id = t.teacher_id 
            WHERE ca.class_id = $class_id ORDER BY ca.publish_date DESC";
    $res = $conn->query($sql);
    while ($row = $res->fetch_assoc()) {
        $class_notices[] = $row;
    }
}

$admin_notices = $conn->query("SELECT * FROM announcements ORDER BY post_date DESC LIMIT 20");
?>

<style>
    .notice-item {
        border-left: 5px solid #ddd;
        background: #fff;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        border-radius: 4px;
    }

    .notice-teacher {
        border-left-color: #004a99;
    }

    .notice-admin {
        border-left-color: #28a745;
    }

    .notice-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
        color: #555;
        font-size: 12px;
        text-transform: uppercase;
        font-weight: bold;
    }

    .notice-title {
        font-size: 18px;
        color: #333;
        margin: 0 0 5px 0;
    }
</style>

<div class="card" style="background:transparent; box-shadow:none; padding:0; border:none;">

    <h3 style="color:#004a99; margin-top:0;">From Teachers</h3>
    <?php if (!empty($class_notices)): foreach ($class_notices as $n): ?>
            <div class="notice-item notice-teacher">
                <div class="notice-header">
                    <span><i class="fas fa-user-tie"></i> <?php echo htmlspecialchars($n['teacher_name']); ?></span>
                    <span><?php echo date("d M Y", strtotime($n['publish_date'])); ?></span>
                </div>
                <h4 class="notice-title"><?php echo htmlspecialchars($n['title']); ?></h4>
                <p style="color:#666; line-height:1.5;"><?php echo nl2br(htmlspecialchars($n['message'])); ?></p>
            </div>
        <?php endforeach;
    else: ?>
        <p style="color:#888; font-style:italic;">No notices from teachers.</p>
    <?php endif; ?>

    <h3 style="color:#28a745; margin-top:30px;">School Announcements</h3>
    <?php if ($admin_notices->num_rows > 0): while ($n = $admin_notices->fetch_assoc()): ?>
            <div class="notice-item notice-admin">
                <div class="notice-header">
                    <span><i class="fas fa-school"></i> Administration</span>
                    <span><?php echo date("d M Y", strtotime($n['post_date'])); ?></span>
                </div>
                <h4 class="notice-title"><?php echo htmlspecialchars($n['title']); ?></h4>
                <p style="color:#666; line-height:1.5;"><?php echo nl2br(htmlspecialchars($n['content'])); ?></p>
            </div>
        <?php endwhile;
    else: ?>
        <p style="color:#888; font-style:italic;">No general announcements.</p>
    <?php endif; ?>

</div>

</div>
</div>
</body>

</html>