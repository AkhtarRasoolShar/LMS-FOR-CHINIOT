<?php
// Secure this page!
include 'admin_check.php'; // This includes db.php

$logged_in_teacher_id = $_SESSION['teacher_id'];
$message = '';
$error = '';

// --- 1. Get the Summary ID from the URL ---
if (!isset($_GET['summary_id'])) {
    die("Error: No summary ID provided.");
}
$summary_id = (int)$_GET['summary_id'];


// --- 2. Handle Form Submission (Update) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = (int)$_POST['student_id'];
    $term_name = $_POST['term_name'];
    $is_locked_status = (int)$_POST['is_locked'];

    // Security check: Is this result still unlocked AND assigned to this teacher/class?
    // We check against the submitted lock status to prevent tampering.
    if ($is_locked_status == 1) {
        $error = "Error: This result was locked by an administrator and cannot be updated.";
    } else {
        $conn->begin_transaction();
        try {
            // Update the marks in the 'results' table
            $subject_ids = $_POST['subject_id'];
            $marks_obtained = $_POST['marks_obtained'];
            $total_marks = $_POST['total_marks'];
            $unannounced_tests = $_POST['unannounced_test'];

            $stmt_results = $conn->prepare("
                UPDATE results SET marks_obtained = ?, total_marks = ?, unannounced_test = ? 
                WHERE student_id = ? AND term_name = ? AND subject_id = ?
            ");

            for ($i = 0; $i < count($subject_ids); $i++) {
                $current_subject_id = (int)$subject_ids[$i];
                $ua_test_score = !empty($unannounced_tests[$i]) ? $unannounced_tests[$i] : NULL;

                $stmt_results->bind_param("diisi", $marks_obtained[$i], $total_marks[$i], $ua_test_score, $student_id, $term_name, $current_subject_id);
                $stmt_results->execute();
            }
            $stmt_results->close();

            // Update the summary table (re-lock it after editing)
            $stmt_summary = $conn->prepare("
                UPDATE summaries SET obtained_marks = ?, out_of_marks = ?, percentage = ?, rank = ?, grade = ?, attendance = ?, remarks = ?, is_locked = 1
                WHERE summary_id = ? AND teacher_id = ?
            ");

            $stmt_summary->bind_param(
                "ddisissii",
                $_POST['summary_obtained'],
                $_POST['summary_outof'],
                $_POST['summary_percentage'],
                $_POST['summary_rank'],
                $_POST['summary_grade'],
                $_POST['summary_attendance'],
                $_POST['summary_remarks'],
                $summary_id,
                $logged_in_teacher_id
            );
            $stmt_summary->execute();
            $stmt_summary->close();

            $conn->commit();
            $message = "Success! Result updated and relocked.";
        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            $error = "Update Failed: " . $e->getMessage();
        }
    }
}


// --- 3. Fetch Data for Display (Summary and Marks) ---
$stmt_summary = $conn->prepare("
    SELECT s.*, st.name AS student_name, st.f_name, c.class_name 
    FROM summaries s
    JOIN students st ON s.student_id = st.student_id
    JOIN classes c ON st.class = c.class_name
    WHERE s.summary_id = ? AND s.teacher_id = ?
");
$stmt_summary->bind_param("ii", $summary_id, $logged_in_teacher_id);
$stmt_summary->execute();
$summary_data = $stmt_summary->get_result()->fetch_assoc();
$stmt_summary->close();

if (!$summary_data) {
    die("Error: Result not found or access denied.");
}

$student_id = $summary_data['student_id'];
$term_name = $summary_data['term_name'];
$is_locked = $summary_data['is_locked'];

// Fetch subject results (marks) for this specific summary
$stmt_marks = $conn->prepare("
    SELECT r.marks_obtained, r.total_marks, r.unannounced_test, s.subject_id, s.subject_name
    FROM results r
    JOIN subjects s ON r.subject_id = s.subject_id
    WHERE r.student_id = ? AND r.term_name = ?
    ORDER BY s.subject_name
");
$stmt_marks->bind_param("is", $student_id, $term_name);
$stmt_marks->execute();
$marks_result = $stmt_marks->get_result();

$marks_list = [];
while ($row = $marks_result->fetch_assoc()) {
    $marks_list[] = $row;
}
$stmt_marks->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #006400;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 900px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h2 {
            border-bottom: 2px solid #006400;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .message,
        .error {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
            font-weight: bold;
        }

        .message {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        fieldset {
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            margin-bottom: 20px;
        }

        legend {
            font-weight: bold;
            color: #006400;
            padding: 0 10px;
        }

        .student-info {
            background: #f0f0f0;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            font-size: 1.1em;
        }

        .info-row span {
            font-weight: normal;
            color: #333;
        }

        .grid-4 {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 15px;
            padding-bottom: 5px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #006400;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
        }

        .locked-overlay {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 4px;
            text-align: center;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .locked-field {
            background: #ccc !important;
            cursor: not-allowed;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Edit Submitted Result</h1>
        <a href="edit_dashboard.php">Back to Review</a>
    </div>

    <div class="container">
        <h2>Report for <?php echo htmlspecialchars($summary_data['student_name'] . ' - ' . $term_name); ?></h2>

        <?php if ($message) echo "<p class='message'>$message</p>"; ?>
        <?php if ($error) echo "<p class='error'>$error</p>"; ?>

        <?php if ($is_locked == 1 && empty($error)): ?>
            <div class="locked-overlay">
                This result is currently **LOCKED** by the Administrator. You cannot make any changes.
            </div>
        <?php endif; ?>

        <div class="student-info">
            <div class="info-row"><strong>Student:</strong> <span><?php echo htmlspecialchars($summary_data['student_name']); ?> (S.NO: <?php echo $student_id; ?>)</span></div>
            <div class="info-row"><strong>Class:</strong> <span><?php echo htmlspecialchars($summary_data['class_name']); ?></span></div>
            <div class="info-row"><strong>Term:</strong> <span><?php echo htmlspecialchars($term_name); ?></span></div>
        </div>

        <form action="edit_result_form.php?summary_id=<?php echo $summary_id; ?>" method="POST" onsubmit="calculateTotals()">
            <input type="hidden" name="student_id" value="<?php echo $student_id; ?>">
            <input type="hidden" name="term_name" value="<?php echo htmlspecialchars($term_name); ?>">
            <input type="hidden" name="is_locked" value="<?php echo $is_locked; ?>">

            <fieldset>
                <legend>Subject Marks (Detailed)</legend>
                <div class="grid-4">
                    <strong>Subject Name</strong>
                    <strong>Marks Obtained</strong>
                    <strong>Total Marks</strong>
                    <strong>Unannounced Test (10)</strong>
                </div>
                <hr style="margin-top:0;">

                <?php foreach ($marks_list as $mark):
                    $is_readonly = ($is_locked == 1) ? 'readonly' : '';
                    $locked_class = ($is_locked == 1) ? 'locked-field' : '';
                ?>
                    <div class="grid-4 form-group">
                        <label><?php echo htmlspecialchars($mark['subject_name']); ?></label>
                        <input type="hidden" name="subject_id[]" value="<?php echo $mark['subject_id']; ?>">

                        <input type="number" step="0.01" name="marks_obtained[]" value="<?php echo $mark['marks_obtained']; ?>"
                            class="subject-marks <?php echo $locked_class; ?>" oninput="calculateTotals()" <?php echo $is_readonly; ?>>

                        <input type="number" name="total_marks[]" value="<?php echo $mark['total_marks']; ?>"
                            class="subject-total <?php echo $locked_class; ?>" oninput="calculateTotals()" <?php echo $is_readonly; ?>>

                        <input type="number" step="0.01" name="unannounced_test[]" value="<?php echo $mark['unannounced_test']; ?>"
                            class="<?php echo $locked_class; ?>" <?php echo $is_readonly; ?>>
                    </div>
                <?php endforeach; ?>
            </fieldset>

            <fieldset>
                <legend>Term Summary (Automatically Calculated)</legend>
                <div class="split-4">
                    <div class="form-group"><label>Obtained Marks (Total)</label><input type="number" step="0.01" name="summary_obtained" id="summary_obtained" value="<?php echo $summary_data['obtained_marks']; ?>" readonly class="locked-field"></div>
                    <div class="form-group"><label>Out Of Marks (Total)</label><input type="number" name="summary_outof" id="summary_outof" value="<?php echo $summary_data['out_of_marks']; ?>" readonly class="locked-field"></div>
                    <div class="form-group"><label>Percentage (%)</label><input type="number" step="0.01" name="summary_percentage" id="summary_percentage" value="<?php echo $summary_data['percentage']; ?>" readonly class="locked-field"></div>

                    <div class="form-group">
                        <label>Rank</label>
                        <input type="text" name="summary_rank" value="<?php echo htmlspecialchars($summary_data['rank']); ?>" placeholder="e.g., 1st" <?php echo $is_locked == 1 ? 'readonly class="locked-field"' : ''; ?>>
                    </div>
                </div>
                <div class="split-3">
                    <div class="form-group">
                        <label>Grade</label>
                        <input type="text" name="summary_grade" value="<?php echo htmlspecialchars($summary_data['grade']); ?>" placeholder="e.g., A+" <?php echo $is_locked == 1 ? 'readonly class="locked-field"' : ''; ?>>
                    </div>
                    <div class="form-group">
                        <label>Attendance</label>
                        <input type="number" id="summary_attendance" name="summary_attendance" value="<?php echo $summary_data['attendance']; ?>" readonly class="locked-field">
                    </div>
                    <div class="form-group">
                        <label>Remarks</label>
                        <select name="summary_remarks" <?php echo $is_locked == 1 ? 'disabled class="locked-field"' : ''; ?>>
                            <option value="PASSED" <?php if ($summary_data['remarks'] == 'PASSED') echo 'selected'; ?>>PASSED</option>
                            <option value="FAILED" <?php if ($summary_data['remarks'] == 'FAILED') echo 'selected'; ?>>FAILED</option>
                        </select>
                        <?php if ($is_locked == 1) echo '<input type="hidden" name="summary_remarks" value="' . htmlspecialchars($summary_data['remarks']) . '"/>'; ?>
                    </div>
                </div>
            </fieldset>

            <?php if ($is_locked == 0): ?>
                <button type="submit">
                    <?php echo "Update & Re-Lock Result"; ?>
                </button>
            <?php endif; ?>
        </form>
    </div>

    <script>
        // Get the summary fields
        const obtainedTotalEl = document.getElementById('summary_obtained');
        const outOfTotalEl = document.getElementById('summary_outof');
        const percentageEl = document.getElementById('summary_percentage');

        function calculateTotals() {
            let totalObtained = 0;
            let totalOutOf = 0;

            // Select only editable inputs (non-readonly inputs)
            const subjectMarksInputs = document.querySelectorAll('.subject-marks:not([readonly])');
            const subjectTotalInputs = document.querySelectorAll('.subject-total:not([readonly])');

            // If the report is unlocked, we calculate from current input values
            if (subjectMarksInputs.length > 0) {
                subjectMarksInputs.forEach(input => {
                    totalObtained += parseFloat(input.value) || 0;
                });
                subjectTotalInputs.forEach(input => {
                    totalOutOf += parseFloat(input.value) || 0;
                });

                obtainedTotalEl.value = totalObtained.toFixed(2);
                outOfTotalEl.value = totalOutOf;

                if (totalOutOf > 0) {
                    percentageEl.value = ((totalObtained / totalOutOf) * 100).toFixed(2);
                } else {
                    percentageEl.value = '0.00';
                }
            }
        }

        // Listener for input changes in subject fields
        document.querySelector('.container').addEventListener('input', (e) => {
            if (e.target.classList.contains('subject-marks') || e.target.classList.contains('subject-total')) {
                calculateTotals();
            }
        });

        // Ensure totals are calculated on load since fields are pre-filled
        window.addEventListener('load', calculateTotals);
    </script>

</body>

</html>