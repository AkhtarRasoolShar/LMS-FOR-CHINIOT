<style>
    .footer {
        background-color: #2c3e50;
        /* Dark Slate Blue */
        color: #ecf0f1;
        padding: 30px;
        text-align: center;
        margin-top: 40px;
    }

    .footer p {
        margin: 5px 0;
        font-size: 14px;
    }

    .footer a {
        color: #fff;
        text-decoration: none;
        font-weight: bold;
    }

    .footer a:hover {
        text-decoration: underline;
    }
</style>

<footer class="footer">
    <p>&copy; <?php echo date('Y'); ?> Chiniot Islamia Public School & College. All Rights Reserved.</p>
    <p>
        <a href="/chiniot/index.php">Home</a> |
        <a href="/chiniot/result/index.php">Student Portal</a> |
        <a href="/chiniot/result/admin/admin_login.php">Teacher Portal</a> |
        <a href="/chiniot/result/superadmin/index.php">Admin Panel</a>
    </p>
</footer>

</body>

</html>