<?php
include 'admin_check.php'; // Includes security and sets $logged_in_user_id

// Only Super Admins
if ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'superadmin') {
    die("Access Denied.");
}

// Stats queries
$students_count = $conn->query("SELECT COUNT(*) as count FROM students")->fetch_assoc()['count'];
$teachers_count = $conn->query("SELECT COUNT(*) as count FROM teachers WHERE role = 'teacher'")->fetch_assoc()['count'];
$classes_count = $conn->query("SELECT COUNT(*) as count FROM classes")->fetch_assoc()['count'];

// --- GET PENDING REQUESTS COUNT ---
$pending_requests_count_result = $conn->query("SELECT COUNT(*) as count FROM result_edit_requests WHERE status = 'Pending'");
$pending_requests_count = $pending_requests_count_result->fetch_assoc()['count'];

// --- Get unread contact messages count ---
$messages_count_result = $conn->query("SELECT COUNT(*) as count FROM contact_messages WHERE is_read = 0");
$messages_count = $messages_count_result->fetch_assoc()['count'];

// --- GET PENDING ADMISSION CHECKUP COUNT (Paid but Pending Final Approval) ---
// This query requires the 'approval_status' column to be present in the applicants table.
$admission_checkup_count_result = $conn->query("SELECT COUNT(*) as count FROM applicants WHERE payment_status = 1 AND approval_status = 'Pending'");
$admission_checkup_count = $admission_checkup_count_result->fetch_assoc()['count'];

// --- GET FINALIZED STUDENTS COUNT (Approved but potentially still locked) ---
$approved_students_count_result = $conn->query("SELECT COUNT(*) as count FROM applicants WHERE approval_status = 'Approved'");
$approved_students_count = $approved_students_count_result->fetch_assoc()['count'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Super Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7f6;
            margin: 0;
        }

        .header {
            background: #004d40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 20px;
        }

        .grid-item {
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            padding: 25px;
            text-decoration: none;
            color: #333;
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
        }

        .grid-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 77, 64, 0.1);
            color: #004d40;
        }

        .grid-item .count {
            display: block;
            font-size: 36px;
            color: #004d40;
            margin-bottom: 10px;
        }

        .badge {
            position: absolute;
            top: -10px;
            right: -10px;
            background: #e53935;
            color: white;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            line-height: 30px;
            font-size: 14px;
        }

        .grid-item.attention {
            background: #fff3e0;
            border: 1px solid #ffcc80;
            color: #ff9800;
        }

        .grid-item.attention:hover {
            color: #d84315;
            box-shadow: 0 6px 15px rgba(255, 152, 0, 0.3);
        }

        .grid-item.data-review {
            background: #e6f7e6;
            border: 1px solid #c3e6cb;
        }

        .grid-item.data-review:hover {
            color: #155724;
            box-shadow: 0 6px 15px rgba(40, 167, 69, 0.2);
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Super Admin Dashboard</h1>
        <span>Welcome, <?php echo htmlspecialchars($logged_in_user_name); ?></span>
        <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <div class="grid-container">

            <a href="check_new_admission.php" class="grid-item attention">
                <?php if ($admission_checkup_count > 0): ?>
                    <span class="badge"><?php echo $admission_checkup_count; ?></span>
                <?php endif; ?>
                Admission Checkup
            </a>

            <a href="view_approved_students.php" class="grid-item data-review">
                <span class="count"><?php echo $approved_students_count; ?></span>
                Finalized Students
            </a>

            <a href="manage_admissions.php" class="grid-item">
                Manage Admissions
            </a>

            <a href="manage_edit_requests.php" class="grid-item attention">
                <?php if ($pending_requests_count > 0): ?>
                    <span class="badge"><?php echo $pending_requests_count; ?></span>
                <?php endif; ?>
                Result Edit Requests
            </a>

            <a href="view_messages.php" class="grid-item">
                <?php if ($messages_count > 0): ?>
                    <span class="badge"><?php echo $messages_count; ?></span>
                <?php endif; ?>
                Contact Messages
            </a>

            <a href="manage_applicants.php" class="grid-item">
                Manage Applicants
            </a>
            <a href="manage_students.php" class="grid-item">
                <span class="count"><?php echo $students_count; ?></span>
                Manage Students
            </a>
            <a href="manage_enrollment.php" class="grid-item">
                Manage Enrollment Status
            </a>
            <a href="manage_teachers.php" class="grid-item">
                <span class="count"><?php echo $teachers_count; ?></span>
                Manage Teachers
            </a>
            <a href="manage_classes.php" class="grid-item">
                <span class="count"><?php echo $classes_count; ?></span>
                Manage Classes
            </a>
            <a href="manage_subjects.php" class="grid-item">
                Manage Subjects
            </a>
            <a href="manage_assignments.php" class="grid-item">
                Manage Assignments
            </a>

            <a href="send_message.php" class="grid-item">
                Send Admin Message
            </a>
            <a href="manage_locks.php" class="grid-item">
                Manage Result Locks
            </a>
            <a href="view_all_results_by_year.php" class="grid-item">
                View All Results
            </a>
        </div>
    </div>
</body>

</html>