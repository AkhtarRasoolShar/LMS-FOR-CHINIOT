<?php
// download_pdf_primary.php
// Loads mPDF and generates the Primary Section report.

// 1. Load the Composer autoloader (which loads mPDF)
require_once __DIR__ . '/vendor/autoload.php';

// 2. Include the database connection
include 'db.php';

// 3. Get the student ID from the URL (e.g., download_pdf.php?id=3225)
if (isset($_GET['id'])) {
    $student_id = (int)$_GET['id'];
} else {
    die("Error: No Student ID provided.");
}

// 4. Fetch Student's Personal Information
$stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student_result = $stmt->get_result();
if ($student_result->num_rows == 0) {
    die("Error: No student found with S.NO: $student_id");
}
$student = $student_result->fetch_assoc();

// 5. Fetch ALL Subject Marks
$sql_marks = "
    SELECT s.subject_name, r.term_name, r.marks_obtained, r.total_marks, r.unannounced_test
    FROM results r
    JOIN subjects s ON r.subject_id = s.subject_id
    WHERE r.student_id = ?
    ORDER BY s.subject_id, r.term_name
";
$stmt_marks = $conn->prepare($sql_marks);
$stmt_marks->bind_param("i", $student_id);
$stmt_marks->execute();
$marks_result = $stmt_marks->get_result();

$marks_by_subject = [];
while ($row = $marks_result->fetch_assoc()) {
    $marks_by_subject[$row['subject_name']][$row['term_name']] = [
        'marks' => $row['marks_obtained'],
        'total' => $row['total_marks'],
        'ua_test' => $row['unannounced_test']
    ];
}

// 6. Fetch Summary Data (1st and 2nd Term)
$sql_summary = "SELECT * FROM summaries WHERE student_id = ? AND (term_name = 'MID TERM' OR term_name = 'FINAL TERM')";
$stmt_summary = $conn->prepare($sql_summary);
$stmt_summary->bind_param("i", $student_id);
$stmt_summary->execute();
$summary_result = $stmt_summary->get_result();
$summary_data = [];
while ($row = $summary_result->fetch_assoc()) {
    $summary_data[$row['term_name']] = $row;
}

// 7. Get a list of all subjects
$subjects_result = $conn->query("SELECT subject_name FROM subjects ORDER BY subject_id");
$subjects_list = [];
while ($row = $subjects_result->fetch_assoc()) {
    $subjects_list[] = $row['subject_name'];
}
$conn->close();

// 8. ======================================================
//    PRIMARY SECTION CALCULATIONS (2nd Term)
//    ======================================================
$calculated_data = [];
$total_final_term_weighted = 0;
$total_out_of_final = 0;

foreach ($subjects_list as $subject) {
    $marks_2q = $marks_by_subject[$subject]['2nd QUARTERLY']['marks'] ?? 0;
    $marks_ua = $marks_by_subject[$subject]['FINAL TERM']['ua_test'] ?? 0;
    $marks_final = $marks_by_subject[$subject]['FINAL TERM']['marks'] ?? 0;
    $total_final = $marks_by_subject[$subject]['FINAL TERM']['total'] ?? 100;

    if ($total_final > 0) {
        $weight_5_ua = ($marks_ua / 10) * 5;
        $weight_10_2q = ($marks_2q / 40) * 10;
        $weight_85_final = ($marks_final / 100) * 85;
        $weighted_total = $weight_5_ua + $weight_10_2q + $weight_85_final;
        $total_final_term_weighted += $weighted_total;
        $total_out_of_final += 100;
    }
    $calculated_data[$subject] = [
        'marks_2q' => $marks_2q,
        'marks_ua' => $marks_ua,
        'marks_final' => $marks_final,
        'weight_5_ua' => $weight_5_ua ?? 0,
        'weight_10_2q' => $weight_10_2q ?? 0,
        'weight_85_final' => $weight_85_final ?? 0,
        'weighted_total' => $weighted_total ?? 0,
    ];
}

// 9. ======================================================
//    FINAL 50/50 CALCULATIONS
//    ======================================================
$marks_1st_term = $summary_data['MID TERM']['obtained_marks'] ?? 0;
$marks_2nd_term = $total_final_term_weighted;
$out_of_1st_term = $summary_data['MID TERM']['out_of_marks'] ?? 0;
$out_of_2nd_term = $total_out_of_final;

$sum_1st_term_50 = 0;
if ($out_of_1st_term > 0) {
    $sum_1st_term_50 = ($marks_1st_term / $out_of_1st_term) * ($out_of_2nd_term * 0.5);
}
$sum_2nd_term_50 = $marks_2nd_term * 0.5;
$final_50_50_sum = $sum_1st_term_50 + $sum_2nd_term_50;

$final_percentage = 0;
if ($out_of_2nd_term > 0) {
    $final_percentage = ($final_50_50_sum / $out_of_2nd_term) * 100;
}

// 10. Start output buffering
// This "catches" all the HTML below
ob_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Primary Section E-Report</title>
    <style>
        /* This is the same CSS from view_result_primary.php */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
        }

        .report-card {
            width: 1000px;
            margin: 0 auto;
            background: #fff;
            border: 2px solid #333;
            padding: 20px;
        }

        .header {
            text-align: center;
            line-height: 1.2;
        }

        .header h1 {
            color: #006400;
            margin: 0;
        }

        .header h2 {
            color: #333;
            margin: 5px 0;
        }

        .header h3 {
            background: #006400;
            color: white;
            padding: 5px;
            margin: 10px 0;
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }

        .info-table td {
            padding: 4px;
        }

        .info-table .label {
            font-weight: bold;
            width: 80px;
        }

        .info-table .value {
            border-bottom: 1px solid #333;
        }

        .marks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        .marks-table th,
        .marks-table td {
            border: 1px solid #333;
            padding: 5px;
            text-align: center;
            font-size: 12px;
        }

        .marks-table th {
            background: #f2f2f2;
        }

        .marks-table .subject-name {
            text-align: left;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: 1.5fr 1fr;
            gap: 20px;
            margin-top: 15px;
        }

        .summary-table {
            width: 100%;
            border-collapse: collapse;
        }

        .summary-table td {
            border: 1px solid #333;
            padding: 5px;
            font-size: 12px;
        }

        .summary-table .label {
            font-weight: bold;
        }

        .summary-table .value {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="report-card">
        <div class="header">
            <h1>Chiniot Islamia Public School & College</h1>
            <h2>PRIMARY SECTION</h2>
            <h3>2nd Term Examination Result 2024-25</h3>
        </div>

        <table class="info-table">
            <tr>
                <td class="label">Class</td>
                <td class="value"><?php echo htmlspecialchars($student['class']); ?></td>
                <td class="label" style="width: 50px;">S.No</td>
                <td class="value" style="width: 100px;"><?php echo htmlspecialchars($student['student_id']); ?></td>
            </tr>
            <tr>
                <td class="label">Name</td>
                <td class="value" colspan="3"><?php echo htmlspecialchars($student['name']); ?></td>
            </tr>
            <tr>
                <td class="label">D/o</td>
                <td class="value" colspan="3"><?php echo htmlspecialchars($student['f_name']); ?></td>
            </tr>
        </table>

        <table class="marks-table">
            <thead>
                <tr>
                    <th>Subjects</th>
                    <th>2nd Qt. (40)</th>
                    <th>Unannounced Test (10)</th>
                    <th>2nd Term (100)</th>
                    <th>5% weightage of Unannounced</th>
                    <th>10% weightage of 2nd Qt.</th>
                    <th>2nd Term Reduced to 85%</th>
                    <th>Total of 2nd Term (100)</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($subjects_list as $subject): $data = $calculated_data[$subject]; ?>
                    <tr>
                        <td class="subject-name"><?php echo htmlspecialchars($subject); ?></td>
                        <td><?php echo number_format($data['marks_2q'], 2); ?></td>
                        <td><?php echo number_format($data['marks_ua'], 2); ?></td>
                        <td><?php echo number_format($data['marks_final'], 2); ?></td>
                        <td><?php echo number_format($data['weight_5_ua'], 2); ?></td>
                        <td><?php echo number_format($data['weight_10_2q'], 2); ?></td>
                        <td><?php echo number_format($data['weight_85_final'], 2); ?></td>
                        <td><?php echo number_format($data['weighted_total'], 2); ?></td>
                        <td><?php echo $summary_data['FINAL TERM']['remarks'] ?? 'N/A'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="summary-grid">
            <div>
                <table class="summary-table">
                    <tr>
                        <td class="label">Marks Obtained 2nd Term</td>
                        <td class="value"><?php echo number_format($total_final_term_weighted, 0); ?></td>
                        <td class="label">Out of</td>
                        <td class="value"><?php echo number_format($total_out_of_final, 0); ?></td>
                        <td class="label" rowspan="2">Rank</td>
                        <td class="value" rowspan="2"><?php echo $summary_data['FINAL TERM']['rank'] ?? 'N/A'; ?></td>
                    </tr>
                    <tr>
                        <td class="label">Marks Obtained 1st Term</td>
                        <td class="value"><?php echo $summary_data['MID TERM']['obtained_marks'] ?? 'N/A'; ?></td>
                        <td class="label">Out of</td>
                        <td class="value"><?php echo $summary_data['MID TERM']['out_of_marks'] ?? 'N/A'; ?></td>
                    </tr>
                    <tr>
                        <td class="label">Sum of 50% of 1st & 2nd Term</td>
                        <td class="value"><?php echo number_format($final_50_50_sum, 0); ?></td>
                        <td class="label" colspan="2"></td>
                        <td class="label" rowspan="2">Grade</td>
                        <td class="value" rowspan="2"><?php echo $summary_data['FINAL TERM']['grade'] ?? 'N/A'; ?></td>
                    </tr>
                    <tr>
                        <td class="label">Percentage</td>
                        <td class="value"><?php echo number_format($final_percentage, 1); ?>%</td>
                        <td class="label" colspan="2"></td>
                    </tr>
                </table>
            </div>
            <div>
                <table class="summary-table">
                    <tr>
                        <td class="label" colspan="3">Attendance</td>
                    </tr>
                    <tr>
                        <td class="label">No. of days</td>
                        <td class="value"><?php echo ($summary_data['MID TERM']['attendance'] ?? 0) + ($summary_data['FINAL TERM']['attendance'] ?? 0); ?></td>
                    </tr>
                    <tr>
                        <td class="label">Present</td>
                        <td class="value"><?php echo $summary_data['FINAL TERM']['attendance'] ?? 'N/A'; ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</body>

</html>

<?php
// 11. Get the "caught" HTML
$html = ob_get_clean();

// 12. Generate the PDF
try {
    // Create new mPDF instance
    $mpdf = new \Mpdf\Mpdf([
        'mode' => 'utf-8',
        'format' => 'A4-L', // 'A4-L' for Landscape, which this report needs
        'margin_top' => 10,
        'margin_left' => 10,
        'margin_right' => 10,
        'margin_bottom' => 10,
    ]);

    // Write the HTML to the PDF
    $mpdf->WriteHTML($html);

    // Set a filename and force download
    $filename = "Report_Card_Primary_" . $student['student_id'] . ".pdf";
    $mpdf->Output($filename, 'D'); // 'D' = Force Download

} catch (\Mpdf\MpdfException $e) {
    echo "Error generating PDF: " . $e->getMessage();
}

exit;
?>