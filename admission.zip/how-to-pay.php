<?php
$pageTitle = "How to Pay";
include 'header.php';
?>
<style>
    .admission-header {
        text-align: center;
        margin: 20px auto;
        padding: 0 20px;
        max-width: 900px;
    }

    .admission-header h2 {
        font-size: 18px;
        color: #555;
        margin: 0;
        font-weight: normal;
    }

    .admission-header h1 {
        font-size: 36px;
        color: #006400;
        margin: 5px 0 15px 0;
    }

    .admission-nav {
        background: #f8f9fa;
        border-bottom: 1px solid #ddd;
        border-top: 1px solid #ddd;
        text-align: center;
        margin-bottom: 30px;
    }

    .admission-nav ul {
        margin: 0;
        padding: 0;
        list-style: none;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
    }

    .admission-nav li {
        display: inline-block;
    }

    .admission-nav a {
        display: block;
        padding: 15px 20px;
        text-decoration: none;
        color: #006400;
        font-weight: bold;
        font-size: 16px;
        border-bottom: 3px solid transparent;
    }

    .admission-nav a:hover {
        background: #e9ecef;
    }

    .admission-nav a.active {
        border-bottom-color: #006400;
        color: #333;
        background: #e9ecef;
    }

    .content-page {
        max-width: 900px;
        margin: 0 auto 30px auto;
        padding: 30px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        font-size: 16px;
        line-height: 1.7;
        color: #333;
    }

    .kuickpay-link {
        display: inline-block;
        padding: 12px 20px;
        background: #006400;
        color: #fff;
        text-decoration: none;
        font-weight: bold;
        border-radius: 5px;
        margin-top: 10px;
    }

    .payment-info {
        background: #fdfdfd;
        border: 1px solid #eee;
        padding: 20px;
        border-radius: 5px;
    }

    .payment-info li {
        font-size: 18px;
    }

    .payment-split {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 30px;
    }

    .payment-example {
        background: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 15px;
    }

    .payment-example h5 {
        margin: 0 0 10px 0;
        font-size: 16px;
    }

    .payment-example ol {
        font-size: 14px;
        padding-left: 18px;
    }

    @media (max-width: 768px) {
        .admission-nav ul {
            flex-direction: column;
        }

        .admission-nav a {
            border-bottom: 1px solid #ddd;
        }

        .admission-nav a.active {
            border-bottom-color: #006400;
        }

        .payment-split {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="admission-header">
    <h2>Chiniot Islamia Public School & College</h2>
    <h1>Admissions</h1>
</div>

<nav class="admission-nav">
    <ul>
        <li><a href="admission-procedure.php">Admission Procedure</a></li>
        <li><a href="admissions.php">Admission Form</a></li>
        <li><a href="fee-structure.php">Fee Structure</a></li>
        <li><a href="admission-policy.php">Admission Policy</a></li>
        <li><a href="admission-faqs.php">FAQs</a></li>
        <li><a href="how-to-pay.php" class="active">How to Pay Fee Bill</a></li>
        <li><a href="uniform.php">Uniform</a></li>
    </ul>
</nav>

<div class="content-page">
    <h2>How to Pay Your Fee Bill</h2>
    <p>You can pay your fee bill using Kuickpay through any major Internet/Mobile Banking app, ATM, or Over-the-Counter (OTC) at a partner bank branch.</p>
    <p>Please click below to know the payment process, or follow the guide.</p>
    <a href="https://app.kuickpay.com/PaymentsBillPayment" target="_blank" class="kuickpay-link">Visit Kuickpay Payment Portal</a>
    <h3 style="margin-top: 40px;">Payment Instructions</h3>
    <p>To pay your bill, you will need two pieces of information:</p>
    <div class="payment-info">
        <ul>
            <li><strong>Company/Institution:</strong> <strong>Chiniot Islamia Public School</strong></li>
            <li><strong>Consumer Number:</strong> <strong>00950XXXXXXX</strong><br><small>(Where XXXXXXX is your child's Registration/Account Number)</small></li>
        </ul>
    </div>
    <h3>Step 1: Choose Your Payment Method</h3>
    <p>You can pay through any of the partners listed below.</p>
    <div class="payment-split">
        <div>
            <h4>Digital Partner Banks (Mobile/Internet)</h4>
            <ul>
                <li>Allied Bank, Al Baraka Bank, Askari Bank</li>
                <li>Bank AL Habib, Bank Alfalah, BankIslami</li>
                <li>Bank of Khyber (BOK), Bank of Punjab (BOP)</li>
                <li>Dubai Islamic Bank (DIB), Digitt+</li>
                <li>EasyPaisa App, Faysal Bank, First Women Bank</li>
                <li>HabibMetro Bank (HMB), HBL, JazzCash App</li>
                <li>JS Bank, Keenu App, MCB bank, MCB Islamic Bank</li>
                <li>Meezan Bank, National Bank of Pakistan (NBP)</li>
                <li>NRSP Bank, SAMBA Bank, SilkBank, Soneri Bank</li>
                <li>Bank Makramah Limited (BML), UBL, Standard Chartered Bank (SCB)</li>

            </ul>
        </div>
        <div>
            <h4>Over the Counter (OTC) Partners</h4>
            <p>You can also pay in cash at any branch of the following partners:</p>
            <ul>
                <li>TCS</li>
                <li>Meezan Bank</li>
                <li>HabibMetro Bank</li>
                <li>Al Baraka Bank</li>
                <li>NRSP Bank</li>
                <li>UBL Omni</li>
                <li>EasyPaisa</li>
                <li>JazzCash</li>
            </ul>
            <h4 style="margin-top: 30px;">Example: How to Pay with JazzCash App</h4>
            <div class="payment-example">
                <h5>Mobile App:</h5>
                <ol>
                    <li>Login to your JazzCash Mobile App</li>
                    <li>Select "Corporate Payments" or "Bill Payment"</li>
                    <li>Select "Kuickpay"</li>
                    <li>Enter Consumer ID: <strong>00950XXXXXXX</strong> and fetch details</li>
                    <li>Verify the amount and student name</li>
                    <li>Enter your MPIN and proceed to pay</li>
                </ol>
            </div>
        </div>
    </div>
    <h3 style="margin-top: 40px;">Have Questions?</h3>
    <p>Contact us on <strong>WhatsApp (+92-335-8425729)</strong></p>
</div>
<?php include 'footer.php'; ?>