<?php
$pageTitle = "Enter Marks (Single Student)";
include 'header_teacher.php';

// Check if class/subject selected
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$subject_id = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;

// If submitting marks
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $term = $_POST['term'];
    $year = $_POST['year'];
    $total = $_POST['total_marks'];
    $obtained = $_POST['obtained_marks'];

    // Update or Insert
    $check = $conn->query("SELECT result_id FROM results WHERE student_id=$student_id AND subject_id=$subject_id AND term_name='$term' AND session_year='$year'");

    if ($check->num_rows > 0) {
        $sql = "UPDATE results SET marks_obtained='$obtained', total_marks='$total' WHERE student_id=$student_id AND subject_id=$subject_id AND term_name='$term' AND session_year='$year'";
    } else {
        $sql = "INSERT INTO results (student_id, subject_id, term_name, session_year, marks_obtained, total_marks) VALUES ($student_id, $subject_id, '$term', '$year', '$obtained', '$total')";
    }

    if ($conn->query($sql)) {
        echo "<script>alert('Marks Saved!'); window.location.href='enter_marks_single.php?class_id=$class_id&subject_id=$subject_id';</script>";
    } else {
        echo "<div class='alert alert-danger'>Error saving marks.</div>";
    }
}

// Fetch Class & Subject Name
if ($class_id && $subject_id) {
    $info = $conn->query("SELECT c.class_name, s.subject_name FROM classes c, subjects s WHERE c.class_id=$class_id AND s.subject_id=$subject_id")->fetch_assoc();
    $students = $conn->query("SELECT * FROM students WHERE class LIKE '{$info['class_name']}' ORDER BY name ASC");
}
?>

<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h3 style="margin:0; color:#004a99;">
            <?php echo $class_id ? $info['subject_name'] . ' (' . $info['class_name'] . ')' : 'Select Class & Subject'; ?>
        </h3>
        <a href="dashboard.php" class="btn-warning" style="text-decoration:none; padding:8px 15px; border-radius:4px;">Back to Dashboard</a>
    </div>

    <?php if ($class_id && $subject_id): ?>
        <table style="width:100%; border-collapse:collapse;">
            <tr style="background:#f8f9fa; text-align:left; border-bottom:2px solid #ddd;">
                <th style="padding:10px;">Roll No</th>
                <th style="padding:10px;">Name</th>
                <th style="padding:10px;">Father Name</th>
                <th style="padding:10px;">Action</th>
            </tr>
            <?php while ($s = $students->fetch_assoc()): ?>
                <tr style="border-bottom:1px solid #eee;">
                    <td style="padding:10px;"><?php echo $s['student_id']; ?></td>
                    <td style="padding:10px; font-weight:bold;"><?php echo htmlspecialchars($s['name']); ?></td>
                    <td style="padding:10px; color:#666;"><?php echo htmlspecialchars($s['f_name']); ?></td>
                    <td style="padding:10px;">
                        <button onclick="openModal('<?php echo $s['student_id']; ?>', '<?php echo addslashes($s['name']); ?>')" class="btn-primary" style="padding:5px 10px; font-size:12px;">
                            <i class="fas fa-edit"></i> Add Marks
                        </button>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p style="text-align:center; color:#666;">Please select a subject from your <a href="dashboard.php">Dashboard</a> first.</p>
    <?php endif; ?>
</div>

<div id="markModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000;">
    <div style="background:white; width:400px; margin:100px auto; padding:20px; border-radius:8px; position:relative;">
        <span onclick="document.getElementById('markModal').style.display='none'" style="position:absolute; top:10px; right:15px; cursor:pointer; font-size:20px;">&times;</span>
        <h3 style="margin-top:0;">Enter Marks for <span id="modalName" style="color:#004a99;"></span></h3>

        <form method="POST">
            <input type="hidden" name="student_id" id="modalID">

            <label style="font-weight:bold; display:block; margin-bottom:5px;">Session Year</label>
            <select name="year" class="form-control" style="width:100%; padding:8px; margin-bottom:15px;">
                <?php for ($y = date('Y'); $y >= 2023; $y--) echo "<option value='$y'>$y</option>"; ?>
            </select>

            <label style="font-weight:bold; display:block; margin-bottom:5px;">Term</label>
            <select name="term" class="form-control" style="width:100%; padding:8px; margin-bottom:15px;">
                <option>1st QUARTERLY</option>
                <option>MID TERM</option>
                <option>2nd QUARTERLY</option>
                <option>FINAL TERM</option>
            </select>

            <div style="display:flex; gap:10px; margin-bottom:20px;">
                <div style="flex:1;">
                    <label style="font-weight:bold; display:block;">Total</label>
                    <input type="number" name="total_marks" value="100" style="width:100%; padding:8px;" required>
                </div>
                <div style="flex:1;">
                    <label style="font-weight:bold; display:block;">Obtained</label>
                    <input type="number" step="any" name="obtained_marks" style="width:100%; padding:8px;" required>
                </div>
            </div>

            <button type="submit" class="btn-primary" style="width:100%; padding:10px;">Save Result</button>
        </form>
    </div>
</div>

<script>
    function openModal(id, name) {
        document.getElementById('modalID').value = id;
        document.getElementById('modalName').innerText = name;
        document.getElementById('markModal').style.display = 'block';
    }
</script>

</div>
</div>
</body>

</html>