<?php
include 'db.php'; // DB connection
session_start();

if (!isset($_SESSION['teacher_id'])) {
    echo json_encode(['present_days' => 'Auth Error']);
    exit;
}

$student_id = (int)$_POST['student_id'];
$term_name = $_POST['term_name'];

// Determine date range based on term
$year = date('Y');
$start_date = '';
$end_date = '';

// Define your school's term dates
switch ($term_name) {
    case '1st QUARTERLY':
        $start_date = "$year-04-01";
        $end_date = "$year-05-31";
        break;
    case 'MID TERM':
        $start_date = "$year-08-01";
        $end_date = "$year-10-31";
        break;
    case '2nd QUARTERLY':
        $start_date = "$year-11-01";
        $end_date = "$year-12-31";
        break;
    case 'FINAL TERM':
        $start_date = "$year-01-01";
        $end_date = "$year-03-31";
        break;
    default:
        echo json_encode(['present_days' => 'N/A']);
        exit;
}

$stmt = $conn->prepare("
    SELECT COUNT(attendance_id) AS present_count 
    FROM attendance 
    WHERE student_id = ? 
    AND status = 'Present' 
    AND attendance_date BETWEEN ? AND ?
");
$stmt->bind_param("iss", $student_id, $start_date, $end_date);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$present_days = $row['present_count'] ?? 0;

$stmt->close();
$conn->close();

header('Content-Type: application/json');
echo json_encode(['present_days' => $present_days]);
