<?php
session_start();
require '../db.php';
include 'header_student.php';

if (!isset($_SESSION['student_id'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit;
}

$student_id = $_SESSION['student_id'];

// --- YEAR SELECTION LOGIC ---
// Default to current year if not selected
$selected_year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// Generate Year List (Current Year down to 2022)
$current_year = date('Y');
$years = range($current_year, 2022);

// 1. Fetch Student Details
$stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();
$stmt->close();

// 2. Fetch Attendance (Filtered by Year)
$att_sql = "SELECT * FROM attendance 
            WHERE student_id = $student_id 
            AND YEAR(attendance_date) = '$selected_year' 
            ORDER BY attendance_date DESC LIMIT 30";
$att_res = $conn->query($att_sql);
// Calculate Present Count for this year
$total_present = $conn->query("SELECT COUNT(*) as cnt FROM attendance WHERE student_id = $student_id AND status='Present' AND YEAR(attendance_date) = '$selected_year'")->fetch_assoc()['cnt'];

// 3. Fetch Notices (General, not year specific usually)
$news_res = $conn->query("SELECT * FROM announcements ORDER BY post_date DESC LIMIT 5");

// 4. Fetch Results (Filtered by Session Year)
$terms = ['1st QUARTERLY', 'MID TERM', '2nd QUARTERLY', 'FINAL TERM'];
$exam_data = [];

foreach ($terms as $t) {
    $safe_term = $conn->real_escape_string($t);
    $q = $conn->query("SELECT * FROM summaries 
                       WHERE student_id = $student_id 
                       AND term_name = '$safe_term' 
                       AND session_year = '$selected_year'");
    $exam_data[$t] = ($q && $q->num_rows > 0) ? $q->fetch_assoc() : null;
}
?>

<style>
    /* Stats Grid */
    .stat-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .stat-card {
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        text-align: center;
        border-bottom: 4px solid #ddd;
    }

    .stat-number {
        font-size: 32px;
        font-weight: bold;
        margin: 10px 0;
        color: #333;
    }

    .stat-label {
        color: #777;
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    /* Year Filter */
    .filter-bar {
        background: white;
        padding: 15px 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    }

    .year-select {
        padding: 8px 15px;
        border-radius: 4px;
        border: 1px solid #ddd;
        font-size: 16px;
        background: #f9f9f9;
        cursor: pointer;
    }

    /* Tabs & Tables */
    .tabs {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
        border-bottom: 2px solid #eee;
    }

    .tab-btn {
        padding: 12px 25px;
        border: none;
        background: none;
        font-size: 16px;
        color: #666;
        cursor: pointer;
        font-weight: 600;
        border-bottom: 3px solid transparent;
        transition: 0.3s;
    }

    .tab-btn.active {
        color: #004a99;
        border-bottom-color: #004a99;
    }

    .tab-content {
        display: none;
        animation: fadeIn 0.3s;
    }

    .tab-content.active {
        display: block;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(5px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 8px;
        overflow: hidden;
    }

    th {
        background: #f8f9fa;
        color: #333;
        text-align: left;
        padding: 12px;
        border-bottom: 2px solid #ddd;
    }

    td {
        border-bottom: 1px solid #eee;
        padding: 12px;
    }

    .badge-Present {
        background: #d4edda;
        color: #155724;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
    }

    .badge-Absent {
        background: #f8d7da;
        color: #721c24;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
    }

    .badge-Leave {
        background: #fff3cd;
        color: #856404;
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: bold;
    }
</style>

<div class="filter-bar">
    <h3 style="margin:0; color:#004a99;">Dashboard</h3>
    <form method="GET" style="display:flex; align-items:center;">
        <label style="margin-right: 10px; font-weight:bold; color:#555;">Select Year:</label>
        <select name="year" class="year-select" onchange="this.form.submit()">
            <?php foreach ($years as $y): ?>
                <option value="<?php echo $y; ?>" <?php echo ($y == $selected_year) ? 'selected' : ''; ?>>
                    <?php echo $y . ' - ' . ($y + 1); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>
</div>

<div class="stat-grid">
    <div class="stat-card" style="border-color: #28a745;">
        <div class="stat-label">Days Present (<?php echo $selected_year; ?>)</div>
        <div class="stat-number" style="color: #28a745;"><?php echo $total_present; ?></div>
    </div>
    <div class="stat-card" style="border-color: #004a99;">
        <div class="stat-label">Exams Taken</div>
        <div class="stat-number" style="color: #004a99;"><?php echo count(array_filter($exam_data)); ?></div>
    </div>
    <div class="stat-card" style="border-color: #ffc107;">
        <div class="stat-label">New Notices</div>
        <div class="stat-number" style="color: #ffc107;"><?php echo $news_res->num_rows; ?></div>
    </div>
</div>

<div class="card">
    <div class="tabs">
        <button class="tab-btn active" onclick="openTab(event, 'Results')">Results</button>
        <button class="tab-btn" onclick="openTab(event, 'Attendance')">Attendance</button>
        <button class="tab-btn" onclick="openTab(event, 'Notices')">Notices</button>
    </div>

    <div id="Results" class="tab-content active">
        <table>
            <thead>
                <tr>
                    <th>Term</th>
                    <th>Obtained</th>
                    <th>Total</th>
                    <th>%</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($terms as $t): $data = $exam_data[$t]; ?>
                    <tr>
                        <td style="font-weight:bold;"><?php echo $t; ?></td>
                        <td><?php echo $data ? $data['obtained_marks'] : '-'; ?></td>
                        <td><?php echo $data ? $data['out_of_marks'] : '-'; ?></td>
                        <td><?php echo ($data && isset($data['percentage'])) ? $data['percentage'] . '%' : '-'; ?></td>
                        <td>
                            <?php if ($data): ?>
                                <a href="view_result.php?term=<?php echo urlencode($t); ?>&year=<?php echo $selected_year; ?>" class="btn btn-primary" style="padding:5px 10px; font-size:12px;">View Card</a>
                            <?php else: ?>
                                <span style="color:#999; font-size:12px;">N/A</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div id="Attendance" class="tab-content">
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($att_res && $att_res->num_rows > 0):
                    while ($row = $att_res->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo date("d M Y", strtotime($row['attendance_date'])); ?></td>
                            <td><span class="badge-<?php echo $row['status']; ?>"><?php echo $row['status']; ?></span></td>
                        </tr>
                    <?php endwhile;
                else: ?>
                    <tr>
                        <td colspan="2" style="text-align:center;">No attendance data for <?php echo $selected_year; ?>.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="Notices" class="tab-content">
        <?php
        if ($news_res && $news_res->num_rows > 0):
            while ($news = $news_res->fetch_assoc()): ?>
                <div style="border-bottom: 1px solid #eee; padding: 15px 0;">
                    <strong style="color: #333; display:block; margin-bottom:5px;"><?php echo htmlspecialchars($news['title']); ?></strong>
                    <span style="font-size: 12px; color: #888;"><?php echo date("d M Y", strtotime($news['post_date'])); ?></span>
                    <p style="margin:5px 0 0; color:#555; font-size:14px;"><?php echo nl2br(htmlspecialchars($news['content'])); ?></p>
                </div>
            <?php endwhile;
        else: ?>
            <p style="text-align:center; padding:20px; color:#777;">No notices found.</p>
        <?php endif; ?>
    </div>

</div>

<script>
    function openTab(evt, tabName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tab-content");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
            tabcontent[i].classList.remove('active');
        }
        tablinks = document.getElementsByClassName("tab-btn");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabName).style.display = "block";
        setTimeout(() => document.getElementById(tabName).classList.add('active'), 10);
        evt.currentTarget.className += " active";
    }
</script>

</div>
</div>
</body>

</html>