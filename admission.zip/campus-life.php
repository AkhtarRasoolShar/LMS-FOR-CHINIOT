<?php
$pageTitle = "Campus Life";
include 'header.php';
?>

<style>
    .facility-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
    }

    .facility-card {
        border: 1px solid #ddd;
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        overflow: hidden;
        text-align: center;
        text-decoration: none;
        color: #333;
        transition: transform 0.2s, box-shadow 0.2s;
    }

    .facility-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    .facility-card h4 {
        margin: 0;
        padding: 15px;
        background: #006400;
        color: white;
    }

    .facility-card p {
        padding: 15px;
        font-size: 14px;
        min-height: 50px;
    }

    .gallery-links {
        list-style: none;
        padding-left: 0;
    }

    .gallery-links li {
        margin-bottom: 10px;
    }

    .gallery-links a {
        text-decoration: none;
        color: #006400;
        font-weight: bold;
    }
</style>

<div class="container">
    <h2>Our Facilities</h2>
    <p>We provide a wide range of facilities to ensure a comfortable and effective learning environment for our students.</p>

    <div class="facility-grid">
        <a href="library.php" class="facility-card">
            <h4>School Library</h4>
            <p>A rich collection of over 13,000 books managed by qualified staff.</p>
        </a>
        <a href="mosque.php" class="facility-card">
            <h4>Mosque</h4>
            <p>A dedicated mosque on campus for students and staff to offer prayers.</p>
        </a>
        <a href="sick-room.php" class="facility-card">
            <h4>Sick Room</h4>
            <p>A well-equipped sick room with first-aid facilities to care for students.</p>
        </a>
        <div class="facility-card">
            <h4>Laboratories</h4>
            <p>State-of-the-art science labs for physics, chemistry, and biology.</p>
        </div>
        <div class="facility-card">
            <h4>Canteen & Tuck Shop</h4>
            <p>Hygienic and healthy food and snacks for students during breaks.</p>
        </div>
        <div class="facility-card">
            <h4>Sports Ground</h4>
            <p>Spacious grounds for sports and our Annual Sports Gala.</p>
        </div>
    </div>

    <h3>Pictorial Gallery</h3>
    <p>A glimpse into the vibrant student life at Chiniot Islamia Public School & College. Click a link to see photos:</p>
    <ul class="gallery-links">
        <li><a href="gallery.php#sports">Sports Gala</a></li>
        <li><a href="gallery.php#scouts">Scout Camp</a></li>
        <li><a href="gallery.php#open-day">Open Day</a></li>
        <li><a href="gallery.php#prize-distribution">Prize Distribution</a></li>
        <li><a href="gallery.php#class-activity">Class Activity</a></li>
    </ul>

</div>

<?php include 'footer.php'; ?>