<?php
// Start the session
session_start();

// --- SECURITY CHECK ---
// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: portal.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Challan - Chiniot Islamia Public School & College</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

    <header>
        <div class="container">
            <a href="index.php" class="logo">Chiniot School</a>
            <nav class="main-nav">
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="messages.php">Messages</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="page-header">
        <div class="container">
            <h1>Fee Challan</h1>
        </div>
    </section>

    <section class="page-content">
        <div class="container">

            <div class="challan-container">
                <div class="challan-header">
                    <h2>Chiniot Islamia Public School & College</h2>
                    <p>FEE CHALLAN (BANK COPY)</p>
                </div>

                <div class="challan-details">
                    <div class="detail-group">
                        <strong>Student Name:</strong> Ahmad <?php echo htmlspecialchars(explode(' ', $_SESSION["full_name"])[0]); ?><br>
                        <strong>Parent Name:</strong> <?php echo htmlspecialchars($_SESSION["full_name"]); ?><br>
                        <strong>Class:</strong> V-B
                    </div>
                    <div class="detail-group" style="text-align: right;">
                        <strong>Challan No:</strong> 1025-001A<br>
                        <strong>Issue Date:</strong> Oct 28, 2025<br>
                        <strong>Due Date:</strong> Nov 05, 2025
                    </div>
                </div>

                <table class="fee-table">
                    <thead>
                        <tr>
                            <th>Description</th>
                            <th>Amount (PKR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Tuition Fee (November)</td>
                            <td>8,500.00</td>
                        </tr>
                        <tr>
                            <td>Computer Lab Fee</td>
                            <td>1,000.00</td>
                        </tr>
                        <tr>
                            <td>Sports Fund</td>
                            <td>500.00</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Total Amount Due</th>
                            <th>PKR 10,000.00</th>
                        </tr>
                    </tfoot>
                </table>

                <div class="challan-footer">
                    <p>Please pay this challan at any HBL branch before the due date to avoid a late fee of PKR 500.</p>
                    <button class="cta-button" onclick="window.print()">
                        <i class="fa-solid fa-print"></i> Print Challan
                    </button>
                </div>
            </div>

        </div>
    </section>

    <footer>
        <div class="footer-bottom">
            <p>&copy; <?php echo date("Y"); ?> Chiniot Islamia Public School & College. All Rights Reserved.</p>
        </div>
    </footer>

</body>

</html>