<?php
include 'admin_check.php'; // Secure this page

$message = '';

// --- Handle adding a new notice ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_notice'])) {
    $title = $_POST['title'];
    $content = $_POST['content'];

    $stmt = $conn->prepare("INSERT INTO announcements (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);

    if ($stmt->execute()) {
        $message = "Success! Notice has been posted.";
    } else {
        $message = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// --- Handle deleting a notice ---
if (isset($_GET['delete'])) {
    $notice_id = (int)$_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM announcements WHERE notice_id = ?");
    $stmt->bind_param("i", $notice_id);

    if ($stmt->execute()) {
        $message = "Notice has been deleted.";
    } else {
        $message = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// --- Get list of all notices ---
$notices_result = $conn->query("SELECT * FROM announcements ORDER BY post_date DESC");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Notice Board</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #b30000;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 900px;
            margin: auto;
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 30px;
        }

        .form-container,
        .table-container {
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h2 {
            border-bottom: 2px solid #b30000;
            padding-bottom: 10px;
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group textarea {
            min-height: 150px;
        }

        button {
            background-color: #b30000;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        .list-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .list-table th,
        .list-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        .list-table th {
            background: #f2f2f2;
        }

        .list-table a {
            color: #b30000;
            text-decoration: none;
        }
    </style>
</head>

<body>

    <div class="header">
        <h1>Manage Notice Board</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">

        <div class="form-container">
            <h2>Add New Notice</h2>
            <?php if ($message): ?>
                <p class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>"><?php echo $message; ?></p>
            <?php endif; ?>

            <form action="manage_notices.php" method="POST">
                <input type="hidden" name="add_notice" value="1">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" required>
                </div>
                <div class="form-group">
                    <label for="content">Content</label>
                    <textarea name="content" required></textarea>
                </div>
                <button type="submit">Post Notice</button>
            </form>
        </div>

        <div class="table-container">
            <h2>Current Notices</h2>
            <table class="list-table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Date Posted</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($notice = $notices_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($notice['title']); ?></td>
                            <td><?php echo date('d-M-Y', strtotime($notice['post_date'])); ?></td>
                            <td>
                                <a href="manage_notices.php?delete=<?php echo $notice['notice_id']; ?>"
                                    onclick="return confirm('Are you sure you want to delete this notice?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

    </div>
</body>

</html>