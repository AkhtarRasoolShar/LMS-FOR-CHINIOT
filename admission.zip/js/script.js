document.addEventListener('DOMContentLoaded', () => {

    // --- Fade-in on Scroll Animation Logic ---

    // Check if IntersectionObserver is supported
    if ('IntersectionObserver' in window) {
        // Create the observer
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                // If the element is in view
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    // Stop observing it once it's visible
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1 // Trigger when 10% of the element is visible
        });

        // Get all elements with the .fade-in class
        const elementsToFade = document.querySelectorAll('.fade-in');

        // Observe each element
        elementsToFade.forEach(el => {
            observer.observe(el);
        });
    }

});