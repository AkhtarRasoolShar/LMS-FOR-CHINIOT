<?php
// Start the session
session_start();

// --- SECURITY CHECK ---
// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: portal.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance - Chiniot Islamia Public School & College</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

    <header>
        <div class="container">
            <a href="index.php" class="logo">Chiniot School</a>
            <nav class="main-nav">
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="messages.php">Messages</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <section class="page-header">
        <div class="container">
            <h1>Attendance Record</h1>
        </div>
    </section>

    <section class="page-content">
        <div class="container">

            <div class="attendance-container">
                <div class="attendance-header">
                    <h3>Student: Ahmad <?php echo htmlspecialchars(explode(' ', $_SESSION["full_name"])[0]); ?></h3>
                    <p>Showing record for: <strong>October 2025</strong></p>
                </div>

                <div class="attendance-summary">
                    <div class="summary-box present">
                        <span class="count">19</span>
                        <span>Days Present</span>
                    </div>
                    <div class="summary-box absent">
                        <span class="count">1</span>
                        <span>Day Absent</span>
                    </div>
                    <div class="summary-box leave">
                        <span class="count">1</span>
                        <span>On Leave</span>
                    </div>
                </div>

                <table class="attendance-table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>October 1, 2025</td>
                            <td><span class="status-present">Present</span></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>October 2, 2025</td>
                            <td><span class="status-present">Present</span></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>October 3, 2025</td>
                            <td><span class="status-absent">Absent</span></td>
                            <td>No note received.</td>
                        </tr>
                        <tr>
                            <td>October 4, 2025</td>
                            <td><span class="status-leave">Leave</span></td>
                            <td>Sick leave application approved.</td>
                        </tr>
                        <tr>
                            <td>October 5, 2025</td>
                            <td><span class="status-present">Present</span></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>October 6, 2025</td>
                            <td><span class="status-present">Present</span></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </div>
    </section>

    <footer>
        <div class="footer-bottom">
            <p>&copy; <?php echo date("Y"); ?> Chiniot Islamia Public School & College. All Rights Reserved.</p>
        </div>
    </footer>

</body>

</html>