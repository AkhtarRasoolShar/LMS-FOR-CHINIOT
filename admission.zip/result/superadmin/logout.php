<?php
session_start();
session_destroy();
// Redirect to the main login page
header("Location: ../admin/admin_login.php");
exit();
