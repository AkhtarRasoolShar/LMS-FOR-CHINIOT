<?php
$pageTitle = "Message Sent";
include 'header.php';
?>

<style>
    /* This uses the .container-padded class from your header.php */
    .thank-you-container {
        text-align: center;
        padding: 50px 20px;
    }

    .thank-you-container .icon {
        font-size: 5em;
        color: #28a745;
        /* Green */
    }

    .thank-you-container h2 {
        color: #004a99;
        /* Blue */
        font-size: 2.5em;
        margin-bottom: 15px;
    }

    .thank-you-container p {
        font-size: 1.2em;
        line-height: 1.7;
        color: #333;
    }

    .back-link {
        display: inline-block;
        margin-top: 30px;
        padding: 12px 25px;
        background-color: #004a99;
        /* Blue */
        color: white;
        text-decoration: none;
        font-weight: bold;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .back-link:hover {
        background-color: #003b7a;
    }
</style>

<div class="container-padded">
    <div class="thank-you-container">
        <div class="icon">
            <i class="fa-solid fa-circle-check"></i>
        </div>
        <h2>Thank You!</h2>
        <p>Your message has been sent successfully.</p>
        <p>Our team will review it and get back to you as soon as possible.</p>
        <a href="index.php" class="back-link">Back to Home</a>
    </div>
</div>

<?php include 'footer.php'; ?>