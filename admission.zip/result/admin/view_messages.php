<?php
// Secure this page!
include 'admin_check.php'; // This includes session and db connection (../db.php)

$logged_in_teacher_id = $_SESSION['teacher_id'];

// Fetch messages sent to THIS teacher OR to ALL teachers (recipient_teacher_id IS NULL)
$stmt = $conn->prepare("
    SELECT sender_name, subject, message_body, sent_at 
    FROM teacher_messages 
    WHERE recipient_teacher_id = ? OR recipient_teacher_id IS NULL
    ORDER BY sent_at DESC
");
$stmt->bind_param("i", $logged_in_teacher_id);
$stmt->execute();
$messages_result = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Messages</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #006400;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 900px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .message-list {
            list-style-type: none;
            padding: 0;
        }

        .message-item {
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 15px;
            background: #fff;
        }

        .message-header {
            background: #f7f7f7;
            padding: 10px 15px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .message-header strong {
            font-size: 18px;
            color: #006400;
        }

        .message-header span {
            font-size: 12px;
            color: #777;
        }

        .message-body {
            padding: 15px;
            font-size: 14px;
            line-height: 1.6;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Admin Messages</h1>
        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <ul class="message-list">
            <?php if ($messages_result->num_rows > 0): ?>
                <?php while ($msg = $messages_result->fetch_assoc()): ?>
                    <li class="message-item">
                        <div class="message-header">
                            <strong><?php echo htmlspecialchars($msg['subject']); ?></strong>
                            <span>From: <?php echo htmlspecialchars($msg['sender_name']); ?> on <?php echo date('M j, Y g:i A', strtotime($msg['sent_at'])); ?></span>
                        </div>
                        <div class="message-body">
                            <?php echo nl2br(htmlspecialchars($msg['message_body'])); ?>
                        </div>
                    </li>
                <?php endwhile; ?>
            <?php else: ?>
                <p>You have no messages.</p>
            <?php endif; ?>
        </ul>
    </div>
</body>

</html>