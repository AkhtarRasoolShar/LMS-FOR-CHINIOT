<?php
include 'admin_check.php'; // Includes security and sets $logged_in_user_id

$message = '';
$selected_class_name = $_GET['class'] ?? ''; // Filter by Class Name
$search_term = $_GET['search'] ?? '';          // Search term for Name/ID/Form No

// Handle "Toggle Payment" action (assuming a simple toggle action is needed)
if (isset($_GET['action']) && $_GET['action'] == 'toggle_payment' && isset($_GET['id'])) {
    $applicant_id = (int)$_GET['id'];

    // Toggle payment status
    $conn->query("UPDATE applicants SET payment_status = !payment_status WHERE applicant_id = $applicant_id");

    $message = "Payment status updated for applicant ID: $applicant_id.";
}

// Handle Delete Action
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id_to_delete = (int)$_GET['id'];

    // Logic to delete the record
    $delete_stmt = $conn->prepare("DELETE FROM applicants WHERE applicant_id = ?");
    $delete_stmt->bind_param("i", $id_to_delete);
    if ($delete_stmt->execute()) {
        $message = "Applicant deleted successfully.";
    } else {
        $message = "Error deleting applicant.";
    }
    $delete_stmt->close();
}


// --- Get Full Class List for Dropdown ---
$class_result = $conn->query("SELECT DISTINCT applying_for_class FROM applicants WHERE applying_for_class IS NOT NULL AND applying_for_class != '' ORDER BY applying_for_class");

// --- Build Applicants Query (with Filters) ---
$applicants_query_sql = "SELECT applicant_id, form_no, student_name, father_name, applying_for_class, payment_status, created_at, test_date FROM applicants";
$where_clauses = [];
$params = [];
$param_types = '';

// 1. Class Filter
if (!empty($selected_class_name)) {
    $where_clauses[] = "applying_for_class = ?";
    $params[] = $selected_class_name;
    $param_types .= 's';
}

// 2. Search Filter (by ID, Name, or Form No)
if (!empty($search_term)) {
    $search_term_like = '%' . $search_term . '%';
    $where_clauses[] = "(form_no LIKE ? OR student_name LIKE ? OR father_name LIKE ?)";
    $params[] = $search_term_like;
    $params[] = $search_term_like;
    $params[] = $search_term_like;
    $param_types .= 'sss';
}

if (!empty($where_clauses)) {
    $applicants_query_sql .= " WHERE " . implode(" AND ", $where_clauses);
}

// Sort by newest first
$applicants_query_sql .= " ORDER BY created_at DESC";

// Prepare and execute the final query
$applicants_stmt = $conn->prepare($applicants_query_sql);
if (!empty($params)) {
    $applicants_stmt->bind_param($param_types, ...$params);
}
$applicants_stmt->execute();
$applicants_result = $applicants_stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Applicants</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            margin: 0;
        }

        .header {
            background: #004a99;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            padding: 30px;
            max-width: 1200px;
            margin: auto;
            background: #fff;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .message {
            padding: 10px;
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
        }

        .filter-area {
            display: grid;
            grid-template-columns: 1fr 2fr 100px;
            /* Class filter, Search input, Search button */
            gap: 15px;
            margin-bottom: 20px;
        }

        .filter-area select {
            padding: 10px;
            font-size: 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        .search-group {
            display: flex;
            grid-column: 2 / 4;
        }

        .search-group input {
            padding: 10px;
            font-size: 16px;
            border-radius: 4px 0 0 4px;
            border: 1px solid #ccc;
            flex-grow: 1;
        }

        .search-group button {
            padding: 10px 15px;
            font-size: 16px;
            background: #004a99;
            color: white;
            border: none;
            border-radius: 0 4px 4px 0;
            cursor: pointer;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th,
        .data-table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            font-size: 14px;
        }

        .data-table th {
            background: #f2f2f2;
        }

        .action-links a {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 13px;
            margin-right: 5px;
        }

        .action-view {
            background-color: #007bff;
            color: white;
        }

        .action-delete {
            background-color: #dc3545;
            color: white;
        }

        .paid {
            color: green;
            font-weight: bold;
        }

        .pending {
            color: red;
            font-weight: bold;
        }

        .table-date {
            white-space: nowrap;
            font-size: 12px;
        }

        .status-na {
            color: #555;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Manage Applicants</h1>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>

    <div class="container">
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>

        <form class="filter-area" method="GET" action="manage_applicants.php">

            <select name="class" onchange="this.form.submit()">
                <option value="">-- Filter by Class --</option>
                <?php $class_result->data_seek(0);
                while ($class = $class_result->fetch_assoc()): ?>
                    <option value="<?php echo htmlspecialchars($class['applying_for_class']); ?>" <?php echo ($selected_class_name == $class['applying_for_class']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($class['applying_for_class']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <input type="text" name="search" placeholder="Search by Name, ID, or Form No" value="<?php echo htmlspecialchars($search_term); ?>">
            <button type="submit" class="search-group">Search</button>
        </form>

        <table class="data-table">
            <thead>
                <tr>
                    <th>Form No</th>
                    <th>Student Name</th>
                    <th>Applying for Class</th>
                    <th>Date Received</th>
                    <th>Payment</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($applicants_result->num_rows > 0): ?>
                    <?php while ($row = $applicants_result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['form_no']); ?></td>
                            <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['applying_for_class']); ?></td>
                            <td class="table-date">
                                <?php echo date('M j, Y h:i A', strtotime($row['created_at'])); ?>
                            </td>
                            <td>
                                <span class="<?php echo $row['payment_status'] ? 'paid' : 'pending'; ?>">
                                    <?php echo $row['payment_status'] ? 'Paid' : 'Pending'; ?>
                                </span>
                            </td>
                            <td class="action-links">
                                <a href="view_applicant_details.php?id=<?php echo $row['applicant_id']; ?>" class="action-view">View</a>
                                <a href="manage_applicants.php?action=delete&id=<?php echo $row['applicant_id']; ?>" class="action-delete" onclick="return confirm('Are you sure you want to delete this applicant?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No applicants found matching your criteria.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>

</html>