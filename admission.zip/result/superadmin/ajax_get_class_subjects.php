<?php
// ajax_get_class_subjects.php
// This file is called by JavaScript to fetch subjects for a specific class curriculum.

include 'admin_check.php'; // Includes session and db connection

// Get the class ID from the URL
$class_id = (int)$_GET['class_id'];

if (empty($class_id)) {
    echo json_encode([]); // Send back an empty list
    exit;
}

// --- Fetch all subjects assigned to this class in the curriculum ---
$stmt = $conn->prepare("
    SELECT s.subject_id, s.subject_name
    FROM class_subjects cs
    JOIN subjects s ON cs.subject_id = s.subject_id
    WHERE 
        cs.class_id = ?
    ORDER BY s.subject_name
");
$stmt->bind_param("i", $class_id);
$stmt->execute();
$result = $stmt->get_result();

$subjects = [];
while ($row = $result->fetch_assoc()) {
    $subjects[] = $row;
}
$stmt->close();

// Set the header to return JSON
header('Content-Type: application/json');
// Send the list of subjects back to the JavaScript
echo json_encode($subjects);
exit();
