<?php
$pageTitle = "Mark Attendance";
include 'header_teacher.php';

// ==================================================================
// SCENARIO 1: NO CLASS SELECTED (Show Class Selection List)
// ==================================================================
if (!isset($_GET['class_id']) || empty($_GET['class_id'])) {
    $teacher_id = $_SESSION['teacher_id'];
    $sql = "SELECT DISTINCT c.class_id, c.class_name 
            FROM teacher_assignments ta 
            JOIN classes c ON ta.class_id = c.class_id 
            WHERE ta.teacher_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $teacher_id);
    $stmt->execute();
    $classes = $stmt->get_result();
?>
    <div class="card">
        <h3 style="margin-top:0; color:#004a99;">Select Class for Attendance</h3>
        <p style="color:#666;">Please select a class to mark attendance.</p>

        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px; margin-top:20px;">
            <?php if ($classes->num_rows > 0): while ($c = $classes->fetch_assoc()): ?>
                    <a href="mark_attendance.php?class_id=<?php echo $c['class_id']; ?>" style="text-decoration:none; color:inherit;">
                        <div style="background:#f8f9fa; border:1px solid #ddd; padding:20px; border-radius:8px; text-align:center; border-left:5px solid #ffc107; transition:0.3s;">
                            <strong style="font-size:18px; display:block; margin-bottom:5px; color:#333;">
                                <?php echo htmlspecialchars($c['class_name']); ?>
                            </strong>
                            <span style="color:#004a99; font-size:14px; font-weight:bold;">Mark Attendance <i class="fas fa-arrow-right"></i></span>
                        </div>
                    </a>
                <?php endwhile;
            else: ?>
                <p style="color:red;">No classes assigned to you.</p>
            <?php endif; ?>
        </div>
    </div>
<?php
    include '../../footer.php';
    exit; // STOP HERE
}

// ==================================================================
// SCENARIO 2: CLASS SELECTED (Show Attendance Form)
// ==================================================================
$class_id = (int)$_GET['class_id'];
$date = isset($_POST['date']) ? $_POST['date'] : date('Y-m-d');

// Check Class Name
$stmt = $conn->prepare("SELECT class_name FROM classes WHERE class_id = ?");
$stmt->bind_param("i", $class_id);
$stmt->execute();
$c_res = $stmt->get_result();

if ($c_res->num_rows === 0) die("<div class='card text-danger'>Invalid Class ID.</div>");
$class_name = $c_res->fetch_assoc()['class_name'];

// Handle Save
$msg = '';
if (isset($_POST['save_attendance']) && isset($_POST['status'])) {
    foreach ($_POST['status'] as $sid => $status) {
        $conn->query("DELETE FROM attendance WHERE student_id=$sid AND attendance_date='$date'");
        $conn->query("INSERT INTO attendance (student_id, attendance_date, status) VALUES ($sid, '$date', '$status')");
    }
    $msg = "<div class='alert' style='background:#d4edda; color:#155724; padding:10px; border-radius:4px; margin-bottom:15px;'>Attendance Saved!</div>";
}

// Fetch Students
$students = $conn->query("SELECT * FROM students WHERE class LIKE CONCAT('%', '$class_name', '%') ORDER BY name ASC");
?>

<style>
    .radio-label {
        margin-right: 15px;
        cursor: pointer;
        font-weight: 500;
    }

    .radio-label input {
        margin-right: 5px;
    }

    .p-col {
        color: green;
    }

    .a-col {
        color: red;
    }

    .l-col {
        color: orange;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        padding: 10px;
        border-bottom: 1px solid #eee;
    }

    th {
        background: #f8f9fa;
        text-align: left;
    }
</style>

<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; border-bottom:1px solid #eee; padding-bottom:10px;">
        <h3 style="margin:0; color:#333;">Attendance: <?php echo htmlspecialchars($class_name); ?></h3>
        <form method="POST" style="display:flex; align-items:center; gap:10px;">
            <label>Date:</label>
            <input type="date" name="date" value="<?php echo $date; ?>" class="form-control" style="padding:5px;" onchange="this.form.submit()">
        </form>
    </div>

    <?php echo $msg; ?>

    <form method="POST" action="mark_attendance.php?class_id=<?php echo $class_id; ?>">
        <input type="hidden" name="date" value="<?php echo $date; ?>">
        <input type="hidden" name="save_attendance" value="1">

        <table>
            <thead>
                <tr>
                    <th>Roll No</th>
                    <th>Student Name</th>
                    <th style="text-align:center;">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($students->num_rows > 0): while ($std = $students->fetch_assoc()):
                        $chk = $conn->query("SELECT status FROM attendance WHERE student_id={$std['student_id']} AND attendance_date='$date'");
                        $st = ($chk->num_rows > 0) ? $chk->fetch_assoc()['status'] : 'Present';
                ?>
                        <tr>
                            <td><?php echo $std['student_id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($std['name']); ?></strong></td>
                            <td style="text-align:center;">
                                <label class="radio-label p-col"><input type="radio" name="status[<?php echo $std['student_id']; ?>]" value="Present" <?php if ($st == 'Present') echo 'checked'; ?>> P</label>
                                <label class="radio-label a-col"><input type="radio" name="status[<?php echo $std['student_id']; ?>]" value="Absent" <?php if ($st == 'Absent') echo 'checked'; ?>> A</label>
                                <label class="radio-label l-col"><input type="radio" name="status[<?php echo $std['student_id']; ?>]" value="Leave" <?php if ($st == 'Leave') echo 'checked'; ?>> L</label>
                            </td>
                        </tr>
                    <?php endwhile;
                else: ?>
                    <tr>
                        <td colspan="3" style="text-align:center; padding:20px; color:red;">No students found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div style="text-align:right; margin-top:20px;">
            <button type="submit" class="btn-primary" style="padding:10px 25px;">Save Attendance</button>
        </div>
    </form>
</div>
<?php include '../../footer.php'; ?>