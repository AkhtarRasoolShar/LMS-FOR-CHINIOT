<?php
require 'db.php'; // Connect to the database

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['form_no'])) {
    $form_no = $_POST['form_no'];

    // Prepare statement to find the applicant
    // We are selecting all necessary columns for the admit card display.
    $stmt = $conn->prepare("
        SELECT 
            applicant_id, form_no, student_name, father_name, applying_for_class, 
            test_date, test_time, syllabus_url, photo_filename,
            whatsapp_father, is_locked 
        FROM applicants 
        WHERE form_no = ? AND approval_status = 'Pending'
    ");
    $stmt->bind_param("s", $form_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $applicant = $result->fetch_assoc();
        
        // Check if the applicant's data is LOCKED by admin control
        if ($applicant['is_locked'] == 1) {
            $stmt->close();
            $conn->close();
            // Redirect back to print page with an error
            header("Location: /chiniot/print-admit-card.php?error=not_found&msg=" . urlencode("Admit card data is currently locked for review. Please contact administration."));
            exit;
        }

        // --- ADMIT CARD HTML STARTS HERE ---
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admit Card - <?php echo htmlspecialchars($applicant['form_no']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .admit-card {
            width: 700px;
            margin: auto;
            background: #fff;
            border: 2px solid #004a99;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .card-header {
            display: flex;
            align-items: center;
            padding: 20px;
            border-bottom: 2px solid #004a99;
        }
        .card-header img {
            height: 80px;
            margin-right: 20px;
        }
        .card-header h1 {
            color: #004a99;
            margin: 0;
            font-size: 20px;
        }
        .card-title {
            text-align: center;
            background: #fdb813;
            color: #000;
            padding: 10px;
            font-size: 20px;
            font-weight: bold;
        }
        .card-body {
            padding: 20px;
            display: flex;
            gap: 20px;
        }
        .student-photo {
            width: 150px;
            flex-shrink: 0;
        }
        .student-photo img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border: 2px solid #ddd;
            border-radius: 5px;
        }
        .student-details {
            flex: 1;
        }
        .details-table {
            width: 100%;
            border-collapse: collapse;
        }
        .details-table td {
            padding: 10px;
            border-bottom: 1px solid #eee;
            font-size: 14px;
        }
        .details-table td:first-child {
            font-weight: bold;
            color: #555;
            width: 150px;
        }
        .test-details {
            background: #fff8e1;
            border: 1px solid #fdb813;
            border-radius: 5px;
            padding: 15px;
            margin-top: 20px;
            text-align: center;
        }
        .test-details h3 {
            margin: 0 0 10px 0;
            color: #004a99;
        }
        .card-footer {
            padding: 20px;
            font-size: 12px;
            color: #777;
            border-top: 1px solid #eee;
        }
        .print-button {
            display: block;
            width: 200px;
            margin: 20px auto;
            padding: 12px;
            background: #004a99;
            color: white;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        @media print {
            body { background: #fff; padding: 0; }
            .print-button { display: none; }
            .admit-card { margin: 0; box-shadow: none; border: 2px solid #000; }
        }
    </style>
</head>
<body>
    <button class="print-button" onclick="window.print()">Print Admit Card</button>
    <div class="admit-card">
        <div class="card-header">
            <img src="/chiniot/logos.png" alt="School Logo">
            <h1>CHINIOT ISLAMIA PUBLIC SCHOOL & COLLEGE</h1>
        </div>
        <div class="card-title">
            ADMISSION TEST ADMIT CARD (Session 2025-2026)
        </div>
        <div class="card-body">
            <div class="student-photo">
                <img src="/chiniot/result/uploads/<?php echo htmlspecialchars($applicant['photo_filename'] ?? 'default.png'); ?>" alt="Applicant Photo">
            </div>
            <div class="student-details">
                <table class="details-table">
                    <tr>
                        <td>Form No:</td>
                        <td><strong><?php echo htmlspecialchars($applicant['form_no']); ?></strong></td>
                    </tr>
                    <tr>
                        <td>Student Name:</td>
                        <td><?php echo htmlspecialchars($applicant['student_name']); ?></td>
                    </tr>
                    <tr>
                        <td>Father's Name:</td>
                        <td><?php echo htmlspecialchars($applicant['father_name']); ?></td>
                    </tr>
                    <tr>
                        <td>Applying for Class:</td>
                        <td><?php echo htmlspecialchars($applicant['applying_for_class']); ?></td>
                    </tr>
                    <tr>
                        <td>Phone/WhatsApp:</td>
                        <td><?php echo htmlspecialchars($applicant['whatsapp_father']); ?></td>
                    </tr>
                </table>
                
                <div class="test-details">
                    <h3>Test Details</h3>
                    <p>
                        <strong>Date:</strong> <?php echo htmlspecialchars($applicant['test_date'] ? date('l, F j, Y', strtotime($applicant['test_date'])) : 'To Be Announced'); ?>
                        <br>
                        <strong>Time:</strong> <?php echo htmlspecialchars($applicant['test_time'] ? date('g:i A', strtotime($applicant['test_time'])) : 'To Be Announced'); ?>
                    </p>
                    <p style="margin:0;">
                        <strong>Syllabus:</strong> 
                        <a href="<?php echo htmlspecialchars($applicant['syllabus_url'] ?? '#'); ?>" target="_blank">Click to View</a>
                    </p>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <ul>
                <li>Please bring this admit card and original B-Form on the test day.</li>
                <li>Please arrive at the campus 15 minutes before the scheduled test time.</li>
                <li>The use of calculators or mobile phones is not allowed.</li>
            </ul>
        </div>
    </div>
</body>
</html>
        <?php
        $stmt->close();
        $conn->close();
        exit;

    } else {
        // No applicant found
        $stmt->close();
        $conn->close();
        header("Location: /chiniot/print-admit-card.php?error=not_found");
        exit;
    }
} else {
    // Not a POST request
    header("Location: /chiniot/print-admit-card.php");
    exit;
}
?>