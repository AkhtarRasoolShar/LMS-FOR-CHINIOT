<?php
$pageTitle = "Class Report Sheet";
include 'header_teacher.php';

// 1. Get Assignment Details
if (!isset($_GET['class_id']) || !isset($_GET['subject_id'])) {
    // If parameters missing, show list of classes to select
    echo "<div class='card'><h3>Select a Class to View Report</h3>";
    $assign_sql = "SELECT ta.class_id, ta.subject_id, c.class_name, s.subject_name 
                   FROM teacher_assignments ta 
                   JOIN classes c ON ta.class_id = c.class_id 
                   JOIN subjects s ON ta.subject_id = s.subject_id 
                   WHERE ta.teacher_id = $teacher_id ORDER BY c.class_name";
    $res = $conn->query($assign_sql);
    if ($res->num_rows > 0) {
        echo "<ul style='list-style:none; padding:0;'>";
        while ($row = $res->fetch_assoc()) {
            echo "<li style='margin-bottom:10px;'><a href='?class_id={$row['class_id']}&subject_id={$row['subject_id']}' class='btn-primary' style='display:block; text-align:left; padding:15px;'> <i class='fas fa-arrow-right'></i> {$row['class_name']} - {$row['subject_name']}</a></li>";
        }
        echo "</ul></div></div></div></body></html>";
        exit;
    } else {
        echo "<p>No classes assigned.</p></div></div></div></body></html>";
        exit;
    }
}

$class_id = (int)$_GET['class_id'];
$subject_id = (int)$_GET['subject_id'];
$term = isset($_GET['term']) ? $_GET['term'] : 'FINAL TERM';
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// Fetch Names
$info = $conn->query("SELECT c.class_name, s.subject_name FROM classes c, subjects s WHERE c.class_id=$class_id AND s.subject_id=$subject_id")->fetch_assoc();

// Fetch Students & Marks
$sql = "SELECT s.student_id, s.name, s.f_name, r.marks_obtained, r.total_marks 
        FROM students s 
        LEFT JOIN results r ON (s.student_id = r.student_id AND r.subject_id = $subject_id AND r.term_name = '$term' AND r.session_year = '$year')
        WHERE s.class LIKE (SELECT class_name FROM classes WHERE class_id = $class_id)
        ORDER BY s.name ASC";
$students = $conn->query($sql);
?>

<style>
    .filters {
        background: #f9f9f9;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        display: flex;
        gap: 15px;
        align-items: end;
    }

    .form-control {
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        width: 100%;
    }

    .report-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
    }

    .report-table th,
    .report-table td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: center;
    }

    .report-table th {
        background: #004a99;
        color: white;
    }

    .report-table tr:nth-child(even) {
        background: #f9f9f9;
    }

    /* Print Styles */
    @media print {

        .sidebar,
        .top-bar,
        .filters,
        .btn-print,
        .actions-col {
            display: none !important;
        }

        .main-content {
            margin: 0;
            width: 100%;
        }

        .card {
            box-shadow: none;
            border: none;
        }

        .report-table th {
            color: black;
            background: #ddd;
        }

        .report-header {
            display: block !important;
            text-align: center;
            margin-bottom: 20px;
        }
    }

    .report-header {
        display: none;
    }
</style>

<div class="card">
    <form method="GET" class="filters">
        <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
        <input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">

        <div style="flex:1;">
            <label><strong>Term:</strong></label>
            <select name="term" class="form-control">
                <?php foreach (['1st QUARTERLY', 'MID TERM', '2nd QUARTERLY', 'FINAL TERM'] as $t)
                    echo "<option value='$t' " . ($t == $term ? 'selected' : '') . ">$t</option>"; ?>
            </select>
        </div>
        <div style="flex:1;">
            <label><strong>Year:</strong></label>
            <select name="year" class="form-control">
                <?php foreach (range(date('Y'), 2022) as $y)
                    echo "<option value='$y' " . ($y == $year ? 'selected' : '') . ">$y</option>"; ?>
            </select>
        </div>
        <button type="submit" class="btn-primary">Load Report</button>
        <button type="button" onclick="window.print()" class="btn-warning btn-print"><i class="fas fa-print"></i> Print List</button>
    </form>

    <div class="report-header">
        <h2>CHINIOT ISLAMIA PUBLIC SCHOOL</h2>
        <h3>Mark Sheet: <?php echo $info['subject_name']; ?> (<?php echo $info['class_name']; ?>)</h3>
        <p>Term: <?php echo $term; ?> | Session: <?php echo $year; ?></p>
    </div>

    <table class="report-table">
        <thead>
            <tr>
                <th style="width:50px;">#</th>
                <th style="text-align:left;">Student Name</th>
                <th style="text-align:left;">Father Name</th>
                <th>Total</th>
                <th>Obtained</th>
                <th>%</th>
                <th class="actions-col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($students->num_rows > 0):
                $count = 1;
                while ($s = $students->fetch_assoc()):
                    $obt = $s['marks_obtained'];
                    $tot = $s['total_marks'];
                    $perc = ($tot > 0 && is_numeric($obt)) ? round(($obt / $tot) * 100) . '%' : '-';
            ?>
                    <tr>
                        <td><?php echo $count++; ?></td>
                        <td style="text-align:left; font-weight:bold;"><?php echo htmlspecialchars($s['name']); ?></td>
                        <td style="text-align:left;"><?php echo htmlspecialchars($s['f_name']); ?></td>
                        <td><?php echo $tot ? $tot : '-'; ?></td>
                        <td><?php echo is_numeric($obt) ? $obt : '<span style="color:red;">Abs</span>'; ?></td>
                        <td><?php echo $perc; ?></td>
                        <td class="actions-col">
                            <a href="../student/view_result.php?student_id_override=<?php echo $s['student_id']; ?>&year=<?php echo $year; ?>" target="_blank" style="color:#004a99; text-decoration:none; font-size:12px;">
                                <i class="fas fa-eye"></i> Card
                            </a>
                        </td>
                    </tr>
                <?php endwhile;
            else: ?>
                <tr>
                    <td colspan="7">No students found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="report-header" style="margin-top:50px; display:flex; justify-content:space-between;">
        <div style="border-top:1px solid #000; width:200px; margin-top:50px;">Subject Teacher</div>
        <div style="border-top:1px solid #000; width:200px; margin-top:50px;">Principal</div>
    </div>
</div>

</div>
</div>
</body>

</html>