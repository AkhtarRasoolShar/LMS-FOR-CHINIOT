<?php
// PHPMAILER-FE - default.config.php

/* GENERAL SETTINGS */
$CONFIG['MAIL_REPLY_TO'] = ''; // Overridden by sender's email address when sending contact form
$CONFIG['MAIL_DEFAULT_FROM_NAME'] = 'Chiniot Islamia Contact Form'; // The name that appears in the recipient's inbox
$CONFIG['MAIL_DEFAULT_TO_EMAIL'] = 'info@aknasoft.com'; // Default recipient email address

/* SMTP SERVER SETTINGS */
// === YOUR PROVIDED CREDENTIALS ARE USED HERE ===
$CONFIG['MAIL_HOST'] = 'smtp.hostinger.com';      // SMTP Hostinger Host
$CONFIG['MAIL_SMTP_AUTH'] = true;               // Always set to true for security
$CONFIG['MAIL_USERNAME'] = 'info@aknasoft.com';   // Your Hostinger Email/Username
$CONFIG['MAIL_PASSWORD'] = 'ALiSain0099@';        // Your Hostinger Password
$CONFIG['MAIL_PORT'] = 465;                      // Your specified Port (465 for SSL)
$CONFIG['MAIL_SMTP_SECURE'] = 'ssl';            // Use 'ssl' for port 465, or 'tls' for port 587
$CONFIG['MAIL_CHARSET'] = 'UTF-8';

/* FORM VALIDATION SETTINGS */
$CONFIG['FORM_REQUIRED_FIELD_COLOR'] = '#FF0000';
$CONFIG['FORM_REQUIRED_FIELD_MSG'] = 'This field is required.';
$CONFIG['FORM_VALID_EMAIL_MSG'] = 'Please enter a valid email address.';
$CONFIG['FORM_VALID_PHONE_MSG'] = 'Please enter a valid phone number.';
$CONFIG['FORM_VALID_URL_MSG'] = 'Please enter a valid website address.';
$CONFIG['FORM_VALID_DATE_MSG'] = 'Please enter a valid date.';
$CONFIG['FORM_VALID_TIME_MSG'] = 'Please enter a valid time.';
$CONFIG['FORM_VALID_DATETIME_MSG'] = 'Please enter a valid date and time.';

/* FILE UPLOAD SETTINGS */
$CONFIG['FILE_UPLOAD'] = false; // Set to true if you are handling file uploads
$CONFIG['FILE_SIZE_LIMIT'] = 100000; // 100KB limit
$CONFIG['FILE_UPLOAD_PATH'] = ''; // Path to the directory where files should be saved

/* CAPTCHA SETTINGS */
$CONFIG['CAPTCHA'] = false; // Set to true to enable the CAPTCHA (requires configuration)
$CONFIG['CAPTCHA_FAIL_MSG'] = 'Please enter the correct verification code.';

/* OUTPUT SETTINGS */
$CONFIG['OUTPUT_SEND_FAIL_MSG'] = 'An error occurred while trying to send your message. Please try again later.';
$CONFIG['OUTPUT_SEND_SUCCESS_MSG'] = 'Your message has been sent successfully. Thank you.';

/* BAN LOGGING SETTINGS */
$CONFIG['BAN_LOGGING'] = false; // Log failed sending attempts

// DO NOT MODIFY BELOW THIS LINE
if (defined('PHPMailerFE_CONFIG_LOADED')) {
   return;
}
define('PHPMailerFE_CONFIG_LOADED', true);
