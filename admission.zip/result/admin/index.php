<?php
session_start();
require 'include/db.php'; // Adjust path if your db.php is elsewhere
include '../../header.php';

if (isset($_SESSION['teacher_id'])) {
    echo "<script>window.location.href='dashboard.php';</script>";
    exit;
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM teacher WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $teacher = $result->fetch_assoc();

        if (password_verify($password, $teacher['password_hash'])) {
            $_SESSION['teacher_id'] = $teacher['teacher_id'];
            $_SESSION['teacher_name'] = $teacher['full_name'];

            // --- FIX: Set Role safely ---
            if (isset($teacher['role']) && !empty($teacher['role'])) {
                $_SESSION['teacher_role'] = $teacher['role'];
            } else {
                $_SESSION['teacher_role'] = 'Teacher'; // Default
            }

            echo "<script>window.location.href='dashboard.php';</script>";
            exit;
        } else {
            $error = "Invalid Password.";
        }
    } else {
        $error = "Username not found.";
    }
    $stmt->close();
}
?>
<div class="container-padded" style="max-width: 400px; margin: 60px auto;">
    <form method="POST" style="background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 20px rgba(0,0,0,0.1); border-top: 5px solid #ffc107;">
        <div style="text-align: center; margin-bottom: 20px;">
            <img src="../../logos.png" alt="Logo" style="width: 80px;">
            <h2 style="color: #333; margin-top: 10px;">Teacher Portal</h2>
        </div>
        <?php if ($error) echo "<div style='background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px; text-align: center;'>$error</div>"; ?>
        <div class="form-group" style="margin-bottom:15px;">
            <label style="font-weight:bold; display:block;">Username</label>
            <input type="text" name="username" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:4px;">
        </div>
        <div class="form-group" style="margin-bottom:20px;">
            <label style="font-weight:bold; display:block;">Password</label>
            <input type="password" name="password" required style="width:100%; padding:10px; border:1px solid #ddd; border-radius:4px;">
        </div>
        <button type="submit" style="width:100%; background:#ffc107; color:#333; padding:12px; border:none; border-radius:4px; font-weight:bold; cursor:pointer;">Login</button>
    </form>
</div>
<?php include '../../footer.php'; ?>